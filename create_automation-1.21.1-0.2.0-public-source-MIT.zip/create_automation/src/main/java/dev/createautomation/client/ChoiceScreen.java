package dev.createautomation.client;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.util.List;
import java.util.function.IntConsumer;

/** Paged, keyboard-accessible picker; large control graphs do not need dozens of cycle clicks. */
final class ChoiceScreen extends Screen {
    private final Screen parent;
    private final List<String> labels;
    private final IntConsumer onPick;
    private int page;

    ChoiceScreen(Screen parent, String title, List<String> labels, IntConsumer onPick) {
        super(Component.literal(title));
        this.parent = parent;
        this.labels = List.copyOf(labels);
        this.onPick = onPick;
    }

    @Override
    protected void init() {
        clearWidgets();
        int columnWidth = Math.min(150, (width - 32) / 3);
        int left = (width - columnWidth * 3) / 2;
        int rows = Math.max(1, (height - 95) / 24);
        int perPage = rows * 3;
        page = Math.max(0, Math.min(page, Math.max(0, (labels.size() - 1) / perPage)));
        for (int local = 0; local < perPage && page * perPage + local < labels.size(); local++) {
            int index = page * perPage + local;
            addRenderableWidget(Button.builder(Component.literal(labels.get(index)), button -> {
                onPick.accept(index);
                if (minecraft.screen == this) minecraft.setScreen(parent);
            }).bounds(left + (local % 3) * columnWidth, 40 + (local / 3) * 24, columnWidth - 4, 20).build());
        }
        addRenderableWidget(Button.builder(Component.literal("<"), b -> { page--; init(); })
                .bounds(width / 2 - 110, height - 32, 40, 20).build()).active = page > 0;
        addRenderableWidget(Button.builder(Component.literal(AutomationScreen.tr("返回", "Back")), b -> onClose())
                .bounds(width / 2 - 60, height - 32, 120, 20).build());
        addRenderableWidget(Button.builder(Component.literal(">"), b -> { page++; init(); })
                .bounds(width / 2 + 70, height - 32, 40, 20).build()).active = (page + 1) * perPage < labels.size();
    }

    @Override
    public void renderBackground(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        // Custom background is painted in render; avoid vanilla's second background/blur pass.
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        graphics.fill(0, 0, width, height, 0xF51A222B);
        graphics.drawCenteredString(font, title, width / 2, 14, 0xF0D49A);
        super.render(graphics, mouseX, mouseY, partialTick);
    }

    @Override public boolean isPauseScreen() { return false; }
    @Override public void onClose() { minecraft.setScreen(parent); }
}
