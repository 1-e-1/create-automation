package dev.createautomation.client;

import dev.createautomation.engine.QuickSettings;
import dev.createautomation.engine.QuickSettingsCodec;
import dev.createautomation.engine.QuickTransferEngine;
import dev.createautomation.engine.QuickTransferMath;
import dev.createautomation.network.AutomationNetwork;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.function.Consumer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.client.gui.screens.ConfirmScreen;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;

/** Direct ZPK editor for a theoretical unity-negative-feedback response, independent of the graph editor. */
public final class QuickConfiguratorScreen extends Screen implements AutomationEditorScreen {
    private static final int TEXT = 0xDFE8EC, MUTED = 0x9DAFB9, GOLD = 0xF0D49A;
    private final BlockPos pos;
    private final String dimension;
    private final CompoundTag original;
    private CompoundTag telemetry;
    private final List<RootDraft> zeros = new ArrayList<>(), poles = new ArrayList<>();
    private final Map<String, String> channels = new LinkedHashMap<>();
    private final List<Label> labels = new ArrayList<>();
    private final List<Sample> history = new ArrayList<>();
    private String gain = "1", message = "";
    private boolean enabled = true, dirty, error, awaitingSave;
    private int tab, zeroPage, polePage, ticks, sentAt, formulaScroll, formulaMaxScroll;
    private long revision, sentRevision, lastSample = Long.MIN_VALUE;

    private static final class RootDraft {
        String real, imaginary;
        RootDraft(double real, double imaginary) { this.real = Double.toString(real); this.imaginary = Double.toString(imaginary); }
        QuickSettings.Root root() { return new QuickSettings.Root(number(real, "real"), number(imaginary, "imaginary")); }
    }
    private record Label(int x, int y, String text) { }
    private record Sample(long tick, double reference, boolean referenceValid, double output, boolean outputValid) { }

    public QuickConfiguratorScreen(BlockPos pos, String dimension, CompoundTag snapshot) {
        super(Component.translatable("block.create_automation.quick_configurator"));
        this.pos = pos.immutable(); this.dimension = dimension;
        original = snapshot.getCompound("settings").copy(); telemetry = snapshot.copy();
        enabled = !original.contains("enabled") || original.getBoolean("enabled");
        channels.put("network", original.contains("network") ? original.getString("network") : "main");
        channels.put("inputA", original.contains("inputA") ? original.getString("inputA") : "setpoint");
        channels.put("output", original.contains("output") ? original.getString("output") : "output");
        channels.put("min", original.contains("min") ? Double.toString(original.getDouble("min")) : "-1.0E12");
        channels.put("max", original.contains("max") ? Double.toString(original.getDouble("max")) : "1.0E12");
        QuickSettings settings;
        try { settings = original.contains("quick") ? QuickSettingsCodec.fromJson(original.getString("quick")) : QuickSettingsCodec.defaults(); }
        catch (RuntimeException exception) { settings = QuickSettingsCodec.defaults(); setMessage(exception.getMessage(), true); }
        gain = Double.toString(settings.gain());
        settings.zeros().forEach(root -> zeros.add(new RootDraft(root.real(), root.imaginary())));
        settings.poles().forEach(root -> poles.add(new RootDraft(root.real(), root.imaginary())));
        if (settings.mode() != QuickSettings.Mode.CLOSED_LOOP)
            setMessage(tr("保存后将使用理论单位负反馈模式", "Saving selects theoretical unity feedback"), false);
        sample(snapshot);
    }

    private static String tr(String zh, String en) {
        return Minecraft.getInstance().getLanguageManager().getSelected().startsWith("zh") ? zh : en;
    }
    private void changed() { dirty = true; revision++; }
    private void setMessage(String text, boolean failed) { message = text == null ? "" : text; error = failed; }
    private Button button(int x, int y, int w, String text, Button.OnPress action) {
        return addRenderableWidget(Button.builder(Component.literal(text), action).bounds(x, y, w, 18).build());
    }
    private EditBox edit(int x, int y, int w, String label, String value, Consumer<String> receiver) {
        EditBox field = new EditBox(font, x, y, w, 18, Component.literal(label));
        field.setMaxLength(48); field.setValue(value);
        field.setResponder(next -> { receiver.accept(next); changed(); });
        field.setTooltip(Tooltip.create(Component.literal(label)));
        return addRenderableWidget(field);
    }
    @Override protected void init() {
        clearWidgets(); labels.clear();
        String[] tabs = {tr("零极点", "Zeros / poles"), tr("通道", "Channels"), tr("传递函数", "Transfer function"), tr("响应曲线", "Response")};
        int tabWidth = (width - 16) / 4;
        for (int i = 0; i < 4; i++) {
            int next = i;
            button(8 + i * tabWidth, 40, tabWidth - 3, tabs[i], b -> { tab = next; init(); }).active = tab != i;
        }
        button(8, height - 24, 92, enabled ? tr("运行：开启", "Enabled: ON") : tr("运行：关闭", "Enabled: OFF"), b -> {
            enabled = !enabled; changed(); init();
        });
        button(width - 190, height - 24, 90, tr("保存并应用", "Save & apply"), b -> save());
        button(width - 94, height - 24, 86, tr("关闭", "Close"), b -> onClose());
        if (tab == 0) initRoots();
        if (tab == 1) initChannels();
    }

    private int rows() { return Math.min(6, Math.max(1, (height - 216) / 24)); }
    private void initRoots() {
        labels.add(new Label(10, 70, tr("增益 K", "Gain K")));
        edit(66, 66, 116, tr("增益 K（零极点乘法系数）", "Gain K (ZPK multiplier)"), gain, value -> gain = value);
        rootColumn(zeros, true, 10, (width - 28) / 2);
        rootColumn(poles, false, 18 + (width - 28) / 2, (width - 28) / 2);
    }
    private void rootColumn(List<RootDraft> roots, boolean zero, int x, int w) {
        int page = zero ? zeroPage : polePage;
        page = Math.max(0, Math.min(page, Math.max(0, roots.size() - rows())));
        if (zero) zeroPage = page; else polePage = page;
        String noun = zero ? tr("零点", "Zero") : tr("极点", "Pole");
        labels.add(new Label(x, 96, noun + tr("  实部 / 虚部", "  Re / Im")));
        button(x + w - 62, 90, 62, "+ " + noun, b -> {
            if (roots.size() >= 6) { setMessage(tr("最多六阶；共轭对占两阶", "Maximum order six; a conjugate pair counts twice"), true); return; }
            roots.add(new RootDraft(-1, 0));
            if (zero) zeroPage = Math.max(0, roots.size() - rows()); else polePage = Math.max(0, roots.size() - rows());
            changed(); init();
        });
        int realWidth = Math.max(32, (w - 48) / 2), imaginaryWidth = w - 48 - realWidth;
        for (int row = 0; row < rows() && page + row < roots.size(); row++) {
            int index = page + row;
            RootDraft root = roots.get(index);
            int y = 114 + row * 24;
            labels.add(new Label(x, y + 5, (zero ? "z" : "p") + (index + 1)));
            edit(x + 22, y, realWidth, noun + (index + 1) + tr(" 实部", " real"), root.real, value -> root.real = value);
            edit(x + 25 + realWidth, y, imaginaryWidth, noun + (index + 1) + tr(" 虚部≥0；正值自动共轭", " imaginary >=0; positive creates pair"), root.imaginary, value -> root.imaginary = value);
            button(x + w - 19, y, 19, "×", b -> { roots.remove(index); changed(); init(); });
        }
        int navY = 114 + rows() * 24;
        button(x, navY, 30, "↑", b -> { if (zero) zeroPage--; else polePage--; init(); }).active = page > 0;
        button(x + 34, navY, 30, "↓", b -> { if (zero) zeroPage++; else polePage++; init(); }).active = page + rows() < roots.size();
        labels.add(new Label(x + 72, navY + 5, roots.isEmpty() ? tr("无", "None") : (page + 1) + "–" + Math.min(page + rows(), roots.size()) + "/" + roots.size()));
    }
    private void initChannels() {
        String[][] fields = {{"network", tr("网络", "Network")}, {"inputA", tr("参考输入 A", "Reference input A")},
                {"output", tr("响应输出 Y", "Response output Y")}, {"min", tr("输出下限", "Output minimum")}, {"max", tr("输出上限", "Output maximum")}};
        for (int i = 0; i < fields.length; i++) {
            String key = fields[i][0], label = fields[i][1];
            int y = 68 + i * 26;
            labels.add(new Label(12, y + 5, label));
            edit(Math.min(135, width / 3), y, width - Math.min(135, width / 3) - 12, label, channels.get(key), value -> channels.put(key, value));
        }
    }
    private QuickSettings settings() {
        return new QuickSettings(QuickSettings.Mode.CLOSED_LOOP, number(gain, "K"),
                zeros.stream().map(RootDraft::root).toList(), poles.stream().map(RootDraft::root).toList());
    }
    private static double number(String text, String name) {
        try {
            double result = Double.parseDouble(text.trim());
            if (Double.isFinite(result)) return result;
        } catch (NumberFormatException ignored) { }
        throw new IllegalArgumentException(name + ": " + tr("请输入有限数值", "enter a finite number"));
    }
    private void save() {
        if (awaitingSave) return;
        try {
            QuickSettings settings = settings();
            new QuickTransferEngine(settings);
            CompoundTag candidate = original.copy();
            candidate.putString("quick", QuickSettingsCodec.toJson(settings));
            for (String key : List.of("network", "inputA", "output")) candidate.putString(key, channels.get(key).trim());
            for (String key : List.of("inputB", "inputC", "inputD")) candidate.putString(key, "NULL");
            candidate.putDouble("min", number(channels.get("min"), "min"));
            candidate.putDouble("max", number(channels.get("max"), "max"));
            candidate.putBoolean("enabled", enabled);
            AutomationNetwork.save(pos, dimension, candidate);
            awaitingSave = true; sentAt = ticks; sentRevision = revision;
            setMessage(tr("正在应用…", "Applying…"), false);
        } catch (RuntimeException exception) { setMessage(exception.getMessage(), true); }
    }
    @Override public void receive(AutomationNetwork.SnapshotPayload packet) {
        if (!pos.equals(packet.pos()) || !dimension.equals(packet.dimension())) return;
        try {
            CompoundTag data = AutomationNetwork.parse(packet.snapshot());
            if (data.contains("value")) { telemetry = data; sample(data); }
            if (packet.acknowledgement()) {
                awaitingSave = false;
                if (packet.message().equals("saved")) {
                    if (sentRevision == revision) dirty = false;
                    setMessage(tr("已保存；理论响应状态已复位", "Saved; theoretical response state reset"), false);
                } else setMessage(packet.message(), true);
            } else if (!packet.message().isEmpty()) setMessage(packet.message(), true);
        } catch (Exception exception) { setMessage(exception.getMessage(), true); }
    }
    private void sample(CompoundTag data) {
        long tick = data.getLong("sampleTick");
        if (tick == lastSample) return;
        lastSample = tick;
        history.add(new Sample(tick, data.getDouble("a"), data.getBoolean("validA"), data.getDouble("value"), data.getBoolean("valid")));
        if (history.size() > 400) history.removeFirst();
    }
    @Override public void tick() {
        super.tick(); ticks++;
        if (minecraft.player == null || minecraft.level == null
                || !minecraft.level.dimension().location().toString().equals(dimension)) {
            minecraft.setScreen(null); return;
        }
        if (ticks % 5 == 0) AutomationNetwork.request(pos, dimension);
        if (awaitingSave && ticks - sentAt > 100) { awaitingSave = false; setMessage(tr("保存超时，请重试", "Save timed out; retry"), true); }
    }
    @Override public boolean isPauseScreen() { return false; }
    @Override public void onClose() {
        if (dirty) minecraft.setScreen(new ConfirmScreen(discard -> {
            if (discard) minecraft.setScreen(null); else minecraft.setScreen(this);
        }, Component.literal(tr("放弃未保存修改？", "Discard unsaved changes?")),
                Component.literal(tr("已保存的系统继续运行。", "The saved system continues running."))));
        else super.onClose();
    }
    @Override public void renderBackground(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        // Screen.render invokes this after our custom drawing; avoid blurring labels and traces.
    }
    @Override public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        graphics.fill(0, 0, width, height, 0xFF15232C);
        graphics.fill(0, 0, width, 34, 0xFF21333D);
        graphics.drawString(font, title, 10, 7, GOLD, false);
        text(graphics, tr("理论单位负反馈：L(s) → L(s)/(1+L(s))；不接实际测量", "Theoretical unity feedback: L/(1+L); no measured feedback"), 10, 23, MUTED, width - 20);
        for (Label label : labels) graphics.drawString(font, label.text, label.x, label.y, TEXT, false);
        if (tab == 0) renderPreview(graphics);
        else if (tab == 2) renderFormula(graphics);
        else if (tab == 3) renderTraces(graphics);
        if (!message.isEmpty()) text(graphics, message, 10, height - 37, error ? 0xFF8D9D : 0x62D8AD, width - 20);
        else text(graphics, dirty ? tr("草稿未保存", "Unsaved draft") : telemetry.getString("status"), 10, height - 37, MUTED, width - 20);
        super.render(graphics, mouseX, mouseY, partialTick);
    }
    private void renderPreview(GuiGraphics graphics) {
        try {
            QuickSettings settings = settings();
            new QuickTransferEngine(settings);
            String stability = QuickTransferMath.strictlyStable(settings) ? tr("闭环离散稳定性判据通过", "Closed-loop discrete stability check passed")
                    : tr("稳定性判据未通过或处于边界", "Stability check failed or borderline");
            text(graphics, stability, 194, 71, QuickTransferMath.strictlyStable(settings) ? 0x62D8AD : 0xFFC86B, width - 204);
            text(graphics, QuickTransferMath.factorFormula(settings), 10, height - 78, TEXT, width - 20);
            text(graphics, QuickTransferMath.expandedFormula(settings), 10, height - 64, GOLD, width - 20);
            text(graphics, tr("虚部=0 为实根；>0 自动共轭成对。完整式见“传递函数”。", "Im=0: real root; Im>0: conjugate pair. Full equation in Transfer function."), 10, height - 50, MUTED, width - 20);
        } catch (RuntimeException exception) { text(graphics, exception.getMessage(), 10, height - 76, 0xFF8D9D, width - 20); }
    }
    private void renderFormula(GuiGraphics graphics) {
        graphics.enableScissor(8, 64, width - 8, height - 54);
        int y = 68 - formulaScroll;
        try {
            QuickSettings settings = settings(); new QuickTransferEngine(settings);
            y = paragraph(graphics, QuickTransferMath.factorFormula(settings), y, TEXT);
            y = paragraph(graphics, QuickTransferMath.expandedFormula(settings), y + 6, GOLD);
        } catch (RuntimeException exception) { y = paragraph(graphics, exception.getMessage(), y, 0xFF8D9D); }
        y = paragraph(graphics, tr("A 是参考 r；Y 是理论响应。这里没有连接外部测量的实际反馈回路。", "A is reference r; Y is the theoretical response. This is not an external measured-feedback loop."), y + 8, TEXT);
        y = paragraph(graphics, tr("20 Hz Tustin：s=40(1-z^-1)/(1+z^-1)，无频率预畸变；一/二阶节级联运行。", "20 Hz Tustin: s=40(1-z^-1)/(1+z^-1), no prewarping; first/second-order cascades."), y + 6, MUTED);
        y = paragraph(graphics, tr("s 单位为模拟秒^-1。K 是零极点乘法系数，不一定等于 DC 增益。最多六阶，分子阶数≤分母。式中数值显示六位有效数字。", "s uses simulation seconds^-1. K is the ZPK multiplier, not necessarily DC gain. Proper transfers up to order 6; displayed coefficients use six significant digits."), y + 6, MUTED);
        y = paragraph(graphics, tr("输出限幅位于传递函数之后；不是 PID 抗积分饱和。缺失/非法输入、停用、重新应用或重载会复位响应历史。", "Output limits follow the transfer function; they are not PID anti-windup. Missing/invalid input, disable, apply or reload resets response history."), y + 6, MUTED);
        formulaMaxScroll = Math.max(0, y + formulaScroll - height + 58);
        graphics.disableScissor();
        if (formulaMaxScroll > 0) text(graphics, tr("滚轮查看完整公式与说明", "Scroll to view all equations and notes"), 12, height - 49, MUTED, width - 24);
    }
    private int paragraph(GuiGraphics graphics, String message, int y, int color) {
        if (message == null) return y;
        for (var line : font.split(Component.literal(message), width - 24)) {
            graphics.drawString(font, line, 12, y, color, false); y += 11;
        }
        return y;
    }
    @Override public boolean mouseScrolled(double mouseX, double mouseY, double scrollX, double scrollY) {
        if (tab == 2) {
            formulaScroll = Math.max(0, Math.min(formulaMaxScroll, formulaScroll - (int) (scrollY * 22)));
            return true;
        }
        return super.mouseScrolled(mouseX, mouseY, scrollX, scrollY);
    }
    private void renderTraces(GuiGraphics graphics) {
        text(graphics, tr("参考 A（蓝） / 理论响应 Y（绿） · 界面每5 tick采样", "Reference A (blue) / theoretical Y (green); display samples every 5 ticks"), 12, 68, MUTED, width - 24);
        int left = 48, top = 92, right = width - 14, bottom = height - 62;
        if (bottom <= top || right <= left) return;
        graphics.fill(left, top, right, bottom, 0xFF0E1920);
        double min = 0, max = 1;
        for (Sample sample : history) {
            if (sample.referenceValid && Double.isFinite(sample.reference)) { min = Math.min(min, sample.reference); max = Math.max(max, sample.reference); }
            if (sample.outputValid && Double.isFinite(sample.output)) { min = Math.min(min, sample.output); max = Math.max(max, sample.output); }
        }
        if (max <= min) { min = -1; max = 1; }
        text(graphics, String.format(Locale.ROOT, "%.3g", max), 5, top, MUTED, 40);
        text(graphics, String.format(Locale.ROOT, "%.3g", min), 5, bottom - 9, MUTED, 40);
        if (history.size() < 2) return;
        long start = history.getFirst().tick, end = history.getLast().tick;
        if (end <= start) return;
        for (int trace = 0; trace < 2; trace++) {
            Sample previous = null;
            for (Sample sample : history) {
                boolean valid = trace == 0 ? sample.referenceValid : sample.outputValid;
                double value = trace == 0 ? sample.reference : sample.output;
                if (!valid || !Double.isFinite(value)) { previous = null; continue; }
                if (previous != null) {
                    double old = trace == 0 ? previous.reference : previous.output;
                    int x0 = left + (int) ((previous.tick - start) * (right - left - 1.0) / (end - start));
                    int x1 = left + (int) ((sample.tick - start) * (right - left - 1.0) / (end - start));
                    int y0 = plotY(old, min, max, top, bottom);
                    int y1 = plotY(value, min, max, top, bottom);
                    line(graphics, x0, y0, x1, y1, trace == 0 ? 0xFF72B6FF : 0xFF62D8AD);
                }
                previous = sample;
            }
        }
    }
    private static int plotY(double value, double min, double max, int top, int bottom) {
        // Normalization before subtraction keeps even opposite near-MAX_VALUE samples drawable.
        double scale = Math.max(1, Math.max(Math.abs(min), Math.abs(max)));
        double fraction = (value / scale - min / scale) / (max / scale - min / scale);
        if (!Double.isFinite(fraction)) fraction = .5;
        fraction = Math.max(0, Math.min(1, fraction));
        return bottom - 1 - (int) (fraction * (bottom - top - 1));
    }
    private static void line(GuiGraphics graphics, int x0, int y0, int x1, int y1, int color) {
        int steps = Math.max(Math.abs(x1 - x0), Math.abs(y1 - y0));
        if (steps == 0) { graphics.fill(x0, y0, x0 + 1, y0 + 1, color); return; }
        for (int i = 0; i <= steps; i++) {
            int x = x0 + (x1 - x0) * i / steps, y = y0 + (y1 - y0) * i / steps;
            graphics.fill(x, y, x + 1, y + 1, color);
        }
    }
    private void text(GuiGraphics graphics, String value, int x, int y, int color, int maxWidth) {
        if (value != null && maxWidth > 0) graphics.drawString(font, font.plainSubstrByWidth(value, maxWidth), x, y, color, false);
    }
}
