package dev.createautomation.client;

import com.google.gson.GsonBuilder;
import dev.createautomation.engine.GraphCodec;
import dev.createautomation.engine.QuickSettingsCodec;
import dev.createautomation.client.ponder.AutomationPonderPlugin;
import com.simibubi.create.foundation.item.ItemDescription;
import net.createmod.catnip.lang.FontHelper;
import net.createmod.ponder.foundation.PonderIndex;
import net.createmod.ponder.foundation.PonderTooltipHandler;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;
import net.createmod.ponder.foundation.ui.PonderUI;
import net.minecraft.client.resources.language.I18n;
import dev.createautomation.network.AutomationNetwork;
import dev.createautomation.registry.ModRegistry;
import dev.createautomation.world.AutomationBlockEntity;
import dev.createautomation.world.AutomationBlock;
import dev.createautomation.world.NodeKind;
import net.minecraft.client.Minecraft;
import net.minecraft.client.Screenshot;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.GameType;
import net.minecraft.world.level.block.Blocks;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.common.NeoForge;

import java.lang.reflect.Field;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.EnumMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.BooleanSupplier;

/**
 * Explicit opt-in integration harness for this repository's isolated client directory.
 * Drives real Screen widgets, the payload protocol and integrated-server block entities;
 * captures actual rendered frames. It is never registered in ordinary gameplay.
 */
final class UiSmokeHarness {
    private static final Minecraft CLIENT = Minecraft.getInstance();
    private static final List<Step> STEPS = new ArrayList<>();
    private static final List<Map<String, Object>> RESULTS = new ArrayList<>();
    private static final List<String> SHOTS = new ArrayList<>();
    private static final List<Map<String, Integer>> LAYOUTS = new ArrayList<>();
    private static final Map<NodeKind, BlockPos> POSITIONS = new EnumMap<>(NodeKind.class);
    private static final AtomicReference<String> SERVER_RESULT = new AtomicReference<>("");
    private static boolean prepared, queued, finished;
    private static int ticks, index, started = -1;

    private UiSmokeHarness() {}

    static void install() {
        Path directory = CLIENT.gameDirectory.toPath().toAbsolutePath().normalize();
        if (!directory.endsWith(Path.of("run", "local-client")))
            throw new IllegalStateException("UI smoke tests are restricted to the isolated run/local-client directory");
        NeoForge.EVENT_BUS.addListener(UiSmokeHarness::tick);
        report("waiting_for_test_world", null);
    }

    private static void tick(ClientTickEvent.Post event) {
        if (finished) {
            // Test runner can request a graceful shutdown after inspecting screenshots.
            if (Files.exists(CLIENT.gameDirectory.toPath().resolve("ui-smoke-exit.request"))) CLIENT.stop();
            return;
        }
        ticks++;
        try {
            if (!prepared) {
                if (CLIENT.player == null || CLIENT.getSingleplayerServer() == null || CLIENT.screen != null) {
                    if (ticks > 2400) fail("No isolated integrated world opened within 120 seconds");
                    return;
                }
                prepared = true;
                CLIENT.getSingleplayerServer().execute(UiSmokeHarness::prepareWorld);
            }
            if (!queued) {
                if (!SERVER_RESULT.get().equals("ready")) {
                    if (SERVER_RESULT.get().startsWith("ERROR")) fail(SERVER_RESULT.get());
                    return;
                }
                queued = true; plan(); report("running", null);
            }
            if (index >= STEPS.size()) {
                finished = true;
                report("passed", null);
                return;
            }
            Step step = STEPS.get(index);
            if (started < 0) { started = ticks; step.action.run(); }
            if (ticks - started >= step.delay && step.check.getAsBoolean()) {
                Map<String, Object> result = new LinkedHashMap<>();
                result.put("check", step.name); result.put("passed", true); result.put("clientTick", ticks);
                RESULTS.add(result); index++; started = -1; report("running", null);
            } else if (ticks - started > 400) fail("Timed out: " + step.name + "; server=" + SERVER_RESULT.get());
        } catch (Throwable exception) {
            fail(exception.getClass().getSimpleName() + ": " + exception.getMessage());
        }
    }

    private static void prepareWorld() {
        try {
            ServerPlayer player = CLIENT.getSingleplayerServer().getPlayerList().getPlayers().get(0);
            var level = player.serverLevel();
            player.setGameMode(GameType.CREATIVE);
            player.teleportTo(level, 3.5, 82, 6.5, 180.0F, 24.0F);
            for (int x = -2; x <= 9; x++) for (int z = -2; z <= 8; z++) {
                level.setBlockAndUpdate(new BlockPos(x, 79, z), Blocks.STONE.defaultBlockState());
                for (int y = 80; y <= 84; y++) level.setBlockAndUpdate(new BlockPos(x, y, z), Blocks.AIR.defaultBlockState());
            }
            for (NodeKind kind : NodeKind.values()) {
                int i = kind.ordinal();
                BlockPos position = new BlockPos((i % 3) * 2, 80, (i / 3) * 2);
                POSITIONS.put(kind, position);
                level.setBlockAndUpdate(position, ModRegistry.NODES.get(kind).get().defaultBlockState()
                        .setValue(AutomationBlock.FACING, Direction.SOUTH));
                var block = (AutomationBlockEntity) level.getBlockEntity(position);
                CompoundTag settings = block.getSettings();
                settings.putString("network", "ui_smoke");
                settings.putString("output", "unused_" + kind.id());
                settings.putString("inputA", "control_output");
                if (kind == NodeKind.CONSTANT) {
                    settings.putDouble("constant", 3.25);
                    settings.putString("output", "setpoint");
                }
                if (kind == NodeKind.SYSTEM_BUILDER) {
                    settings.putString("inputA", "setpoint");
                    settings.putString("output", "control_output");
                }
                block.applySettings(settings);
                if (block.getNodeKind() != kind) throw new IllegalStateException("Wrong block entity kind: " + kind);
            }
            SERVER_RESULT.set("ready");
        } catch (Throwable exception) { SERVER_RESULT.set("ERROR " + exception); }
    }

    private static void plan() {
        step("compact GUI scale", () -> setScale(2), () -> CLIENT.getWindow().getGuiScaledWidth() == 427
                && CLIENT.getWindow().getGuiScaledHeight() == 240, 4);
        for (NodeKind kind : NodeKind.values()) {
            step("open " + kind, () -> open(kind), () -> current(kind), 10);
            step("render " + kind + " configuration", () -> shot("block-" + kind.id()), () -> current(kind), 4);
            step("save " + kind + " settings over network", () -> click("保存并应用", "Save & apply"), UiSmokeHarness::saved, 10);
        }
        planDetectorsAndQuick();
        step("open system graph", () -> open(NodeKind.SYSTEM_BUILDER), () -> current(NodeKind.SYSTEM_BUILDER), 8);
        step("graph tab", () -> click("系统构建", "Build graph"), () -> integer(editor(), "tab") == 1, 3);
        step("add node picker", () -> click("+ 节点", "+ Node"), () -> CLIENT.screen instanceof ChoiceScreen, 2);
        step("add GAIN node", () -> clickPrefix("GAIN"), () -> CLIENT.screen instanceof AutomationScreen && nodeCount() == 2, 3);
        step("choose operation", () -> clickPrefix("GAIN"), () -> CLIENT.screen instanceof ChoiceScreen, 2);
        step("change to CLAMP", () -> clickPrefix("CLAMP"), () -> CLIENT.screen instanceof AutomationScreen, 2);
        step("open operation again", () -> clickPrefix("CLAMP"), () -> CLIENT.screen instanceof ChoiceScreen, 2);
        step("change back to GAIN", () -> clickPrefix("GAIN"), () -> CLIENT.screen instanceof AutomationScreen, 2);
        step("input connection picker", () -> clickPrefix("输入1", "Input1"), () -> CLIENT.screen instanceof ChoiceScreen, 2);
        step("connect external INPUT", () -> firstButton().onPress(), () -> CLIENT.screen instanceof AutomationScreen, 2);
        step("set gain parameter", () -> onlyEdit().setValue("1.5"), () -> onlyEdit().getValue().equals("1.5"), 3);
        step("select output", () -> click("设为输出", "Use as output"), () -> ((String) field(editor(), "output")).startsWith("n"), 2);
        step("apply custom graph", () -> click("保存并应用", "Save & apply"), UiSmokeHarness::saved, 8);
        step("server executes edited graph", () -> verifyServerGraph(1.5), () -> SERVER_RESULT.get().equals("graph_ok"), 10);
        step("graph screenshot", () -> shot("graph-custom-gain"), () -> true, 3);
        step("large logical GUI scale", () -> setScale(1), () -> CLIENT.getWindow().getGuiScaledWidth() == 854
                && CLIENT.getWindow().getGuiScaledHeight() == 480 && onlyEdit().getValue().equals("1.5"), 4);
        step("large graph screenshot", () -> shot("graph-scale-1"), () -> true, 3);
        step("restore compact graph GUI", () -> setScale(2), () -> CLIENT.getWindow().getGuiScaledWidth() == 427
                && CLIENT.getWindow().getGuiScaledHeight() == 240 && onlyEdit().getValue().equals("1.5"), 4);
        step("edit draft without saving", () -> onlyEdit().setValue("2.75"), () -> onlyEdit().getValue().equals("2.75"), 20);
        step("telemetry preserves draft", () -> {}, () -> onlyEdit().getValue().equals("2.75") && liveEquals(4.875), 12);
        step("restore draft gain", () -> onlyEdit().setValue("1.5"), () -> true, 2);
        step("add disposable node", () -> click("+ 节点", "+ Node"), () -> CLIENT.screen instanceof ChoiceScreen, 2);
        step("add constant node", () -> clickPrefix("CONSTANT"), () -> CLIENT.screen instanceof AutomationScreen && nodeCount() == 3, 2);
        step("delete unreferenced node", () -> click("删除节点", "Delete node"), () -> nodeCount() == 2, 2);
        step("save after deletion", () -> click("保存并应用", "Save & apply"), UiSmokeHarness::saved, 8);
        step("live traces tab", () -> click("实时曲线", "Live traces"), () -> integer(editor(), "tab") == 2, 30);
        step("trace history contains actual samples", () -> {}, () -> list(editor(), "history").size() >= 8 && liveEquals(4.875), 10);
        step("trace screenshot", () -> shot("live-output-curve"), () -> true, 3);
        step("return channels", () -> click("通道与设置", "Channels"), () -> integer(editor(), "tab") == 0, 2);
        step("invalid channel entered", () -> firstEdit().setValue("invalid channel"), () -> true, 2);
        step("server rejects invalid channel", () -> click("保存并应用", "Save & apply"),
                () -> !(boolean) field(editor(), "awaitingSave") && (boolean) field(editor(), "error"), 8);
        step("failed save preserves edits", () -> {}, () -> firstEdit().getValue().equals("invalid channel"), 10);
        step("restore channel", () -> firstEdit().setValue("ui_smoke"), () -> true, 2);
        step("valid channel saves again", () -> click("保存并应用", "Save & apply"), UiSmokeHarness::saved, 8);
        step("help screenshot", () -> click("使用说明", "Help"), () -> integer(editor(), "tab") == 3, 3);
        step("capture help", () -> shot("help"), () -> true, 3);
        step("close saved screen", () -> click("关闭", "Close"), () -> CLIENT.screen == null, 4);
        planPonder();
        step("view all thirteen fronts", () -> CLIENT.getSingleplayerServer().execute(() -> {
            ServerPlayer player = CLIENT.getSingleplayerServer().getPlayerList().getPlayers().get(0);
            player.getAbilities().flying = true;
            player.onUpdateAbilities();
            player.teleportTo(player.serverLevel(), 3.0, 86, 12.0, 180.0F, 35.0F);
        }), () -> CLIENT.player.getY() > 84, 10);
        step("world overview screenshot", () -> shot("all-thirteen-blocks"), () -> true, 6);
    }

    private static void planDetectorsAndQuick() {
        for (NodeKind kind : List.of(NodeKind.HEIGHT_SENSOR, NodeKind.SPEED_SENSOR, NodeKind.ATTITUDE_SENSOR)) {
            step("sensor mode picker " + kind, () -> { open(kind); }, () -> current(kind), 6);
            step("open mode choices " + kind, () -> clickPrefix("测量：", "Measure: "), () -> CLIENT.screen instanceof ChoiceScreen, 2);
            String[] choices = kind == NodeKind.HEIGHT_SENSOR ? new String[]{"相对归零高度", "Height from zero"}
                    : kind == NodeKind.SPEED_SENSOR ? new String[]{"世界 Y 速度", "World Y velocity"} : new String[]{"俯仰 Pitch", "Pitch"};
            step("choose detector component " + kind, () -> click(choices), () -> current(kind), 2);
            step("save detector mode " + kind, () -> click("保存并应用", "Save & apply"), UiSmokeHarness::saved, 8);
        }
        step("detector help", () -> click("使用说明", "Help"), () -> integer(editor(), "tab") == 3, 3);
        step("detector reference screenshot", () -> shot("detector-reference-help"), () -> true, 3);
        step("open quick editor", () -> open(NodeKind.QUICK_CONFIGURATOR), () -> current(NodeKind.QUICK_CONFIGURATOR), 8);
        step("edit actual ZPK gain", () -> editNamed("增益 K（零极点乘法系数）", "Gain K (ZPK multiplier)").setValue("2"), () -> field(CLIENT.screen,"gain").equals("2"), 2);
        step("edit actual ZPK pole", () -> editNamed("极点1 实部", "Pole1 real").setValue("-2"), () -> true, 2);
        step("add and remove zero", () -> click("+ 零点", "+ Zero"), () -> list(CLIENT.screen,"zeros").size() == 1, 2);
        step("remove added zero", () -> click("×"), () -> list(CLIENT.screen,"zeros").isEmpty(), 2);
        step("add and page second pole", () -> click("+ 极点", "+ Pole"), () -> list(CLIENT.screen,"poles").size() == 2, 2);
        step("remove second pole", () -> click("×"), () -> list(CLIENT.screen,"poles").size() == 1, 2);
        step("quick channels", () -> click("通道", "Channels"), () -> integer(CLIENT.screen,"tab") == 1, 2);
        step("connect quick reference", () -> editNamed("参考输入 A", "Reference input A").setValue("setpoint"), () -> true, 2);
        step("save theoretical closed loop", () -> click("保存并应用", "Save & apply"), UiSmokeHarness::saved, 100);
        step("quick server response and NULL ports", UiSmokeHarness::verifyQuick, () -> SERVER_RESULT.get().equals("quick_ok"), 10);
        step("quick channels screenshot", () -> shot("quick-channels-null"), () -> true, 3);
        step("quick transfer formula tab", () -> click("传递函数", "Transfer function"), () -> integer(CLIENT.screen,"tab") == 2, 3);
        step("quick formula screenshot", () -> shot("quick-formula-scale-2"), () -> true, 3);
        step("quick formula larger scale", () -> setScale(1), () -> CLIENT.getWindow().getGuiScaledWidth() == 854, 3);
        step("quick formula full screenshot", () -> shot("quick-formula-scale-1"), () -> true, 3);
        step("quick roots larger scale", () -> click("零极点", "Zeros / poles"), () -> integer(CLIENT.screen,"tab") == 0, 3);
        step("quick roots full screenshot", () -> shot("quick-roots-scale-1"), () -> true, 3);
        step("quick compact scale", () -> setScale(2), () -> CLIENT.getWindow().getGuiScaledWidth() == 427, 3);
        step("quick roots screenshot", () -> shot("quick-roots-scale-2"), () -> true, 3);
        step("quick preserves unsaved gain", () -> editNamed("增益 K（零极点乘法系数）", "Gain K (ZPK multiplier)").setValue("2.75"), () -> field(CLIENT.screen,"gain").equals("2.75"), 30);
        step("quick rejects nonfinite gain", () -> { editNamed("增益 K（零极点乘法系数）", "Gain K (ZPK multiplier)").setValue("NaN"); click("保存并应用", "Save & apply"); },
                () -> (boolean) field(CLIENT.screen,"error") && field(CLIENT.screen,"gain").equals("NaN"), 4);
        step("restore quick gain", () -> { editNamed("增益 K（零极点乘法系数）", "Gain K (ZPK multiplier)").setValue("2"); click("保存并应用", "Save & apply"); }, UiSmokeHarness::saved, 8);
        step("quick actual response curve", () -> click("响应曲线", "Response"), () -> integer(CLIENT.screen,"tab") == 3 && list(CLIENT.screen,"history").size() >= 10, 70);
        step("quick response screenshot", () -> shot("quick-response"), () -> true, 3);
    }

    private static EditBox editNamed(String... labels) {
        return CLIENT.screen.children().stream().filter(EditBox.class::isInstance).map(EditBox.class::cast)
                .filter(edit -> List.of(labels).contains(edit.getMessage().getString())).findFirst()
                .orElseThrow(() -> new IllegalStateException("Missing field " + List.of(labels)));
    }

    private static void verifyQuick() {
        SERVER_RESULT.set("checking_quick");
        CLIENT.getSingleplayerServer().execute(() -> {
            try {
                var block = (AutomationBlockEntity) CLIENT.getSingleplayerServer().overworld().getBlockEntity(POSITIONS.get(NodeKind.QUICK_CONFIGURATOR));
                var settings = block.getSettings();
                var quick = QuickSettingsCodec.fromJson(settings.getString("quick"));
                CompoundTag runtime = block.clientSnapshot();
                if (quick.gain() != 2 || quick.poles().size() != 1 || quick.poles().getFirst().real() != -2
                        || !quick.zeros().isEmpty() || !runtime.getBoolean("valid") || Math.abs(runtime.getDouble("value") - 1.625) > .0001)
                    throw new IllegalStateException("Quick saved response differs from 2/(s+4): " + runtime);
                for (String port : List.of("B","C","D"))
                    if (!settings.getString("input"+port).equals("NULL") || !runtime.getBoolean("unused"+port) || runtime.getBoolean("valid"+port))
                        throw new IllegalStateException("Unused port was treated as numerical data: " + port);
                SERVER_RESULT.set("quick_ok");
            } catch (Throwable error) { SERVER_RESULT.set("ERROR " + error); }
        });
    }

    private static void planPonder() {
        step("all thirteen native Ponder entries and Shift tooltips", () -> {
            for (NodeKind kind : NodeKind.values()) {
                var item = ModRegistry.NODES.get(kind).get().asItem();
                if (!PonderIndex.getSceneAccess().doScenesExistForId(AutomationPonderPlugin.id(kind.id())))
                    throw new IllegalStateException("Missing hold-W entry: " + kind);
                var description = ItemDescription.create(item, FontHelper.Palette.STANDARD_CREATE);
                if (description == null || description.linesOnShift().isEmpty())
                    throw new IllegalStateException("Missing Shift description: " + kind);
            }
            if (!I18n.exists("create_automation.ponder.shared.quick_feedback")) throw new IllegalStateException("Missing tutorial language");
        }, () -> true, 2);
        step("native item tooltip W and Shift prompt", () -> CLIENT.setScreen(new TooltipPreview(NodeKind.QUICK_CONFIGURATOR,false)),
                () -> ((TooltipPreview)CLIENT.screen).nativeLines().stream().anyMatch(line -> line.getString().contains("W")), 8);
        step("native tooltip prompt screenshot", () -> shot("tooltip-native-w-shift-prompt"), () -> true, 3);
        step("native expanded Create description", () -> CLIENT.setScreen(new TooltipPreview(NodeKind.QUICK_CONFIGURATOR,true)),
                () -> ((TooltipPreview)CLIENT.screen).nativeLines().stream().anyMatch(line -> line.getString().contains("L(s)")), 8);
        step("expanded description screenshot", () -> shot("tooltip-quick-expanded-description"), () -> true, 3);
        step("height native expanded description", () -> CLIENT.setScreen(new TooltipPreview(NodeKind.HEIGHT_SENSOR,true)), () -> true, 8);
        step("height tooltip screenshot", () -> shot("tooltip-height-expanded-description"), () -> true, 3);
        Map<String, NodeKind> scenes = new LinkedHashMap<>();
        scenes.put("signal_flow",NodeKind.CONSTANT); scenes.put("sensors",NodeKind.HEIGHT_SENSOR);
        scenes.put("graph",NodeKind.SYSTEM_BUILDER); scenes.put("redstone",NodeKind.REDSTONE_INPUT);
        scenes.put("quick_control",NodeKind.QUICK_CONFIGURATOR);
        scenes.forEach((scene,kind) -> {
            step("native Ponder opens " + scene, () -> CLIENT.setScreen(PonderUI.of(ModRegistry.NODES.get(kind).get().asItem().getDefaultInstance())), () -> CLIENT.screen instanceof PonderUI, 4);
            step("navigate native storyboard " + scene, () -> {
                var ponder = (PonderUI) CLIENT.screen;
                for (int i = 0; i < 5 && !ponder.getActiveScene().getId().getPath().equals(scene); i++) ponder.mouseScrolled(200,120,0,1);
                if (!ponder.getActiveScene().getId().getPath().equals(scene)) throw new IllegalStateException("Storyboard not found: " + scene);
                if (ponder.getActiveScene().getWorld().getBlockState(new BlockPos(0,0,0)).isAir()) throw new IllegalStateException("Empty Ponder structure: " + scene);
                ponder.seekToTime(scene.equals("sensors") ? 200 : 250);
            }, () -> CLIENT.screen instanceof PonderUI, 12);
            step("Ponder screenshot " + scene, () -> shot("ponder-" + scene + "-scale-2"), () -> true, 4);
        });
        step("Ponder large scale", () -> setScale(1), () -> CLIENT.screen instanceof PonderUI, 8);
        step("Ponder large screenshot", () -> shot("ponder-quick-control-scale-1"), () -> true, 3);
        step("restore compact scale after Ponder", () -> { CLIENT.setScreen(null); setScale(2); }, () -> CLIENT.screen == null, 3);
    }

    /** Preview native generated tooltip content; deliberately does not claim physical key injection. */
    private static final class TooltipPreview extends Screen {
        private final ItemStack stack;
        private final boolean expanded;
        TooltipPreview(NodeKind kind, boolean expanded) {
            super(Component.literal(expanded ? "原生 Create 介绍 · Shift 内容预览" : "原生物品提示 · W / Shift"));
            stack = ModRegistry.NODES.get(kind).get().asItem().getDefaultInstance(); this.expanded = expanded;
        }
        List<Component> nativeLines() {
            if (!expanded) return Screen.getTooltipFromItem(CLIENT,stack);
            List<Component> lines = new ArrayList<>();
            lines.add(stack.getHoverName());
            lines.addAll(ItemDescription.create(stack.getItem(),FontHelper.Palette.STANDARD_CREATE).linesOnShift());
            PonderTooltipHandler.addToTooltip(lines,stack);
            return lines;
        }
        @Override public void renderBackground(GuiGraphics g,int x,int y,float partialTick) { }
        @Override public void render(GuiGraphics g,int x,int y,float partialTick) {
            g.fill(0,0,width,height,0xFF1A222B);
            g.drawString(font,title,12,14,0xF0D49A,false);
            g.drawString(font,"测试内容来自 Create / Ponder 原生提示处理器",12,30,0x9DAFB9,false);
            g.renderItem(stack,24,65);
            if (expanded) g.renderComponentTooltip(font,nativeLines(),58,65,stack);
            else g.renderTooltip(font,stack,58,65);
        }
        @Override public boolean isPauseScreen() { return false; }
    }

    private static void open(NodeKind kind) {
        CLIENT.getSingleplayerServer().execute(() -> {
            ServerPlayer player = CLIENT.getSingleplayerServer().getPlayerList().getPlayers().get(0);
            var block = (AutomationBlockEntity) player.serverLevel().getBlockEntity(POSITIONS.get(kind));
            AutomationNetwork.open(player, block);
        });
    }

    private static boolean current(NodeKind kind) {
        return kind == NodeKind.QUICK_CONFIGURATOR ? CLIENT.screen instanceof QuickConfiguratorScreen
                : CLIENT.screen instanceof AutomationScreen && field(CLIENT.screen, "kind").equals(kind.name());
    }

    private static AutomationScreen editor() {
        if (!(CLIENT.screen instanceof AutomationScreen screen)) throw new IllegalStateException("Expected editor, got " + CLIENT.screen);
        return screen;
    }

    private static boolean saved() {
        if (!(CLIENT.screen instanceof AutomationEditorScreen)) return false;
        Screen screen = CLIENT.screen;
        return !(boolean) field(screen, "awaitingSave") && !(boolean) field(screen, "error")
                && ((String) field(screen, "message")).matches("^(已保存|Saved).*");
    }

    private static boolean liveEquals(double expected) {
        CompoundTag snapshot = (CompoundTag) field(editor(), "telemetry");
        return snapshot.getBoolean("valid") && Math.abs(snapshot.getDouble("value") - expected) < 1e-9;
    }

    private static void verifyServerGraph(double gain) {
        SERVER_RESULT.set("checking_graph");
        CLIENT.getSingleplayerServer().execute(() -> {
            try {
                var level = CLIENT.getSingleplayerServer().overworld();
                var builder = (AutomationBlockEntity) level.getBlockEntity(POSITIONS.get(NodeKind.SYSTEM_BUILDER));
                var graph = GraphCodec.fromJson(builder.getSettings().getString("graph"));
                boolean correct = graph.nodes().stream().anyMatch(node -> node.id().equals(graph.output())
                        && node.op().name().equals("GAIN") && Math.abs(node.parameters().get("gain") - gain) < 1e-9);
                CompoundTag snapshot = builder.clientSnapshot();
                if (!correct || !snapshot.getBoolean("valid") || Math.abs(snapshot.getDouble("value") - 4.875) > 1e-9)
                    throw new IllegalStateException("Edited graph not applied: " + snapshot);
                SERVER_RESULT.set("graph_ok");
            } catch (Throwable exception) { SERVER_RESULT.set("ERROR " + exception); }
        });
    }

    private static int nodeCount() { return list(editor(), "nodes").size(); }
    private static List<?> list(Object object, String name) { return (List<?>) field(object, name); }
    private static int integer(Object object, String name) { return (int) field(object, name); }
    private static Object field(Object object, String name) {
        try { Field field = object.getClass().getDeclaredField(name); field.setAccessible(true); return field.get(object); }
        catch (ReflectiveOperationException exception) { throw new IllegalStateException(exception); }
    }

    private static Button firstButton() {
        return CLIENT.screen.children().stream().filter(Button.class::isInstance).map(Button.class::cast)
                .filter(button -> button.active).findFirst().orElseThrow();
    }

    private static EditBox firstEdit() {
        return CLIENT.screen.children().stream().filter(EditBox.class::isInstance).map(EditBox.class::cast).findFirst().orElseThrow();
    }

    private static EditBox onlyEdit() {
        List<EditBox> fields = CLIENT.screen.children().stream().filter(EditBox.class::isInstance).map(EditBox.class::cast).toList();
        if (fields.size() != 1) throw new IllegalStateException("Expected one parameter field, got " + fields.size());
        return fields.get(0);
    }

    private static void click(String... labels) { clickMatching(false, labels); }
    private static void clickPrefix(String... prefixes) { clickMatching(true, prefixes); }
    private static void clickMatching(boolean prefix, String... choices) {
        Screen screen = CLIENT.screen;
        for (var child : screen.children()) if (child instanceof Button button && button.active) {
            String text = button.getMessage().getString();
            for (String choice : choices) if (prefix ? text.startsWith(choice) : text.equals(choice)) {
                button.onPress(); return;
            }
        }
        throw new IllegalStateException("Missing active button " + List.of(choices) + " in " + screen.getClass().getSimpleName());
    }

    private static void shot(String name) {
        String file = "ui-smoke-" + name + ".png";
        Screenshot.grab(CLIENT.gameDirectory, file, CLIENT.getMainRenderTarget(), component -> {});
        SHOTS.add("screenshots/" + file);
    }

    private static void setScale(int scale) {
        CLIENT.options.guiScale().set(scale);
        CLIENT.resizeDisplay();
        LAYOUTS.add(Map.of("scale", scale, "width", CLIENT.getWindow().getGuiScaledWidth(),
                "height", CLIENT.getWindow().getGuiScaledHeight()));
    }

    private static void step(String name, Runnable action, BooleanSupplier check, int delay) {
        STEPS.add(new Step(name, action, check, delay));
    }

    private static void fail(String reason) {
        finished = true;
        try { shot("failure"); } catch (Throwable ignored) { }
        report("failed", reason);
    }

    private static void report(String state, String failure) {
        try {
            Map<String, Object> report = new LinkedHashMap<>();
            report.put("status", state); report.put("checks", RESULTS); report.put("screenshots", SHOTS);
            report.put("layouts", LAYOUTS);
            report.put("testOnlySystemProperty", "create_automation.uiSmoke=true");
            report.put("tooltipValidation", "Native W/Shift prompt rendering and expanded Create description; no physical keyboard hold simulated");
            report.put("isolatedDirectory", CLIENT.gameDirectory.toString());
            report.put("framebufferWidth", CLIENT.getWindow().getWidth());
            report.put("framebufferHeight", CLIENT.getWindow().getHeight());
            report.put("guiWidth", CLIENT.getWindow().getGuiScaledWidth());
            report.put("guiHeight", CLIENT.getWindow().getGuiScaledHeight());
            if (failure != null) report.put("failure", failure);
            Files.writeString(CLIENT.gameDirectory.toPath().resolve("ui-smoke-report.json"),
                    new GsonBuilder().setPrettyPrinting().create().toJson(report), StandardCharsets.UTF_8);
        } catch (Exception exception) { throw new IllegalStateException("Could not write isolated UI test report", exception); }
    }

    private record Step(String name, Runnable action, BooleanSupplier check, int delay) {}
}
