package dev.createautomation.client.ponder;

import dev.createautomation.registry.ModRegistry;
import dev.createautomation.world.NodeKind;
import net.createmod.ponder.api.registration.PonderPlugin;
import net.createmod.ponder.api.registration.PonderSceneRegistrationHelper;
import net.createmod.ponder.api.registration.PonderTagRegistrationHelper;
import net.createmod.ponder.api.registration.SharedTextRegistrationHelper;
import net.minecraft.resources.ResourceLocation;
import java.util.Arrays;

/** Native Ponder registration; these entries also provide the standard hold-W item prompt. */
public final class AutomationPonderPlugin implements PonderPlugin {
    public static ResourceLocation id(String path) { return ResourceLocation.fromNamespaceAndPath("create_automation", path); }
    @Override public String getModId() { return "create_automation"; }

    @Override public void registerScenes(PonderSceneRegistrationHelper<ResourceLocation> helper) {
        var h = helper.withKeyFunction((NodeKind kind) -> id(kind.id()));
        h.forComponents(Arrays.asList(NodeKind.values())).addStoryBoard("signal_flow", AutomationScenes::signalFlow, id("signals"));
        h.forComponents(NodeKind.MOTION_SENSOR, NodeKind.HEIGHT_SENSOR, NodeKind.SPEED_SENSOR, NodeKind.ATTITUDE_SENSOR, NodeKind.RPM_SENSOR)
                .addStoryBoard("sensors", AutomationScenes::sensors, id("signals"));
        h.forComponents(NodeKind.SYSTEM_BUILDER, NodeKind.CONSTANT, NodeKind.SYSTEM_OUTPUT, NodeKind.MONITOR)
                .addStoryBoard("graph", AutomationScenes::graph, id("control"));
        h.forComponents(NodeKind.REDSTONE_INPUT, NodeKind.REDSTONE_OUTPUT)
                .addStoryBoard("redstone", AutomationScenes::redstone, id("actuators"));
        h.forComponents(NodeKind.QUICK_CONFIGURATOR, NodeKind.RPM_OUTPUT)
                .addStoryBoard("quick_control", AutomationScenes::quickControl, id("control"), id("actuators"));
    }

    @Override public void registerTags(PonderTagRegistrationHelper<ResourceLocation> helper) {
        helper.registerTag("signals").title("Continuous signals").description("Measure and route precise numerical signals")
                .item(ModRegistry.NODES.get(NodeKind.HEIGHT_SENSOR).get()).addToIndex().register();
        helper.registerTag("control").title("Control systems").description("Build a graph or configure a transfer function")
                .item(ModRegistry.NODES.get(NodeKind.SYSTEM_BUILDER).get()).addToIndex().register();
        helper.registerTag("actuators").title("Outputs and interfaces").description("Drive Create rotation and connect redstone")
                .item(ModRegistry.NODES.get(NodeKind.RPM_OUTPUT).get()).addToIndex().register();
        for (NodeKind kind : NodeKind.values()) helper.addTagToComponent(id(kind.id()), id("signals"));
        for (NodeKind kind : new NodeKind[]{NodeKind.SYSTEM_BUILDER, NodeKind.QUICK_CONFIGURATOR, NodeKind.CONSTANT, NodeKind.MONITOR})
            helper.addTagToComponent(id(kind.id()), id("control"));
        for (NodeKind kind : new NodeKind[]{NodeKind.RPM_OUTPUT, NodeKind.SYSTEM_OUTPUT, NodeKind.REDSTONE_INPUT, NodeKind.REDSTONE_OUTPUT})
            helper.addTagToComponent(id(kind.id()), id("actuators"));
    }

    @Override public void registerSharedText(SharedTextRegistrationHelper helper) { AutomationPonderText.register(helper); }
}
