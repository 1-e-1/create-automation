package dev.createautomation.client;

import dev.createautomation.client.ponder.AutomationPonderPlugin;
import dev.createautomation.network.AutomationNetwork;
import dev.createautomation.registry.ModRegistry;
import dev.createautomation.world.NodeKind;
import com.simibubi.create.foundation.item.ItemDescription;
import com.simibubi.create.foundation.item.TooltipModifier;
import net.createmod.catnip.lang.FontHelper;
import net.createmod.ponder.foundation.PonderIndex;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.fml.event.lifecycle.FMLClientSetupEvent;

/** This class is discovered only on a physical client; common setup never resolves it. */
@EventBusSubscriber(modid = "create_automation", bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class ClientBootstrap {
    private static AutomationEditorScreen activeEditor;
    private ClientBootstrap() {}

    @SubscribeEvent
    public static void setup(FMLClientSetupEvent event) {
        // Same lifecycle used by Create 6.0.10: plugin registration precedes Ponder's reload.
        PonderIndex.addPlugin(new AutomationPonderPlugin());
        event.enqueueWork(() -> {
            for (NodeKind kind : NodeKind.values()) {
                var item = ModRegistry.NODES.get(kind).get().asItem();
                TooltipModifier.REGISTRY.register(item, new ItemDescription.Modifier(item, FontHelper.Palette.STANDARD_CREATE));
            }
            if (Boolean.getBoolean("create_automation.uiSmoke")) UiSmokeHarness.install();
            AutomationNetwork.setClientReceivers(packet -> {
                Minecraft client = Minecraft.getInstance();
                try {
                    var snapshot = AutomationNetwork.parse(packet.snapshot());
                    Screen screen = packet.kind().equals("QUICK_CONFIGURATOR")
                            ? new QuickConfiguratorScreen(packet.pos(), packet.dimension(), snapshot)
                            : new AutomationScreen(packet.pos(), packet.dimension(), packet.kind(), snapshot);
                    activeEditor = (AutomationEditorScreen) screen;
                    client.setScreen(screen);
                } catch (Exception exception) {
                    if (client.player != null) client.player.displayClientMessage(
                            Component.literal("Create: Automation — " + exception.getMessage()), false);
                }
            }, packet -> {
                // Modal node pickers and confirmations retain their parent receiver.
                if (activeEditor != null) activeEditor.receive(packet);
            });
        });
    }
}
