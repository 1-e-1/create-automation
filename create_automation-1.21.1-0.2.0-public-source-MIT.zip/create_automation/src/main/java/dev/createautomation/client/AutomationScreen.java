package dev.createautomation.client;

import dev.createautomation.engine.ControlEngine;
import dev.createautomation.engine.Graph;
import dev.createautomation.engine.GraphCodec;
import dev.createautomation.engine.Node;
import dev.createautomation.engine.Op;
import dev.createautomation.network.AutomationNetwork;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.client.gui.screens.ConfirmScreen;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.function.Consumer;

/** A live configuration screen. Polling only replaces telemetry, never the editable draft. */
public final class AutomationScreen extends Screen implements AutomationEditorScreen {
    private static final int TEXT = 0xDFE8EC, MUTED = 0x9DAFB9, GOLD = 0xF0D49A;
    private static final int[] TRACE_COLORS = {0xFF62D8AD, 0xFFFFC86B, 0xFF72B6FF, 0xFFD997FF, 0xFFFF8D9D};
    private static final List<String> MOTION_MODES = List.of("HEIGHT", "VELOCITY_X", "VELOCITY_Y", "VELOCITY_Z", "SPEED",
            "ROLL", "PITCH", "YAW", "ANGULAR_X", "ANGULAR_Y", "ANGULAR_Z");
    private final BlockPos pos;
    private final String dimension;
    private final String kind;
    private final CompoundTag originalSettings;
    private CompoundTag telemetry;
    private final Map<String, String> values = new LinkedHashMap<>();
    private final List<EditableNode> nodes = new ArrayList<>();
    private final List<Label> labels = new ArrayList<>();
    private final List<Sample> history = new ArrayList<>();
    private final boolean[] traces = {true, false, false, false, false};
    private String output = "";
    private String message = "";
    private boolean error;
    private boolean enabled;
    private boolean dirty;
    private boolean awaitingSave;
    private long revision;
    private long sentRevision;
    private int tab;
    private int selected;
    private int graphRow;
    private int parameterIndex;
    private int ticks;
    private int saveStartedAt;
    private int horizon = 300;
    private long lastSampleTick = Long.MIN_VALUE;

    public AutomationScreen(BlockPos pos, String dimension, String kind, CompoundTag snapshot) {
        super(Component.translatable("block.create_automation." + kind.toLowerCase(Locale.ROOT)));
        this.pos = pos.immutable();
        this.dimension = dimension;
        this.kind = kind;
        telemetry = snapshot.copy();
        originalSettings = snapshot.getCompound("settings").copy();
        enabled = !originalSettings.contains("enabled") || originalSettings.getBoolean("enabled");
        for (String key : List.of("network", "inputA", "inputB", "inputC", "inputD", "output", "mode"))
            values.put(key, originalSettings.getString(key));
        for (String key : List.of("constant", "scale", "offset", "min", "max"))
            values.put(key, Double.toString(originalSettings.getDouble(key)));
        if (kind.equals("SYSTEM_BUILDER")) {
            try { loadGraph(GraphCodec.fromJson(originalSettings.getString("graph"))); }
            catch (RuntimeException exception) {
                loadGraph(GraphCodec.preset("passthrough"));
                setMessage(tr("原图无法读取，请检查后保存", "Could not read graph; check it before saving"), true);
            }
        }
        sample(snapshot);
    }

    static String tr(String chinese, String english) {
        return Minecraft.getInstance().getLanguageManager().getSelected().startsWith("zh") ? chinese : english;
    }

    private boolean builder() { return kind.equals("SYSTEM_BUILDER"); }

    private List<String> motionModes() {
        return switch (kind) {
            case "MOTION_SENSOR" -> MOTION_MODES;
            case "HEIGHT_SENSOR" -> List.of("WORLD_Y", "RELATIVE_HEIGHT");
            case "SPEED_SENSOR" -> List.of("SPEED", "VELOCITY_X", "VELOCITY_Y", "VELOCITY_Z");
            case "ATTITUDE_SENSOR" -> List.of("ROLL", "PITCH", "YAW");
            default -> List.of();
        };
    }

    private static String modeLabel(String mode) {
        return switch (mode) {
            case "WORLD_Y" -> tr("世界高度 Y", "World height Y");
            case "RELATIVE_HEIGHT" -> tr("相对归零高度", "Height from zero");
            case "HEIGHT" -> tr("原检测器点位相对高度", "Legacy point height");
            case "SPEED" -> tr("合速度", "Speed magnitude");
            case "VELOCITY_X" -> tr("世界 X 速度", "World X velocity");
            case "VELOCITY_Y" -> tr("世界 Y 速度", "World Y velocity");
            case "VELOCITY_Z" -> tr("世界 Z 速度", "World Z velocity");
            case "ROLL" -> tr("横滚 Roll", "Roll");
            case "PITCH" -> tr("俯仰 Pitch", "Pitch");
            case "YAW" -> tr("偏航 Yaw", "Yaw");
            default -> mode;
        };
    }

    @Override
    protected void init() {
        clearWidgets();
        labels.clear();
        String[] tabs = {tr("通道与设置", "Channels"), tr("系统构建", "Build graph"), tr("实时曲线", "Live traces"), tr("使用说明", "Help")};
        int count = builder() ? 4 : 3;
        int tabWidth = (width - 16) / count;
        int slot = 0;
        for (int index = 0; index < tabs.length; index++) {
            if (index == 1 && !builder()) continue;
            int target = index;
            button(8 + slot++ * tabWidth, 40, tabWidth - 3, 18, tabs[index], b -> { tab = target; init(); }).active = tab != index;
        }
        button(8, height - 24, 100, 20, enabled ? tr("运行：开启", "Enabled: ON") : tr("运行：关闭", "Enabled: OFF"), b -> {
            enabled = !enabled; changed(); init();
        }).setTooltip(Tooltip.create(Component.literal(tr("保存后生效；关闭时输出为零", "Applied on Save; disabled outputs go to zero"))));
        button(width - 192, height - 24, 88, 20, tr("保存并应用", "Save & apply"), b -> save(false));
        button(width - 96, height - 24, 88, 20, tr("关闭", "Close"), b -> onClose());
        if (tab == 0) initSettings();
        else if (tab == 1) initGraph();
        else if (tab == 2) initTraces();
    }

    private Button button(int x, int y, int w, int h, String text, Button.OnPress action) {
        return addRenderableWidget(Button.builder(Component.literal(text), action).bounds(x, y, w, h).build());
    }

    private EditBox edit(int x, int y, int w, String content, int maxLength, Consumer<String> onChange) {
        EditBox field = new EditBox(font, x, y, w, 18, Component.literal(content));
        field.setMaxLength(maxLength);
        field.setValue(content);
        field.setResponder(onChange);
        addRenderableWidget(field);
        return field;
    }

    private void initSettings() {
        List<String> keys = new ArrayList<>(List.of("network"));
        if (builder()) keys.addAll(List.of("inputA", "inputB", "inputC", "inputD", "output"));
        else {
            if (List.of("SYSTEM_OUTPUT", "RPM_OUTPUT", "REDSTONE_OUTPUT", "MONITOR").contains(kind)) keys.add("inputA");
            if (!List.of("RPM_OUTPUT", "REDSTONE_OUTPUT", "MONITOR").contains(kind)) keys.add("output");
            if (kind.equals("CONSTANT")) keys.add("constant");
            if (!kind.equals("MONITOR")) keys.addAll(List.of("scale", "offset", "min", "max"));
        }
        int columnWidth = (width - 24) / 2;
        for (int index = 0; index < keys.size(); index++) {
            String key = keys.get(index);
            int x = 8 + index % 2 * (columnWidth + 8);
            int y = 66 + index / 2 * 30;
            labels.add(new Label(x, y, settingLabel(key), MUTED));
            EditBox field = edit(x, y + 11, columnWidth, values.getOrDefault(key, ""), key.startsWith("input") || key.equals("output") || key.equals("network") ? 48 : 32,
                    text -> { values.put(key, text); changed(); });
            field.setTooltip(Tooltip.create(Component.literal(settingHelp(key))));
        }
        List<String> modes = motionModes();
        if (!modes.isEmpty()) {
            button(8, 169, columnWidth, 18, tr("测量：", "Measure: ") + modeLabel(values.get("mode")), b ->
                    minecraft.setScreen(new ChoiceScreen(this, tr("选择测量量", "Choose measurement"), modes.stream().map(AutomationScreen::modeLabel).toList(), index -> {
                        values.put("mode", modes.get(index)); changed();
                    })));
            if (kind.equals("MOTION_SENSOR") || kind.equals("HEIGHT_SENSOR"))
                button(16 + columnWidth, 169, columnWidth, 18, tr("保存并校准高度零点", "Save & zero height"), b -> save(true));
        }
    }

    private static String settingLabel(String key) {
        return switch (key) {
            case "network" -> tr("网络名称", "Network name");
            case "inputA" -> tr("输入 A 通道", "Input A channel");
            case "inputB" -> tr("输入 B 通道", "Input B channel");
            case "inputC" -> tr("输入 C 通道", "Input C channel");
            case "inputD" -> tr("输入 D 通道", "Input D channel");
            case "output" -> tr("发布通道", "Publish channel");
            case "constant" -> tr("常数 / 目标值", "Constant / setpoint");
            case "scale" -> tr("比例系数", "Scale");
            case "offset" -> tr("偏移量", "Offset");
            case "min" -> tr("输出下限", "Lower limit");
            case "max" -> tr("输出上限", "Upper limit");
            default -> key;
        };
    }

    private static String settingHelp(String key) {
        return switch (key) {
            case "network" -> tr("同维度、同网络的同名通道相连。支持字母、数字、_、-、.、/。", "Same dimension + network + channel connects blocks. Use letters, numbers, _, -, ., /." );
            case "inputA", "inputB", "inputC", "inputD" -> tr("填写源方块的发布通道。NULL 或留空表示未使用，不订阅信号，也不代表数值 0。", "Enter the source publish channel. NULL or blank means unused: no subscription, not a numeric zero.");
            case "output" -> tr("其他方块用此名称订阅信号。转速单位 RPM；位置单位方块。", "Other blocks subscribe using this name. Rotation: RPM; position: blocks.");
            case "scale", "offset", "min", "max" -> tr("结果 = clamp(输入 × 比例 + 偏移, 下限, 上限)。红石输出再取整到 0–15。", "Result = clamp(input * scale + offset, min, max). Redstone output is then rounded to 0–15.");
            default -> tr("可输入小数和科学计数法，例如 0.125 或 1e-3。", "Decimals and scientific notation are supported, e.g. 0.125 or 1e-3.");
        };
    }

    private void initGraph() {
        int toolbarWidth = (width - 16) / 4;
        button(8, 62, toolbarWidth - 3, 18, tr("+ 节点", "+ Node"), b -> chooseNewNode()).active = nodes.size() < 64;
        button(8 + toolbarWidth, 62, toolbarWidth - 3, 18, tr("删除节点", "Delete node"), b -> deleteNode()).active = !nodes.isEmpty();
        button(8 + toolbarWidth * 2, 62, toolbarWidth - 3, 18, tr("设为输出", "Use as output"), b -> {
            if (!nodes.isEmpty()) { output = nodes.get(selected).id; changed(); }
        }).active = !nodes.isEmpty();
        button(8 + toolbarWidth * 3, 62, toolbarWidth - 3, 18, tr("载入预设", "Load preset"), b -> choosePreset());
        selected = Math.max(0, Math.min(selected, nodes.size() - 1));
        if (nodes.isEmpty()) return;
        EditableNode node = nodes.get(selected);
        int x = width - 178;
        labels.add(new Label(x, 86, node.id + (node.id.equals(output) ? "  → OUT" : ""), GOLD));
        button(x, 98, 170, 18, opLabel(node.op), b -> minecraft.setScreen(new ChoiceScreen(this,
                tr("选择节点运算", "Choose node operation"), Arrays.stream(Op.values()).map(AutomationScreen::opLabel).toList(), index -> {
                    node.setOperation(Op.values()[index], nodes); parameterIndex = 0; changed();
                })));
        for (int port = 0; port < Math.min(2, node.inputs.size()); port++) {
            int input = port;
            String label = node.op == Op.PID ? (port == 0 ? tr("目标", "Target") : tr("测量", "Measured")) : tr("输入", "Input") + (port + 1);
            button(x, 120 + port * 22, 170, 18, label + " ← " + node.inputs.get(port), b -> chooseInput(node, input));
        }
        if (!node.parameters.isEmpty()) {
            List<String> keys = new ArrayList<>(node.parameters.keySet());
            parameterIndex = Math.floorMod(parameterIndex, keys.size());
            String key = keys.get(parameterIndex);
            button(x, 166, 74, 18, key + " ▸", b -> { parameterIndex++; init(); })
                    .setTooltip(Tooltip.create(Component.literal(parameterHelp(node.op, key))));
            edit(x + 78, 166, 92, node.parameters.get(key), 32, text -> { node.parameters.put(key, text); changed(); })
                    .setTooltip(Tooltip.create(Component.literal(parameterHelp(node.op, key))));
        }
    }

    private static String parameterHelp(Op op, String key) {
        return switch (key) {
            case "port" -> tr("INPUT 外部端口：0=A，1=B，2=C，3=D。点击左边参数名切换参数。", "INPUT external port: 0=A, 1=B, 2=C, 3=D. Click the parameter name to cycle parameters.");
            case "kp", "ki", "kd" -> tr("PID 参数；微分作用于测量值；含积分抗饱和。点击参数名切换 kp/ki/kd/min/max。", "PID gain; derivative on measurement, integral anti-windup. Click the name to cycle kp/ki/kd/min/max.");
            case "tau" -> tr("低通滤波时间常数，单位模拟秒。", "Low-pass time constant in simulated seconds.");
            case "initial" -> tr("初始化 / 复位值。DELAY 输出上一采样步的输入，允许构成反馈环。", "Initial / reset value. DELAY emits the previous step and allows feedback loops.");
            default -> tr("点击左侧参数名切换参数；数值支持小数。", "Click the parameter name to cycle parameters. Decimal values are supported.");
        };
    }

    private static String opLabel(Op op) {
        return switch (op) {
            case INPUT -> tr("INPUT 外部输入", "INPUT External input");
            case CONSTANT -> tr("CONSTANT 常数", "CONSTANT Constant");
            case ADD -> tr("ADD 加法", "ADD Sum");
            case SUBTRACT -> tr("SUBTRACT 减法", "SUBTRACT Difference");
            case MULTIPLY -> tr("MULTIPLY 乘法", "MULTIPLY Product");
            case DIVIDE -> tr("DIVIDE 除法", "DIVIDE Quotient");
            case GAIN -> tr("GAIN 比例增益", "GAIN Gain");
            case CLAMP -> tr("CLAMP 限幅", "CLAMP Saturation");
            case PID -> tr("PID 控制器", "PID Controller");
            case INTEGRATE -> tr("INTEGRATE 积分", "INTEGRATE Integral");
            case DERIVATIVE -> tr("DERIVATIVE 微分", "DERIVATIVE Derivative");
            case LOW_PASS -> tr("LOW_PASS 低通", "LOW_PASS Filter");
            case DELAY -> tr("DELAY 单步延迟", "DELAY One-step delay");
            case NEGATE -> tr("NEGATE 取负", "NEGATE Negation");
            case ABS -> tr("ABS 绝对值", "ABS Absolute value");
            case MIN -> tr("MIN 较小值", "MIN Minimum");
            case MAX -> tr("MAX 较大值", "MAX Maximum");
        };
    }

    private void chooseNewNode() {
        minecraft.setScreen(new ChoiceScreen(this, tr("添加运算节点", "Add operation node"),
                Arrays.stream(Op.values()).map(AutomationScreen::opLabel).toList(), index -> {
                    String id = nextId();
                    EditableNode node = new EditableNode(id);
                    node.setOperation(Op.values()[index], nodes);
                    nodes.add(node); selected = nodes.size() - 1;
                    if (output.isEmpty()) output = id;
                    graphRow = Math.max(0, selected / 2 - visibleRows() + 1);
                    parameterIndex = 0; changed();
                }));
    }

    private String nextId() {
        int id = 1;
        while (true) {
            String candidate = "n" + id++;
            if (nodes.stream().noneMatch(node -> node.id.equals(candidate))) return candidate;
        }
    }

    private void chooseInput(EditableNode node, int input) {
        List<String> ids = nodes.stream().map(item -> item.id).toList();
        List<String> choices = nodes.stream().map(item -> item.id + ": " + item.op.name()).toList();
        minecraft.setScreen(new ChoiceScreen(this, tr("连接到输入节点（自环需含 DELAY）", "Connect input (feedback requires DELAY)"), choices, index -> {
            node.inputs.set(input, ids.get(index)); changed();
        }));
    }

    private void deleteNode() {
        if (nodes.isEmpty()) return;
        String id = nodes.get(selected).id;
        if (nodes.stream().anyMatch(node -> !node.id.equals(id) && node.inputs.contains(id))) {
            setMessage(tr("其他节点仍连接此节点，请先改接输入", "Reconnect dependent inputs before deleting this node"), true);
            return;
        }
        nodes.remove(selected);
        if (output.equals(id)) output = nodes.isEmpty() ? "" : nodes.get(0).id;
        selected = Math.max(0, selected - 1); parameterIndex = 0;
        graphRow = Math.min(graphRow, Math.max(0, (nodes.size() + 1) / 2 - visibleRows()));
        changed(); init();
    }

    private void choosePreset() {
        List<String> names = List.of("passthrough", "pid", "sum", "altitude");
        List<String> labels = List.of(tr("直通 A", "Pass through A"), tr("PID：A 目标 / B 测量", "PID: A target / B measured"),
                tr("求和 A+B", "Sum A+B"), tr("定高：A 目标 B 高度 C 速度", "Altitude: A target B height C speed"));
        minecraft.setScreen(new ChoiceScreen(this, tr("预设将替换当前节点图", "Preset replaces the current graph"), labels, index ->
                minecraft.setScreen(new ConfirmScreen(confirmed -> {
                    if (confirmed) { loadGraph(GraphCodec.preset(names.get(index))); changed(); }
                    minecraft.setScreen(this);
                }, Component.literal(tr("替换当前节点图？", "Replace the current graph?")),
                        Component.literal(labels.get(index) + tr("。预设仅为起点，需按载具调参。", ". Presets are starting points; tune for your vehicle."))))));
    }

    private void loadGraph(Graph graph) {
        nodes.clear();
        for (Node node : graph.nodes()) nodes.add(new EditableNode(node));
        output = graph.output(); selected = 0; graphRow = 0; parameterIndex = 0;
    }

    private Graph graph() {
        List<Node> result = new ArrayList<>();
        for (EditableNode node : nodes) {
            Map<String, Double> parameters = new LinkedHashMap<>();
            node.parameters.forEach((key, value) -> parameters.put(key, finite(value, node.id + "." + key)));
            result.add(new Node(node.id, node.op, List.copyOf(node.inputs), parameters));
        }
        Graph graph = new Graph(result, output);
        ControlEngine.validate(graph);
        return graph;
    }

    private static double finite(String value, String key) {
        try {
            double result = Double.parseDouble(value.trim());
            if (!Double.isFinite(result)) throw new NumberFormatException();
            return result;
        } catch (NumberFormatException exception) {
            throw new IllegalArgumentException(key + tr(" 必须是有限数值", " must be a finite number"));
        }
    }

    private void save(boolean calibrate) {
        if (awaitingSave) return;
        try {
            CompoundTag settings = originalSettings.copy();
            for (Map.Entry<String, String> entry : values.entrySet()) {
                String key = entry.getKey();
                if (List.of("constant", "scale", "offset", "min", "max").contains(key)) settings.putDouble(key, finite(entry.getValue(), key));
                else settings.putString(key, entry.getValue().trim());
            }
            settings.putBoolean("enabled", enabled);
            if (builder()) settings.putString("graph", GraphCodec.toJson(graph()));
            if (calibrate) settings.putBoolean("calibrate", true);
            AutomationNetwork.save(pos, dimension, settings);
            awaitingSave = true; sentRevision = revision; saveStartedAt = ticks;
            setMessage(tr("正在应用…", "Applying…"), false);
        } catch (Exception exception) { setMessage(exception.getMessage(), true); }
    }

    public void receive(AutomationNetwork.SnapshotPayload packet) {
        if (!pos.equals(packet.pos()) || !dimension.equals(packet.dimension())) return;
        try {
            CompoundTag next = AutomationNetwork.parse(packet.snapshot());
            if (next.contains("value")) { telemetry = next; sample(next); }
            if (packet.acknowledgement()) {
                awaitingSave = false;
                if (packet.message().equals("saved")) {
                    if (revision == sentRevision) dirty = false;
                    setMessage(tr("已保存，控制器状态已复位", "Saved; controller state reset"), false);
                } else setMessage(translateStatus(packet.message()), true);
            } else if (!packet.message().isEmpty()) {
                setMessage(translateStatus(packet.message()), true);
                if (packet.message().equals("out_of_range")) {
                    telemetry = telemetry.copy();
                    telemetry.putBoolean("valid", false);
                    telemetry.putString("status", translateStatus(packet.message()));
                }
            }
        } catch (Exception exception) {
            awaitingSave = false;
            setMessage(tr("状态数据读取失败", "Could not read status data"), true);
        }
    }

    private static String translateStatus(String text) {
        return switch (text) {
            case "no_permission" -> tr("无法修改：距离过远、方块未加载或没有建造权限", "Cannot edit: out of range, unloaded block or no build permission");
            case "out_of_range" -> tr("方块未加载或已离开 8 格操作范围", "Block is unloaded or outside the 8-block interaction range");
            case "too_fast" -> tr("操作太快，请稍后再保存", "Please wait a moment before saving again");
            default -> text;
        };
    }

    private void sample(CompoundTag data) {
        long tick = data.contains("sampleTick") ? data.getLong("sampleTick") : ticks;
        if (tick == lastSampleTick) return;
        lastSampleTick = tick;
        double[] samples = new double[5];
        boolean[] valid = new boolean[5];
        samples[0] = data.getDouble("value"); valid[0] = data.getBoolean("valid") && Double.isFinite(samples[0]);
        for (int i = 1; i < 5; i++) {
            String key = String.valueOf((char) ('a' + i - 1));
            samples[i] = data.getDouble(key);
            valid[i] = data.getBoolean("valid" + key.toUpperCase(Locale.ROOT)) && Double.isFinite(samples[i]);
        }
        history.add(new Sample(tick, samples, valid));
        if (history.size() > 300) history.remove(0);
    }

    private void changed() { dirty = true; revision++; }
    private void setMessage(String text, boolean error) { message = text == null ? "" : text; this.error = error; }

    @Override
    public void tick() {
        ticks++;
        if (minecraft.player == null || minecraft.level == null || !minecraft.level.dimension().location().toString().equals(dimension)) {
            minecraft.setScreen(null); return;
        }
        if (ticks % 4 == 0) AutomationNetwork.request(pos, dimension);
        if (awaitingSave && ticks - saveStartedAt >= 100) {
            // A delayed acknowledgement must not lock the GUI permanently.
            awaitingSave = false;
            setMessage(tr("等待响应超时，可重试保存；草稿已保留", "Save acknowledgement timed out; draft kept. You may retry."), true);
        }
    }

    private void initTraces() {
        int w = Math.min(70, (width - 90) / 5);
        for (int i = 0; i < 5; i++) {
            int index = i;
            String name = i == 0 ? tr("输出", "OUT") : String.valueOf((char) ('A' + i - 1));
            button(8 + i * w, 64, w - 3, 18, (traces[i] ? "● " : "○ ") + name, b -> { traces[index] = !traces[index]; init(); });
        }
        button(width - 76, 64, 68, 18, horizon / 5 + " s", b -> { horizon = horizon == 300 ? 50 : horizon == 50 ? 150 : 300; init(); });
    }

    @Override
    public void renderBackground(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        // This screen paints its own background before its graph and text. In 1.21.1,
        // Screen.render calls this method again; vanilla blur would blur our content.
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        graphics.fill(0, 0, width, height, 0xF21A222B);
        graphics.fill(0, 0, width, 35, 0xFF202D37);
        graphics.drawString(font, title, 8, 8, GOLD);
        String live = (telemetry.getBoolean("valid") ? "● " : "! ") + tr("实时值 ", "Live ")
                + number(telemetry.getDouble("value")) + " " + telemetry.getString("unit") + "  " + telemetry.getString("status");
        graphics.drawString(font, font.plainSubstrByWidth(live, width - 16), 8, 24, telemetry.getBoolean("valid") ? 0x70DAB0 : 0xFFB080);
        if (tab == 1) renderGraph(graphics, mouseX, mouseY);
        else if (tab == 2) renderTraces(graphics);
        else if (tab == 3) renderHelp(graphics);
        for (Label label : labels) graphics.drawString(font, label.text, label.x, label.y, label.color, false);
        String status = (dirty ? tr("未保存 · ", "Unsaved · ") : "") + message;
        graphics.drawString(font, font.plainSubstrByWidth(status, width - 16), 8, height - 38, error ? 0xFF9E92 : MUTED, false);
        super.render(graphics, mouseX, mouseY, partialTick);
    }

    private int graphWidth() { return width - 196; }
    private int visibleRows() { return Math.max(1, (height - 143) / 30); }
    private int cardWidth() { return (graphWidth() - 22) / 2; }
    private int nodeX(int index) { return 12 + (index % 2) * (cardWidth() + 16); }
    private int nodeY(int index) { return 88 + (index / 2 - graphRow) * 30; }

    private boolean visibleNode(int index) {
        return index / 2 >= graphRow && index / 2 < graphRow + visibleRows();
    }

    private void renderGraph(GuiGraphics graphics, int mouseX, int mouseY) {
        int right = width - 187, bottom = height - 51;
        graphics.fill(8, 84, right, bottom, 0xFF111A22);
        graphics.enableScissor(8, 84, right, bottom);
        for (int index = 0; index < nodes.size(); index++) {
            if (!visibleNode(index)) continue;
            EditableNode target = nodes.get(index);
            for (String input : target.inputs) {
                int source = -1;
                for (int j = 0; j < nodes.size(); j++) if (nodes.get(j).id.equals(input)) { source = j; break; }
                if (source < 0 || !visibleNode(source)) continue;
                boolean highlight = index == selected || source == selected;
                int color = highlight ? 0xFF75C6D8 : 0xFF405764;
                int x1 = nodeX(source) + cardWidth(), y1 = nodeY(source) + 11;
                int x2 = nodeX(index), y2 = nodeY(index) + 11;
                int via = source % 2 == 0 ? x1 + 6 : x1 + 3;
                graphics.hLine(Math.min(x1, via), Math.max(x1, via), y1, color);
                graphics.vLine(via, Math.min(y1, y2), Math.max(y1, y2), color);
                graphics.hLine(Math.min(via, x2), Math.max(via, x2), y2, color);
                graphics.fill(x2 - 2, y2 - 2, x2 + 1, y2 + 3, color);
            }
        }
        for (int index = 0; index < nodes.size(); index++) {
            if (!visibleNode(index)) continue;
            EditableNode node = nodes.get(index);
            int x = nodeX(index), y = nodeY(index), w = cardWidth();
            int border = index == selected ? 0xFFF0D49A : node.id.equals(output) ? 0xFF62D8AD : 0xFF45606D;
            graphics.fill(x - 1, y - 1, x + w + 1, y + 24, border);
            graphics.fill(x, y, x + w, y + 23, index == selected ? 0xFF35454E : 0xFF24333D);
            graphics.drawString(font, node.id + (node.id.equals(output) ? " >" : ""), x + 4, y + 3, index == selected ? GOLD : TEXT, false);
            graphics.drawString(font, font.plainSubstrByWidth(node.op.name(), w - 6), x + 4, y + 13, MUTED, false);
        }
        graphics.disableScissor();
        String hint = nodes.isEmpty() ? tr("添加 INPUT 或常数节点开始构建", "Add INPUT or CONSTANT to begin") : tr("滚轮翻页 · 点击节点编辑", "Scroll pages · Click node to edit");
        graphics.drawString(font, font.plainSubstrByWidth(hint, graphWidth()), 8, height - 49, MUTED, false);
    }

    private void renderTraces(GuiGraphics graphics) {
        int left = 51, top = 96, right = width - 10, bottom = height - 65;
        graphics.fill(left, top, right, bottom, 0xFF111A22);
        int start = Math.max(0, history.size() - horizon);
        double min = Double.POSITIVE_INFINITY, max = Double.NEGATIVE_INFINITY;
        for (int i = start; i < history.size(); i++) for (int trace = 0; trace < 5; trace++) {
            Sample sample = history.get(i);
            if (traces[trace] && sample.valid[trace]) { min = Math.min(min, sample.values[trace]); max = Math.max(max, sample.values[trace]); }
        }
        if (!Double.isFinite(min)) { min = -1; max = 1; }
        if (max - min < 1e-9) { min -= Math.max(1, Math.abs(min) * 0.05); max += Math.max(1, Math.abs(max) * 0.05); }
        double padding = (max - min) * 0.08;
        min -= padding; max += padding;
        // Avoid overflow for finite but extreme telemetry values.
        if (!Double.isFinite(max - min)) { min = -1e300; max = 1e300; }
        for (int row = 0; row <= 4; row++) {
            int y = top + (bottom - top) * row / 4;
            graphics.hLine(left, right, y, 0xFF2C3D48);
        }
        graphics.drawString(font, font.plainSubstrByWidth(number(max), 45), 5, top, MUTED, false);
        graphics.drawString(font, font.plainSubstrByWidth(number(min), 45), 5, bottom - 8, MUTED, false);
        for (int trace = 0; trace < 5; trace++) {
            if (!traces[trace]) continue;
            for (int i = Math.max(start + 1, 1); i < history.size(); i++) {
                Sample a = history.get(i - 1), b = history.get(i);
                if (!a.valid[trace] || !b.valid[trace] || b.tick - a.tick > 12) continue;
                int x1 = left + (i - 1 - start) * (right - left) / Math.max(1, history.size() - start - 1);
                int x2 = left + (i - start) * (right - left) / Math.max(1, history.size() - start - 1);
                int y1 = plotY(a.values[trace], min, max, top, bottom);
                int y2 = plotY(b.values[trace], min, max, top, bottom);
                line(graphics, x1, y1, x2, y2, TRACE_COLORS[trace]);
            }
        }
        double seconds = history.size() <= start + 1 ? 0 : (history.get(history.size() - 1).tick - history.get(start).tick) / 20.0;
        String legend = String.format(Locale.ROOT, "%.1f s", seconds) + tr(" 模拟时间 · 无效数据留空", " simulated time · gaps = invalid data");
        graphics.drawString(font, legend, left, bottom + 5, MUTED, false);
        int x = 8;
        Sample latest = history.isEmpty() ? null : history.get(history.size() - 1);
        int valueWidth = (width - 16) / 5;
        for (int trace = 0; trace < 5; trace++) {
            String label = trace == 0 ? "OUT" : String.valueOf((char) ('A' + trace - 1));
            boolean unused = trace > 0 && telemetry.getBoolean("unused" + label);
            String value = unused ? tr("未使用", "unused") : latest != null && latest.valid[trace] ? number(latest.values[trace]) : "—";
            graphics.drawString(font, font.plainSubstrByWidth(label + " " + value, valueWidth - 3), x, 86, TRACE_COLORS[trace], false);
            x += valueWidth;
        }
    }

    private static int plotY(double value, double min, double max, int top, int bottom) {
        double scaled = (value - min) / (max - min);
        scaled = Math.max(0, Math.min(1, scaled));
        return bottom - (int) Math.round(scaled * (bottom - top));
    }

    private static void line(GuiGraphics graphics, int x1, int y1, int x2, int y2, int color) {
        int steps = Math.max(Math.abs(x2 - x1), Math.abs(y2 - y1));
        for (int i = 0; i <= steps; i++) {
            int x = x1 + (x2 - x1) * i / Math.max(1, steps);
            int y = y1 + (y2 - y1) * i / Math.max(1, steps);
            graphics.fill(x, y, x + 1, y + 1, color);
        }
    }

    private void renderHelp(GuiGraphics graphics) {
        List<String> paragraphs = !motionModes().isEmpty() ? List.of(
                kind.equals("MOTION_SENSOR") ? tr("旧运动传感器保留点位高度兼容。新高度、速度、姿态检测器测量整个 Sable 刚体。", "Legacy motion sensors retain point-height compatibility. New sensors measure the whole Sable rigid body.") : tr("检测对象是整个 Sable 刚体，检测器安装位置不改变整船参考点。没有有效刚体时显示无效。", "Measures the whole Sable rigid body, independent of mounting location. No valid body means an invalid signal."),
                tr("高度：世界 Y 是绝对高度；相对高度减去归零参考。首次有效或换船后自动建立参考，可手动重新归零。", "Height: World Y is absolute; relative height subtracts the zero reference. First valid body or a new body establishes the reference; you can zero it again."),
                tr("速度：合速度或世界 X/Y/Z 分量，单位方块/秒。姿态：Roll/Pitch/Yaw，YXZ 欧拉角，单位度。", "Speed: magnitude or world X/Y/Z components, in blocks/s. Attitude: Roll/Pitch/Yaw, YXZ Euler angles in degrees."),
                tr("同维度、同网络、同名通道连接；保存后生效。NULL 输入表示未使用，不是 0。", "Match dimension, network and channel; Save to apply. NULL inputs are unused, not zero.")) : builder() ? List.of(
                tr("1. INPUT 的 port=0/1/2/3 对应 A/B/C/D。NULL 或空白表示未使用，不是数值 0。", "1. INPUT port=0/1/2/3 maps to A/B/C/D. NULL or blank means unused, not zero."),
                tr("2. 添加节点，点击节点后选择运算与输入连接；点击参数名切换参数。PID 输入为目标、测量。", "2. Add/select nodes, choose operation and input connections. Click parameter name to cycle. PID inputs: target, measured."),
                tr("3. 选择最终节点并设为输出，再保存。反馈环必须经过 DELAY；无效输入会复位控制器。", "3. Select the final node, Use as output, then Save. Feedback loops require DELAY; invalid signals reset control state."),
                tr("4. 实时曲线显示已保存系统的值，不覆盖草稿。每 tick 一步；普通网络连接额外延迟一 tick。", "4. Traces show the saved system without overwriting drafts. One step/tick; bus connections add one tick of delay.")) : List.of(
                tr("同维度 + 同网络 + 同名通道可连接方块，无需红石线。一个通道只允许一个发布者。", "Blocks connect by matching dimension + network + channel; no redstone wire needed. One publisher per channel."),
                tr("连续信号支持小数。转速 RPM，线速度方块/秒，姿态角 °，角速度 rad/s，采用世界坐标。", "Signals support decimals. Rotation: RPM; speed: blocks/s; attitude: degrees; angular velocity: rad/s, in world axes."),
                tr("比例、偏移与上下限用于信号映射。红石输出仅在接口处量化为 0–15。", "Scale, offset and limits map signals. Only the redstone output interface quantizes to 0–15."),
                tr("修改后保存生效。信号丢失、冲突或传感器故障时执行器归零。运动传感器需要 Sable 刚体。", "Save to apply. Missing/conflicting signals and sensor faults drive actuators to zero. Motion sensors require a Sable body."));
        int y = 67;
        for (String text : paragraphs) {
            var lines = font.split(Component.literal(text), width - 20);
            for (var line : lines) { graphics.drawString(font, line, 10, y, TEXT, false); y += 10; }
            y += 6;
        }
    }

    private static String number(double value) {
        if (!Double.isFinite(value)) return "—";
        return String.format(Locale.ROOT, Math.abs(value) >= 100000 || (Math.abs(value) > 0 && Math.abs(value) < .0001) ? "%.3g" : "%.4f", value);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int mouseButton) {
        if (tab == 1 && mouseButton == 0 && mouseX >= 8 && mouseX < width - 187 && mouseY >= 84 && mouseY < height - 51) {
            for (int i = 0; i < nodes.size(); i++) {
                if (!visibleNode(i)) continue;
                if (mouseX >= nodeX(i) && mouseX <= nodeX(i) + cardWidth() && mouseY >= nodeY(i) && mouseY <= nodeY(i) + 23) {
                    selected = i; parameterIndex = 0; init(); return true;
                }
            }
        }
        return super.mouseClicked(mouseX, mouseY, mouseButton);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double scrollX, double scrollY) {
        if (tab == 1 && mouseX < width - 187 && mouseY >= 84 && mouseY < height - 45) {
            int maxRow = Math.max(0, (nodes.size() + 1) / 2 - visibleRows());
            graphRow = Math.max(0, Math.min(maxRow, graphRow - (int) Math.signum(scrollY))); return true;
        }
        return super.mouseScrolled(mouseX, mouseY, scrollX, scrollY);
    }

    @Override public boolean isPauseScreen() { return false; }

    @Override
    public void onClose() {
        if (dirty) minecraft.setScreen(new ConfirmScreen(discard -> {
            if (discard) minecraft.setScreen(null); else minecraft.setScreen(this);
        }, Component.literal(tr("放弃尚未保存的修改？", "Discard unsaved changes?")),
                Component.literal(tr("已保存的系统会继续运行。", "The saved system will continue running."))));
        else minecraft.setScreen(null);
    }

    private record Label(int x, int y, String text, int color) {}
    private record Sample(long tick, double[] values, boolean[] valid) {}

    private static final class EditableNode {
        final String id;
        Op op;
        final List<String> inputs = new ArrayList<>();
        final Map<String, String> parameters = new LinkedHashMap<>();

        EditableNode(String id) { this.id = id; }
        EditableNode(Node node) {
            id = node.id(); op = node.op(); inputs.addAll(node.inputs());
            // Stable field order makes PID tuning predictable across reloads.
            defaults(op).forEach((key, value) -> parameters.put(key, Double.toString(node.parameters().getOrDefault(key, value))));
            node.parameters().forEach((key, value) -> parameters.putIfAbsent(key, Double.toString(value)));
        }

        void setOperation(Op operation, List<EditableNode> graph) {
            op = operation;
            int arity = switch (op) {
                case INPUT, CONSTANT -> 0;
                case ADD, SUBTRACT, MULTIPLY, DIVIDE, PID, MIN, MAX -> 2;
                default -> 1;
            };
            while (inputs.size() > arity) inputs.remove(inputs.size() - 1);
            while (inputs.size() < arity) inputs.add(graph.stream().filter(node -> !node.id.equals(id)).map(node -> node.id).findFirst().orElse(id));
            parameters.clear(); defaults(op).forEach((key, value) -> parameters.put(key, Double.toString(value)));
        }

        private static Map<String, Double> defaults(Op op) {
            LinkedHashMap<String, Double> values = new LinkedHashMap<>();
            switch (op) {
                case INPUT -> values.put("port", 0.0);
                case CONSTANT -> values.put("value", 0.0);
                case GAIN -> values.put("gain", 1.0);
                case CLAMP -> { values.put("min", -256.0); values.put("max", 256.0); }
                case PID -> {
                    values.put("kp", 1.0); values.put("ki", 0.0); values.put("kd", 0.0);
                    values.put("min", -256.0); values.put("max", 256.0);
                }
                case INTEGRATE -> { values.put("initial", 0.0); values.put("min", -1e12); values.put("max", 1e12); }
                case LOW_PASS -> values.put("tau", 0.1);
                case DELAY -> values.put("initial", 0.0);
                default -> {}
            }
            return values;
        }
    }
}
