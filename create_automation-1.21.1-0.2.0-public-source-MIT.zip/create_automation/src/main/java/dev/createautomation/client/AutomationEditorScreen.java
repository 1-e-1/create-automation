package dev.createautomation.client;

import dev.createautomation.network.AutomationNetwork;

/** Common receiver for independent configuration screens and their modal pickers. */
public interface AutomationEditorScreen {
    void receive(AutomationNetwork.SnapshotPayload packet);
}
