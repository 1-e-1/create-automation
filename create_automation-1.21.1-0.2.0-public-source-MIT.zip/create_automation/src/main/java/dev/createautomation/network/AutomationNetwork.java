package dev.createautomation.network;

import dev.createautomation.world.AutomationBlockEntity;
import dev.createautomation.world.MotionBridge;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.TagParser;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.network.PacketDistributor;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;
import net.neoforged.neoforge.network.handling.IPayloadContext;

import java.nio.charset.StandardCharsets;
import java.util.Map;
import java.util.WeakHashMap;
import java.util.function.Consumer;

/** Common-side protocol. No Minecraft client classes may be referenced from this class. */
public final class AutomationNetwork {
    public static final int MAX_CONFIG_BYTES = 24000;
    private static final Map<ServerPlayer, Long> LAST_READ = new WeakHashMap<>();
    private static final Map<ServerPlayer, Long> LAST_WRITE = new WeakHashMap<>();
    private static Consumer<OpenPayload> openReceiver = packet -> {};
    private static Consumer<SnapshotPayload> snapshotReceiver = packet -> {};

    private AutomationNetwork() {}

    /** Installed only by the Dist.CLIENT event subscriber. */
    public static void setClientReceivers(Consumer<OpenPayload> open, Consumer<SnapshotPayload> snapshot) {
        openReceiver = open;
        snapshotReceiver = snapshot;
    }

    public static void register(RegisterPayloadHandlersEvent event) {
        var registrar = event.registrar("1");
        registrar.playToClient(OpenPayload.TYPE, OpenPayload.CODEC, (packet, context) -> openReceiver.accept(packet));
        registrar.playToClient(SnapshotPayload.TYPE, SnapshotPayload.CODEC, (packet, context) -> snapshotReceiver.accept(packet));
        registrar.playToServer(ReadPayload.TYPE, ReadPayload.CODEC, AutomationNetwork::read);
        registrar.playToServer(ConfigurePayload.TYPE, ConfigurePayload.CODEC, AutomationNetwork::configure);
    }

    public static void open(ServerPlayer player, AutomationBlockEntity block) {
        if (block.getLevel() != player.level() || !accessible(player, block.getBlockPos())) return;
        CompoundTag snapshot = snapshot(block, true);
        String data = snapshot.toString();
        if (!bounded(data)) return;
        PacketDistributor.sendToPlayer(player, new OpenPayload(block.getBlockPos(), dimension(player),
                block.getNodeKind().name(), data));
    }

    public static void request(BlockPos pos, String dimension) {
        PacketDistributor.sendToServer(new ReadPayload(pos, dimension));
    }

    public static void save(BlockPos pos, String dimension, CompoundTag settings) {
        String data = settings.toString();
        if (!bounded(data)) throw new IllegalArgumentException("Configuration is larger than 24 KB");
        PacketDistributor.sendToServer(new ConfigurePayload(pos, dimension, data));
    }

    public static CompoundTag parse(String data) throws Exception {
        if (!bounded(data)) throw new IllegalArgumentException("Configuration is larger than 24 KB");
        return TagParser.parseTag(data);
    }

    private static CompoundTag snapshot(AutomationBlockEntity block, boolean includeSettings) {
        CompoundTag result = block.clientSnapshot().copy();
        if (includeSettings) result.put("settings", block.getSettings());
        else result.remove("settings");
        if (block.getLevel() != null) result.putLong("sampleTick", block.getLevel().getGameTime());
        return result;
    }

    private static boolean bounded(String data) {
        return data.length() <= MAX_CONFIG_BYTES && data.getBytes(StandardCharsets.UTF_8).length <= MAX_CONFIG_BYTES;
    }

    private static String dimension(ServerPlayer player) {
        return player.level().dimension().location().toString();
    }

    private static boolean accessible(ServerPlayer player, BlockPos pos) {
        return player.level().hasChunkAt(pos)
                && MotionBridge.distanceSquared(player.level(), player.position(), Vec3.atCenterOf(pos)) <= 64.0;
    }

    private static AutomationBlockEntity target(ServerPlayer player, BlockPos pos, String dim) {
        if (!dimension(player).equals(dim) || !accessible(player, pos)) return null;
        return player.level().getBlockEntity(pos) instanceof AutomationBlockEntity block ? block : null;
    }

    private static void reply(ServerPlayer player, BlockPos pos, String dim, AutomationBlockEntity block,
                              String message, boolean acknowledgement) {
        String data = block == null ? "{}" : snapshot(block, false).toString();
        if (!bounded(data)) data = "{}";
        PacketDistributor.sendToPlayer(player, new SnapshotPayload(pos, dim, data,
                message.length() > 256 ? message.substring(0, 256) : message, acknowledgement));
    }

    private static void read(ReadPayload packet, IPayloadContext context) {
        if (!(context.player() instanceof ServerPlayer player)) return;
        long tick = player.serverLevel().getGameTime();
        Long previous = LAST_READ.put(player, tick);
        if (previous != null && tick >= previous && tick - previous < 3) return;
        AutomationBlockEntity block = target(player, packet.pos(), packet.dimension());
        if (block == null) {
            reply(player, packet.pos(), packet.dimension(), null, "out_of_range", false);
            return;
        }
        reply(player, packet.pos(), packet.dimension(), block, "", false);
    }

    private static void configure(ConfigurePayload packet, IPayloadContext context) {
        if (!(context.player() instanceof ServerPlayer player)) return;
        AutomationBlockEntity block = target(player, packet.pos(), packet.dimension());
        if (block == null || !player.mayBuild() || player.isSpectator()) {
            reply(player, packet.pos(), packet.dimension(), null, "no_permission", true);
            return;
        }
        long tick = player.serverLevel().getGameTime();
        Long previous = LAST_WRITE.get(player);
        if (previous != null && tick >= previous && tick - previous < 3) {
            reply(player, packet.pos(), packet.dimension(), block, "too_fast", true);
            return;
        }
        LAST_WRITE.put(player, tick);
        try {
            requireFlatSettings(packet.settings());
            CompoundTag settings = parse(packet.settings());
            // Only the settings validator may mutate world state. Runtime fields are never trusted.
            block.applySettings(settings);
            reply(player, packet.pos(), packet.dimension(), block, "saved", true);
        } catch (Exception exception) {
            String message = exception.getMessage();
            reply(player, packet.pos(), packet.dimension(), block,
                    message == null ? "Invalid configuration" : message, true);
        }
    }

    /** Settings contain primitive values only. Reject nested structures before the recursive SNBT parser. */
    private static void requireFlatSettings(String data) {
        if (!bounded(data)) throw new IllegalArgumentException("Configuration is larger than 24 KB");
        char quote = 0;
        boolean escaped = false;
        boolean opened = false;
        for (int i = 0; i < data.length(); i++) {
            char c = data.charAt(i);
            if (quote != 0) {
                if (escaped) escaped = false;
                else if (c == '\\') escaped = true;
                else if (c == quote) quote = 0;
            } else if (c == '\'' || c == '"') quote = c;
            else if (c == '[' || (c == '{' && opened)) throw new IllegalArgumentException("Nested settings are not supported");
            else if (c == '{') opened = true;
        }
    }

    private static <T extends CustomPacketPayload> CustomPacketPayload.Type<T> type(String path) {
        return new CustomPacketPayload.Type<>(ResourceLocation.fromNamespaceAndPath("create_automation", path));
    }

    public record OpenPayload(BlockPos pos, String dimension, String kind, String snapshot) implements CustomPacketPayload {
        public static final Type<OpenPayload> TYPE = AutomationNetwork.type("open");
        public static final StreamCodec<RegistryFriendlyByteBuf, OpenPayload> CODEC = new StreamCodec<>() {
            public OpenPayload decode(RegistryFriendlyByteBuf buf) {
                return new OpenPayload(buf.readBlockPos(), buf.readUtf(128), buf.readUtf(32), buf.readUtf(MAX_CONFIG_BYTES));
            }
            public void encode(RegistryFriendlyByteBuf buf, OpenPayload packet) {
                buf.writeBlockPos(packet.pos()); buf.writeUtf(packet.dimension(), 128);
                buf.writeUtf(packet.kind(), 32); buf.writeUtf(packet.snapshot(), MAX_CONFIG_BYTES);
            }
        };
        public Type<? extends CustomPacketPayload> type() { return TYPE; }
    }

    public record SnapshotPayload(BlockPos pos, String dimension, String snapshot, String message,
                                  boolean acknowledgement) implements CustomPacketPayload {
        public static final Type<SnapshotPayload> TYPE = AutomationNetwork.type("snapshot");
        public static final StreamCodec<RegistryFriendlyByteBuf, SnapshotPayload> CODEC = new StreamCodec<>() {
            public SnapshotPayload decode(RegistryFriendlyByteBuf buf) {
                return new SnapshotPayload(buf.readBlockPos(), buf.readUtf(128), buf.readUtf(MAX_CONFIG_BYTES),
                        buf.readUtf(256), buf.readBoolean());
            }
            public void encode(RegistryFriendlyByteBuf buf, SnapshotPayload packet) {
                buf.writeBlockPos(packet.pos()); buf.writeUtf(packet.dimension(), 128);
                buf.writeUtf(packet.snapshot(), MAX_CONFIG_BYTES); buf.writeUtf(packet.message(), 256);
                buf.writeBoolean(packet.acknowledgement());
            }
        };
        public Type<? extends CustomPacketPayload> type() { return TYPE; }
    }

    public record ReadPayload(BlockPos pos, String dimension) implements CustomPacketPayload {
        public static final Type<ReadPayload> TYPE = AutomationNetwork.type("read");
        public static final StreamCodec<RegistryFriendlyByteBuf, ReadPayload> CODEC = new StreamCodec<>() {
            public ReadPayload decode(RegistryFriendlyByteBuf buf) { return new ReadPayload(buf.readBlockPos(), buf.readUtf(128)); }
            public void encode(RegistryFriendlyByteBuf buf, ReadPayload packet) { buf.writeBlockPos(packet.pos()); buf.writeUtf(packet.dimension(), 128); }
        };
        public Type<? extends CustomPacketPayload> type() { return TYPE; }
    }

    public record ConfigurePayload(BlockPos pos, String dimension, String settings) implements CustomPacketPayload {
        public static final Type<ConfigurePayload> TYPE = AutomationNetwork.type("configure");
        public static final StreamCodec<RegistryFriendlyByteBuf, ConfigurePayload> CODEC = new StreamCodec<>() {
            public ConfigurePayload decode(RegistryFriendlyByteBuf buf) {
                return new ConfigurePayload(buf.readBlockPos(), buf.readUtf(128), buf.readUtf(MAX_CONFIG_BYTES));
            }
            public void encode(RegistryFriendlyByteBuf buf, ConfigurePayload packet) {
                buf.writeBlockPos(packet.pos()); buf.writeUtf(packet.dimension(), 128); buf.writeUtf(packet.settings(), MAX_CONFIG_BYTES);
            }
        };
        public Type<? extends CustomPacketPayload> type() { return TYPE; }
    }
}
