package dev.createautomation.registry;

import dev.createautomation.world.AutomationBlock;
import dev.createautomation.world.AutomationBlockEntity;
import dev.createautomation.world.NodeKind;
import dev.createautomation.world.SignalBus;
import java.util.EnumMap;
import java.util.Map;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class ModRegistry {
    public static final String MOD_ID = "create_automation";
    public static final DeferredRegister<Block> BLOCKS = DeferredRegister.create(Registries.BLOCK, MOD_ID);
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(Registries.ITEM, MOD_ID);
    public static final DeferredRegister<BlockEntityType<?>> BLOCK_ENTITIES = DeferredRegister.create(Registries.BLOCK_ENTITY_TYPE, MOD_ID);
    public static final DeferredRegister<CreativeModeTab> TABS = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, MOD_ID);
    public static final Map<NodeKind, DeferredHolder<Block, AutomationBlock>> NODES = new EnumMap<>(NodeKind.class);

    static {
        for (NodeKind kind : NodeKind.values()) {
            var block = BLOCKS.register(kind.id(), () -> new AutomationBlock(
                    BlockBehaviour.Properties.of().strength(3.0f, 6.0f).sound(SoundType.METAL)
                            .requiresCorrectToolForDrops(), kind));
            NODES.put(kind, block);
            ITEMS.register(kind.id(), () -> new BlockItem(block.get(), new Item.Properties()));
        }
    }

    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<AutomationBlockEntity>> NODE_ENTITY =
            BLOCK_ENTITIES.register("automation_node", () -> BlockEntityType.Builder.of(AutomationBlockEntity::new,
                    NODES.values().stream().map(DeferredHolder::get).toArray(Block[]::new)).build(null));

    public static final DeferredHolder<CreativeModeTab, CreativeModeTab> AUTOMATION_TAB = TABS.register("automation",
            () -> CreativeModeTab.builder().title(Component.translatable("itemGroup.create_automation"))
                    .icon(() -> new ItemStack(NODES.get(NodeKind.SYSTEM_BUILDER).get()))
                    .displayItems((parameters, output) -> {
                        for (NodeKind kind : NodeKind.values()) output.accept(NODES.get(kind).get());
                    }).build());

    private ModRegistry() { }

    public static void register(IEventBus bus) {
        BLOCKS.register(bus);
        ITEMS.register(bus);
        BLOCK_ENTITIES.register(bus);
        TABS.register(bus);
        NeoForge.EVENT_BUS.addListener(SignalBus::endLevelTick);
        NeoForge.EVENT_BUS.addListener(SignalBus::unloadLevel);
    }
}
