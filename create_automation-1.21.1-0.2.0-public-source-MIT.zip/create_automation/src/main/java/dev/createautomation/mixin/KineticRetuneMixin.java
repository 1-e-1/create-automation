package dev.createautomation.mixin;

import com.simibubi.create.content.kinetics.base.KineticBlockEntity;
import dev.createautomation.integration.KineticFlickerAccess;
import dev.createautomation.integration.ServoSpeedUpdate;
import org.objectweb.asm.Opcodes;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

/** Exact Create 6.0.10 hook: leave onSpeedChanged and all destruction checks otherwise intact. */
@Mixin(value = KineticBlockEntity.class, remap = false)
public abstract class KineticRetuneMixin implements KineticFlickerAccess {
    @Shadow(remap = false) private int flickerTally;

    @Redirect(method = "onSpeedChanged(F)V", at = @At(value = "FIELD",
            target = "Lcom/simibubi/create/content/kinetics/base/KineticBlockEntity;flickerTally:I",
            opcode = Opcodes.PUTFIELD, remap = false), require = 1, expect = 1, allow = 1, remap = false)
    private void createAutomation$accountRetune(KineticBlockEntity instance, int proposedScore, float previousSpeed) {
        flickerTally = ServoSpeedUpdate.accountFlicker(instance, previousSpeed, flickerTally, proposedScore);
    }

    @Override
    @Unique
    public void createAutomation$addDeferredFlicker(int amount) {
        if (amount > 0) flickerTally += amount;
    }
}
