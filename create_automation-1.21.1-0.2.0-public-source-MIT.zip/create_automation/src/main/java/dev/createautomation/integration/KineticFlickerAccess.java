package dev.createautomation.integration;

/** Mixin bridge: can only ADD a deferred real-stop penalty, never erase prior flicker history. */
public interface KineticFlickerAccess {
    void createAutomation$addDeferredFlicker(int amount);
}
