package dev.createautomation.integration;

import com.simibubi.create.content.kinetics.KineticNetwork;
import com.simibubi.create.content.kinetics.base.GeneratingKineticBlockEntity;
import com.simibubi.create.content.kinetics.base.KineticBlockEntity;
import java.util.IdentityHashMap;
import java.util.Map;
import java.util.Objects;

/**
 * Performs the complete original Create speed update, including propagation, stress and conflicts.
 * Only the artificial detach/reattach flicker penalties of a continuous single-source retune are
 * accounted differently. Real reversals, starts/stops, overstress and unrelated machines are untouched.
 */
public final class ServoSpeedUpdate {
    private record Context(GeneratingKineticBlockEntity source, Long network,
                           RetuneFlickerLedger<KineticBlockEntity> ledger) { }
    private static final ThreadLocal<Context> ACTIVE = new ThreadLocal<>();
    private ServoSpeedUpdate() { }

    /** Call after changing getGeneratedSpeed()'s backing value, before invoking any Create update. */
    public static void update(GeneratingKineticBlockEntity source) {
        Context outer = ACTIVE.get();
        if (outer != null) {
            // A nested update is not part of the original transaction. Keep all its safeguards.
            ACTIVE.remove();
            try { source.updateGeneratedRotation(); }
            finally { ACTIVE.set(outer); }
            return;
        }
        float before = source.getTheoreticalSpeed(), after = source.getGeneratedSpeed();
        if (!RetuneFlickerLedger.isContinuousRetune(before, after)
                || source.getLevel() == null || source.getLevel().isClientSide
                || source.hasSource() || !source.hasNetwork() || source.isOverStressed()) {
            source.updateGeneratedRotation();
            return;
        }
        KineticNetwork network = source.getOrCreateNetwork();
        if (network.sources.size() != 1 || !network.sources.containsKey(source)) {
            source.updateGeneratedRotation();
            return;
        }
        Map<KineticBlockEntity, Float> speeds = new IdentityHashMap<>();
        for (KineticBlockEntity member : network.members.keySet()) {
            if (!member.isRemoved() && member.getLevel() == source.getLevel() && !member.isOverStressed()
                    && member.hasNetwork() && Objects.equals(member.network, source.network))
                speeds.put(member, member.getSpeed());
        }
        Context context = new Context(source, source.network, new RetuneFlickerLedger<>(speeds, before, after));
        ACTIVE.set(context);
        try {
            source.updateGeneratedRotation();
        } finally {
            ACTIVE.remove();
            context.ledger.finish((member, penalty) -> {
                if (member instanceof KineticFlickerAccess access) access.createAutomation$addDeferredFlicker(penalty);
            });
        }
    }

    /** Used only by the narrowly targeted onSpeedChanged flicker-field redirect. */
    public static int accountFlicker(KineticBlockEntity member, float previousSpeed,
                                     int existingScore, int proposedScore) {
        Context context = ACTIVE.get();
        if (context == null || member.getLevel() != context.source.getLevel()) return proposedScore;
        boolean detached = !member.hasNetwork() && member.getTheoreticalSpeed() == 0;
        boolean restored = member.hasNetwork() && Objects.equals(member.network, context.network)
                && !member.isOverStressed();
        return context.ledger.adjust(member, previousSpeed, member.getSpeed(), detached, restored, existingScore, proposedScore);
    }
}
