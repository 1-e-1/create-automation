package dev.createautomation.integration;

import java.util.IdentityHashMap;
import java.util.Map;
import java.util.function.BiConsumer;

/**
 * Accounts for Create 6.0.10's synthetic stop/start pair during one synchronous speed retune.
 * Existing flicker history is never cleared. Unmatched stops and unexpected transitions receive
 * every original penalty. Kept independent of Minecraft so this protection policy can be tested.
 */
final class RetuneFlickerLedger<T> {
    private enum Phase { ORIGINAL, STOPPED, COMPLETE, REJECTED }
    private static final class Entry {
        final float initialSpeed;
        Phase phase = Phase.ORIGINAL;
        Entry(float initialSpeed) { this.initialSpeed = initialSpeed; }
    }
    private final Map<T, Entry> entries = new IdentityHashMap<>();
    private final double ratio;

    RetuneFlickerLedger(Map<T, Float> originalSpeeds, float oldSourceSpeed, float newSourceSpeed) {
        if (!isContinuousRetune(oldSourceSpeed, newSourceSpeed))
            throw new IllegalArgumentException("Only finite nonzero same-direction retunes may be scoped");
        ratio = (double) newSourceSpeed / oldSourceSpeed;
        originalSpeeds.forEach((node, speed) -> {
            if (node != null && speed != null && Float.isFinite(speed) && speed != 0)
                entries.put(node, new Entry(speed));
        });
    }

    static boolean isContinuousRetune(float before, float after) {
        return Float.isFinite(before) && Float.isFinite(after) && before != 0 && after != 0
                && before != after && Math.signum(before) == Math.signum(after);
    }

    /** Called only where Create is about to write its original flickerScore + 5. */
    int adjust(T node, float previousSpeed, float currentSpeed, boolean fullyDetached,
               boolean returnedToOriginalNetwork, int existingScore, int proposedScore) {
        Entry entry = entries.get(node);
        if (entry == null || entry.phase == Phase.COMPLETE || entry.phase == Phase.REJECTED)
            return proposedScore;
        // Fail closed if another compatibility layer changes Create's accounting convention.
        if (proposedScore - existingScore != 5) return reject(entry, proposedScore);
        if (entry.phase == Phase.ORIGINAL) {
            if (Float.compare(previousSpeed, entry.initialSpeed) == 0 && currentSpeed == 0 && fullyDetached) {
                entry.phase = Phase.STOPPED;
                return existingScore;
            }
            entry.phase = Phase.REJECTED;
            return proposedScore;
        }
        double expected = entry.initialSpeed * ratio;
        double tolerance = Math.max(Math.abs(expected) * 1e-6, Math.ulp(currentSpeed) * 8.0);
        if (previousSpeed == 0 && Float.isFinite(currentSpeed) && currentSpeed != 0
                && Math.signum(currentSpeed) == Math.signum(entry.initialSpeed)
                && returnedToOriginalNetwork && Math.abs(currentSpeed - expected) <= tolerance) {
            entry.phase = Phase.COMPLETE;
            return existingScore;
        }
        return reject(entry, proposedScore);
    }

    private int reject(Entry entry, int proposedScore) {
        boolean owesStop = entry.phase == Phase.STOPPED;
        entry.phase = Phase.REJECTED;
        return owesStop ? proposedScore + 5 : proposedScore;
    }

    /** Also called on exceptional exit: a stop that did not reconnect remains a real stop. */
    void finish(BiConsumer<T, Integer> addMissingPenalty) {
        entries.forEach((node, entry) -> {
            if (entry.phase == Phase.STOPPED) {
                entry.phase = Phase.REJECTED;
                addMissingPenalty.accept(node, 5);
            }
        });
    }
}
