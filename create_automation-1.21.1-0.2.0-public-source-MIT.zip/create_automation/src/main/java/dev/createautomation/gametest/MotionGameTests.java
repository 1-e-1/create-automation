package dev.createautomation.gametest;

import dev.createautomation.registry.ModRegistry;
import dev.createautomation.world.AutomationBlockEntity;
import dev.createautomation.world.MotionBridge;
import dev.createautomation.world.NodeKind;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.gametest.framework.GameTest;
import net.minecraft.gametest.framework.GameTestHelper;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.Unit;
import net.neoforged.fml.ModList;
import net.neoforged.neoforge.gametest.GameTestHolder;
import net.neoforged.neoforge.gametest.PrefixGameTestTemplate;
import org.joml.Vector3d;
import org.joml.Vector3dc;

/** Requires Sable in the test runtime. Uses a real assembled body and actual physics impulses. */
@GameTestHolder("create_automation")
@PrefixGameTestTemplate(false)
public final class MotionGameTests {
    @GameTest(template = "empty", timeoutTicks = 100)
    public static void assembled_motion_sensor_measures_real_physics(GameTestHelper helper) {
        helper.assertTrue(ModList.get().isLoaded("sable"), "This integration test requires Sable 2.0.6");
        BlockPos placed = helper.absolutePos(new BlockPos(3, 24, 3));
        helper.getLevel().setBlockAndUpdate(placed, ModRegistry.NODES.get(NodeKind.MOTION_SENSOR).get().defaultBlockState());
        Object[] body = new Object[1];
        AutomationBlockEntity[] sensor = new AutomationBlockEntity[1];
        double[] origin = new double[1];

        helper.runAtTickTime(5, () -> checked(() -> {
            Class<?> boundsType = Class.forName("dev.ryanhcode.sable.companion.math.BoundingBox3i");
            Class<?> boundsInterface = Class.forName("dev.ryanhcode.sable.companion.math.BoundingBox3ic");
            Object bounds = boundsType.getConstructor(BlockPos.class, BlockPos.class).newInstance(placed, placed);
            Class<?> assembly = Class.forName("dev.ryanhcode.sable.api.SubLevelAssemblyHelper");
            body[0] = assembly.getMethod("assembleBlocks", ServerLevel.class, BlockPos.class, Iterable.class, boundsInterface)
                    .invoke(null, helper.getLevel(), placed, List.of(placed), bounds);
            forceBody(helper, body[0]); // A headless test has no player to keep a moving body resident.
            Object plot = body[0].getClass().getMethod("getPlot").invoke(body[0]);
            BlockPos migrated = (BlockPos) plot.getClass().getMethod("getCenterBlock").invoke(plot);
            sensor[0] = (AutomationBlockEntity) helper.getLevel().getBlockEntity(migrated);
            helper.assertTrue(sensor[0] != null, "Assembly must migrate the actual motion detector block entity");
        }));

        helper.runAtTickTime(12, () -> checked(() -> {
            MotionBridge.Sample sample = MotionBridge.sample(sensor[0]);
            helper.assertTrue(sample.valid(), "Assembled body must provide data: " + sample.status());
            origin[0] = sample.height();
            CompoundTag settings = sensor[0].getSettings();
            settings.putString("network", "motion_test_" + placed.asLong());
            settings.putString("mode", "HEIGHT");
            settings.putBoolean("calibrate", true);
            sensor[0].applySettings(settings);
            CompoundTag saved = sensor[0].saveWithFullMetadata(helper.getLevel().registryAccess());
            helper.assertTrue(saved.getBoolean("Calibrated") && saved.hasUUID("OriginBody"),
                    "Calibration and body identity must be saved");
            Object handle = handle(body[0]);
            helper.assertTrue((boolean) handle.getClass().getMethod("isValid").invoke(handle), "Body physics handle must be live");
            handle.getClass().getMethod("addLinearAndAngularVelocity", Vector3dc.class, Vector3dc.class)
                    .invoke(handle, new Vector3d(3.25, 4.0, -0.75), new Vector3d(0.15, 0.25, 0.35));
        }));

        helper.runAtTickTime(24, () -> checked(() -> {
            MotionBridge.Sample sample = MotionBridge.sample(sensor[0]);
            helper.assertTrue(sample.valid(), "Moving assembled sensor remains valid: " + sample.status());
            helper.assertTrue(sample.vx() > 1.0, "Real impulse must produce positive X velocity; sample=" + sample);
            helper.assertTrue(Math.abs(sample.height() - origin[0]) > 0.02, "Physical body position must change");
            helper.assertTrue(Math.abs(sample.roll()) + Math.abs(sample.pitch()) + Math.abs(sample.yaw()) > 0.2,
                    "Angular impulse must be observable as nonzero attitude");
            CompoundTag snapshot = sensor[0].clientSnapshot();
            helper.assertTrue(snapshot.getBoolean("valid"), "Moved block entity must keep ticking inside its Sable plot");
            helper.assertTrue(Math.abs(snapshot.getDouble("value") - (sample.height() - origin[0])) < 1.0,
                    "Published HEIGHT must track the calibrated physical height");
            Object liveHandle = handle(body[0]);
            Vector3dc physicalVelocity = (Vector3dc) liveHandle.getClass().getMethod("getLinearVelocity").invoke(liveHandle);
            helper.assertTrue(Math.abs(sample.vx() - physicalVelocity.x()) < 0.5,
                    "Sensor velocity must agree with the actual physics pipeline");
            CompoundTag settings = sensor[0].getSettings();
            settings.putString("mode", "VELOCITY_X");
            sensor[0].applySettings(settings);
        }));

        helper.runAtTickTime(32, () -> checked(() -> {
            MotionBridge.Sample sample = MotionBridge.sample(sensor[0]);
            CompoundTag snapshot = sensor[0].clientSnapshot();
            helper.assertTrue(snapshot.getBoolean("valid"), "Velocity mode must produce a valid published value");
            helper.assertTrue(Math.abs(snapshot.getDouble("value") - sample.vx()) < 0.5 && sample.vx() > 0.5,
                    "Published VELOCITY_X must follow real body velocity without redstone quantization");
            helper.assertTrue("block/s (world)".equals(snapshot.getString("unit")), "Velocity units must be explicit");
            removeBody(helper, body[0]);
            helper.succeed();
        }));
    }

    private static Object handle(Object body) throws ReflectiveOperationException {
        Class<?> handle = Class.forName("dev.ryanhcode.sable.api.physics.handle.RigidBodyHandle");
        Class<?> serverBody = Class.forName("dev.ryanhcode.sable.sublevel.ServerSubLevel");
        return handle.getMethod("of", serverBody).invoke(null, body);
    }

    private static void forceBody(GameTestHelper helper, Object body) throws ReflectiveOperationException {
        Class<?> containers = Class.forName("dev.ryanhcode.sable.api.sublevel.SubLevelContainer");
        Object container = container(helper);
        Class<?> serverBody = Class.forName("dev.ryanhcode.sable.sublevel.ServerSubLevel");
        Class<?> ticket = Class.forName("dev.ryanhcode.sable.api.sublevel.ticket.SubLevelLoadingTicketType");
        Object commandTicket = ticket.getField("COMMAND_FORCED").get(null);
        container.getClass().getMethod("addForceLoadTicket", serverBody, ticket, Object.class)
                .invoke(container, body, commandTicket, Unit.INSTANCE);
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    private static void removeBody(GameTestHelper helper, Object body) throws ReflectiveOperationException {
        Class<?> containers = Class.forName("dev.ryanhcode.sable.api.sublevel.SubLevelContainer");
        Object container = container(helper);
        Class<? extends Enum> reasonType = (Class<? extends Enum>) Class.forName("dev.ryanhcode.sable.sublevel.storage.SubLevelRemovalReason");
        Object reason = Enum.valueOf(reasonType, "REMOVED");
        Class<?> subLevel = Class.forName("dev.ryanhcode.sable.sublevel.SubLevel");
        try {
            MethodHandles.publicLookup().findVirtual(containers, "removeSubLevel", MethodType.methodType(void.class, subLevel, reasonType))
                    .invoke(container, body, reason);
        } catch (Throwable exception) { throw new IllegalStateException("Cannot remove test body", exception); }
    }

    private static Object container(GameTestHelper helper) throws ReflectiveOperationException {
        Class<?> containers = Class.forName("dev.ryanhcode.sable.api.sublevel.SubLevelContainer");
        Class<?> serverContainers = Class.forName("dev.ryanhcode.sable.api.sublevel.ServerSubLevelContainer");
        // Exact method handles avoid reflection enumerating the unrelated ClientLevel overload on a dedicated server.
        try {
            return MethodHandles.publicLookup().findStatic(containers, "getContainer", MethodType.methodType(serverContainers, ServerLevel.class))
                    .invoke(helper.getLevel());
        } catch (Throwable exception) { throw new IllegalStateException("Cannot locate Sable server container", exception); }
    }

    private interface CheckedAction { void run() throws ReflectiveOperationException; }
    private static void checked(CheckedAction action) {
        try { action.run(); }
        catch (InvocationTargetException exception) { throw new IllegalStateException("Sable physics integration failed", exception.getCause()); }
        catch (ReflectiveOperationException exception) { throw new IllegalStateException("Sable integration API unavailable", exception); }
    }
}
