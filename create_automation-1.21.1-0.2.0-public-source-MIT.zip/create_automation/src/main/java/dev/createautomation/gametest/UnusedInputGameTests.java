package dev.createautomation.gametest;

import dev.createautomation.engine.Graph;
import dev.createautomation.engine.GraphCodec;
import dev.createautomation.engine.Node;
import dev.createautomation.engine.Op;
import dev.createautomation.registry.ModRegistry;
import dev.createautomation.world.AutomationBlock;
import dev.createautomation.world.AutomationBlockEntity;
import dev.createautomation.world.NodeKind;
import java.util.List;
import java.util.Map;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.gametest.framework.GameTest;
import net.minecraft.gametest.framework.GameTestHelper;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.neoforged.neoforge.gametest.GameTestHolder;
import net.neoforged.neoforge.gametest.PrefixGameTestTemplate;

@GameTestHolder("create_automation")
@PrefixGameTestTemplate(false)
public final class UnusedInputGameTests {
    @GameTest(template="empty",timeoutTicks=60)
    public static void null_ports_only_invalidate_explicit_dependencies(GameTestHelper h) {
        var builder=place(h,NodeKind.SYSTEM_BUILDER,new BlockPos(2,2,2));
        CompoundTag settings=builder.getSettings();
        settings.putString("inputA","  nUlL  "); settings.putString("inputB"," ");
        settings.putString("output","command");
        settings.putString("graph",GraphCodec.toJson(new Graph(List.of(
                new Node("unused",Op.INPUT,List.of(),Map.of("port",0.0)),
                new Node("fixed",Op.CONSTANT,List.of(),Map.of("value",11.5))),"fixed")));
        builder.applySettings(settings);
        h.assertTrue("NULL".equals(builder.getSettings().getString("inputA"))
                && "NULL".equals(builder.getSettings().getString("inputB")),"NULL/blank must normalize to the disconnected sentinel");
        var motor=place(h,NodeKind.RPM_OUTPUT,new BlockPos(5,2,5));
        CompoundTag motorSettings=motor.getSettings(); motorSettings.putString("inputA","command"); motor.applySettings(motorSettings);
        h.runAtTickTime(12,()->{
            CompoundTag state=builder.clientSnapshot();
            h.assertTrue(state.getBoolean("valid") && Math.abs(state.getDouble("value")-11.5)<1e-9,
                    "An unused NULL input node outside the output dependency closure must not contaminate the graph");
            h.assertTrue(state.getBoolean("unusedA")&&!state.getBoolean("validA")&&state.getString("statusA").contains("NULL"),
                    "NULL must remain explicitly unused and invalid, never numeric zero");
            h.assertTrue(Math.abs(motor.getGeneratedSpeed()-11.5)<0.001,"Valid independent graph must drive the real actuator");
            CompoundTag saved=builder.saveWithFullMetadata(h.getLevel().registryAccess());
            var restored=(AutomationBlockEntity)BlockEntity.loadStatic(builder.getBlockPos(),builder.getBlockState(),saved,h.getLevel().registryAccess());
            h.assertTrue(restored!=null&&restored.getSettings().equals(builder.getSettings()),"NULL must persist in actual Minecraft NBT");
            CompoundTag used=builder.getSettings();
            used.putString("graph",GraphCodec.toJson(GraphCodec.preset("passthrough")));
            builder.applySettings(used);
        });
        h.runAtTickTime(24,()->{
            CompoundTag state=builder.clientSnapshot();
            h.assertTrue(!state.getBoolean("valid")&&state.getString("status").contains("NULL"),
                    "Explicit INPUT A reference must report the unused port, not produce zero");
            h.assertTrue(!motor.clientSnapshot().getBoolean("valid")&&motor.getGeneratedSpeed()==0,
                    "A referenced NULL input must stop downstream actuation");
            h.succeed();
        });
    }

    @GameTest(template="empty",timeoutTicks=30)
    public static void null_is_reserved_for_inputs_and_existing_channels_survive(GameTestHelper h) {
        var source=place(h,NodeKind.CONSTANT,new BlockPos(2,2,2));
        for(String key:List.of("inputA","inputB","inputC","inputD"))
            h.assertTrue("NULL".equals(source.getSettings().getString(key)),"A source has no used input ports");
        for(String key:List.of("network","output")) {
            CompoundTag prior=source.getSettings(); CompoundTag invalid=prior.copy(); invalid.putString(key," NuLl ");
            boolean rejected=false;
            try { source.applySettings(invalid); }catch(IllegalArgumentException expected){rejected=true;}
            h.assertTrue(rejected&&source.getSettings().equals(prior),"Reserved NULL publisher/network must reject atomically");
        }
        var old=place(h,NodeKind.SYSTEM_BUILDER,new BlockPos(4,2,2));
        CompoundTag legacy=old.getSettings(); legacy.putString("inputA","old.reference"); legacy.putString("inputB","measurement");
        legacy.putString("inputC","velocity");legacy.putString("inputD","aux");old.applySettings(legacy);
        CompoundTag saved=old.saveWithFullMetadata(h.getLevel().registryAccess());
        var restored=(AutomationBlockEntity)BlockEntity.loadStatic(old.getBlockPos(),old.getBlockState(),saved,h.getLevel().registryAccess());
        h.assertTrue(restored!=null&&restored.getSettings().equals(legacy),"Existing non-NULL channel names must survive save loading");
        h.succeed();
    }

    private static AutomationBlockEntity place(GameTestHelper h,NodeKind kind,BlockPos p) {
        h.setBlock(p,ModRegistry.NODES.get(kind).get().defaultBlockState().setValue(AutomationBlock.FACING,Direction.EAST));
        var entity=(AutomationBlockEntity)h.getLevel().getBlockEntity(h.absolutePos(p));
        CompoundTag settings=entity.getSettings();
        settings.putString("network","unused_"+h.absolutePos(BlockPos.ZERO).asLong());
        settings.putString("output","out_"+p.asLong());
        entity.applySettings(settings);
        return entity;
    }
}
