package dev.createautomation.gametest;

import com.simibubi.create.AllBlocks;
import com.simibubi.create.content.kinetics.base.KineticBlockEntity;
import dev.createautomation.engine.Graph;
import dev.createautomation.engine.GraphCodec;
import dev.createautomation.engine.Node;
import dev.createautomation.engine.Op;
import dev.createautomation.registry.ModRegistry;
import dev.createautomation.world.AutomationBlock;
import dev.createautomation.world.AutomationBlockEntity;
import dev.createautomation.world.NodeKind;
import java.util.List;
import java.util.Map;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.gametest.framework.GameTest;
import net.minecraft.gametest.framework.GameTestHelper;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.neoforged.neoforge.gametest.GameTestHolder;
import net.neoforged.neoforge.gametest.PrefixGameTestTemplate;

/** Actual server-side PI feedback through Create's shaft network and our sampled signal bus. */
@GameTestHolder("create_automation")
@PrefixGameTestTemplate(false)
public final class ClosedLoopGameTests {
    private static final double TARGET_RPM = 64.125;
    private static final BlockPos MOTOR = new BlockPos(5, 2, 4);
    private static final BlockPos SHAFT = new BlockPos(6, 2, 4);
    private static final BlockPos SENSOR = new BlockPos(7, 2, 4);

    private static AutomationBlockEntity place(GameTestHelper helper, NodeKind kind, BlockPos position) {
        helper.setBlock(position, ModRegistry.NODES.get(kind).get().defaultBlockState()
                .setValue(AutomationBlock.FACING, Direction.EAST));
        var entity = (AutomationBlockEntity) helper.getLevel().getBlockEntity(helper.absolutePos(position));
        CompoundTag settings = entity.getSettings();
        settings.putString("network", "closed_loop_" + helper.absolutePos(BlockPos.ZERO).asLong());
        entity.applySettings(settings);
        return entity;
    }

    @GameTest(template = "empty", timeoutTicks = 600)
    public static void rpm_pi_feedback_cold_starts_and_tracks_for_500_ticks(GameTestHelper helper) {
        var source = place(helper, NodeKind.CONSTANT, new BlockPos(1, 2, 1));
        CompoundTag constant = source.getSettings();
        constant.putString("output", "setpoint");
        constant.putDouble("constant", TARGET_RPM);
        source.applySettings(constant);

        var controller = place(helper, NodeKind.SYSTEM_BUILDER, new BlockPos(3, 2, 1));
        Graph graph = new Graph(List.of(
                new Node("reference", Op.INPUT, List.of(), Map.of("port", 0.0)),
                new Node("measured", Op.INPUT, List.of(), Map.of("port", 1.0)),
                new Node("pi", Op.PID, List.of("reference", "measured"),
                        Map.of("kp", .15, "ki", .4, "kd", 0.0, "min", -256.0, "max", 256.0))), "pi");
        CompoundTag control = controller.getSettings();
        control.putString("inputA", "setpoint");
        control.putString("inputB", "feedback");
        control.putString("output", "command");
        control.putString("graph", GraphCodec.toJson(graph));
        controller.applySettings(control);

        var motor = place(helper, NodeKind.RPM_OUTPUT, MOTOR);
        CompoundTag actuator = motor.getSettings();
        actuator.putString("inputA", "command");
        motor.applySettings(actuator);
        helper.setBlock(SHAFT, AllBlocks.SHAFT.get().defaultBlockState()
                .setValue(BlockStateProperties.AXIS, Direction.Axis.X));
        var detector = place(helper, NodeKind.RPM_SENSOR, SENSOR);
        CompoundTag sensor = detector.getSettings();
        sensor.putString("output", "feedback");
        detector.applySettings(sensor);

        // EAST is the positive X axis in Create.convertToDirection, so no absolute-value shortcut
        // is allowed here: a wrong physical sign must fail the negative-feedback test.
        helper.assertTrue(KineticBlockEntity.convertToDirection(1, Direction.EAST) == 1,
                "EAST output must preserve the commanded RPM sign");
        double[] earlyError = {Double.NaN};
        for (int tick = 20; tick <= 520; tick++) {
            final int currentTick = tick;
            helper.runAtTickTime(tick, () -> {
                helper.assertTrue(helper.getLevel().getBlockEntity(helper.absolutePos(MOTOR)) == motor,
                        "RPM motor must survive continuous PI retuning at tick " + currentTick);
                helper.assertTrue(helper.getLevel().getBlockEntity(helper.absolutePos(SENSOR)) == detector,
                        "RPM detector must survive continuous PI retuning at tick " + currentTick);
                helper.assertTrue(helper.getLevel().getBlockState(helper.absolutePos(SHAFT)).is(AllBlocks.SHAFT.get()),
                        "Real Create shaft must not be destroyed by synthetic flicker at tick " + currentTick);
                helper.assertTrue(controller.clientSnapshot().getBoolean("valid") && motor.clientSnapshot().getBoolean("valid")
                                && detector.clientSnapshot().getBoolean("valid"),
                        "Cold-started feedback must remain valid at tick " + currentTick);
                double actual = detector.getSpeed();
                helper.assertTrue(Double.isFinite(actual) && actual > 0 && actual <= 256,
                        "Physical shaft must rotate in the positive feedback direction: " + actual);
                helper.assertTrue(Math.abs(actual - motor.getSpeed()) < .001,
                        "Motor and downstream physical shaft must agree");
                double error = Math.abs(TARGET_RPM - actual);
                if (currentTick == 100) earlyError[0] = error;
                if (currentTick >= 500) {
                    helper.assertTrue(error < .02, "500-tick actual RPM tracking error must be <0.02; got " + error);
                    helper.assertTrue(error < earlyError[0], "Feedback must reduce measured error, not merely remain valid");
                }
                if (currentTick == 520) helper.succeed();
            });
        }
    }
}
