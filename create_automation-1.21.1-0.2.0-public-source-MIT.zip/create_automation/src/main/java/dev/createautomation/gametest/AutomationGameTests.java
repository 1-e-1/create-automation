package dev.createautomation.gametest;

import dev.createautomation.engine.Graph;
import dev.createautomation.engine.GraphCodec;
import dev.createautomation.engine.Node;
import dev.createautomation.engine.Op;
import dev.createautomation.registry.ModRegistry;
import dev.createautomation.world.AutomationBlock;
import dev.createautomation.world.AutomationBlockEntity;
import dev.createautomation.world.NodeKind;
import java.util.List;
import java.util.Map;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.gametest.framework.GameTest;
import net.minecraft.gametest.framework.GameTestHelper;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.level.block.Blocks;
import net.neoforged.neoforge.gametest.GameTestHolder;
import net.neoforged.neoforge.gametest.PrefixGameTestTemplate;

/** Real server tests: these inspect actual block entities, kinetic networks and redstone output. */
@GameTestHolder("create_automation")
@PrefixGameTestTemplate(false)
public final class AutomationGameTests {
    private static AutomationBlockEntity place(GameTestHelper h, NodeKind kind, BlockPos p) {
        h.setBlock(p, ModRegistry.NODES.get(kind).get().defaultBlockState()
                .setValue(AutomationBlock.FACING, Direction.EAST));
        var be = (AutomationBlockEntity) h.getLevel().getBlockEntity(h.absolutePos(p));
        CompoundTag settings = be.getSettings();
        settings.putString("network", "test_" + h.absolutePos(BlockPos.ZERO).asLong());
        be.applySettings(settings);
        return be;
    }

    private static void config(AutomationBlockEntity be, String input, String output, double constant) {
        CompoundTag settings = be.getSettings();
        settings.putString("inputA", input);
        settings.putString("output", output);
        settings.putDouble("constant", constant);
        be.applySettings(settings);
    }

    private static void near(GameTestHelper h, double actual, double expected, double tolerance, String message) {
        h.assertTrue(Double.isFinite(actual) && Math.abs(actual - expected) < tolerance,
                message + ": expected " + expected + ", got " + actual);
    }

    @GameTest(template = "empty", timeoutTicks = 100)
    public static void fractional_signal_drives_real_create_shaft(GameTestHelper h) {
        var source = place(h, NodeKind.CONSTANT, new BlockPos(1,2,1));
        config(source,"unused","reference",47.125);
        var output = place(h, NodeKind.SYSTEM_OUTPUT, new BlockPos(3,2,1));
        config(output,"reference","rpm",0);
        var motor = place(h, NodeKind.RPM_OUTPUT, new BlockPos(5,2,4));
        config(motor,"rpm","unused",0);
        var detector = place(h, NodeKind.RPM_SENSOR, new BlockPos(6,2,4));
        config(detector,"unused","measured",0);
        h.runAtTickTime(25, () -> {
            h.assertTrue(motor.clientSnapshot().getBoolean("valid"),"Motor must have a valid numeric command");
            near(h,Math.abs(motor.getSpeed()),47.125,0.001,"Actual motor RPM");
            near(h,Math.abs(detector.getSpeed()),47.125,0.001,"Connected Create shaft RPM");
            near(h,Math.abs(detector.clientSnapshot().getDouble("value")),47.125,0.001,"RPM feedback");
            h.succeed();
        });
    }

    @GameTest(template = "empty", timeoutTicks = 100)
    public static void custom_graph_runs_on_the_server(GameTestHelper h) {
        var source = place(h, NodeKind.CONSTANT, new BlockPos(1,2,1));
        config(source,"unused","reference",12.345);
        var builder = place(h, NodeKind.SYSTEM_BUILDER, new BlockPos(3,2,1));
        var graph = new Graph(List.of(
                new Node("external",Op.INPUT,List.of(),Map.of("port",0.0)),
                new Node("offset",Op.CONSTANT,List.of(),Map.of("value",0.125)),
                new Node("sum",Op.ADD,List.of("external","offset"),Map.of()),
                new Node("gain",Op.GAIN,List.of("sum"),Map.of("gain",2.0))),"gain");
        CompoundTag settings=builder.getSettings();
        settings.putString("inputA","reference"); settings.putString("output","result");
        settings.putString("graph", GraphCodec.toJson(graph)); builder.applySettings(settings);
        var monitor=place(h,NodeKind.MONITOR,new BlockPos(5,2,1));
        config(monitor,"result","unused",0);
        h.runAtTickTime(15,()->{
            h.assertTrue(monitor.clientSnapshot().getBoolean("valid"),"Custom graph output must reach monitor");
            near(h,monitor.clientSnapshot().getDouble("value"),24.94,1e-9,"Graph value");
            h.succeed();
        });
    }

    @GameTest(template = "empty", timeoutTicks = 100)
    public static void redstone_bridges_scale_without_internal_quantization(GameTestHelper h) {
        BlockPos inputPosition=new BlockPos(2,2,2);
        var input=place(h,NodeKind.REDSTONE_INPUT,inputPosition);
        CompoundTag inputConfig=input.getSettings(); inputConfig.putDouble("scale",0.1);
        inputConfig.putString("output","analog"); input.applySettings(inputConfig);
        h.setBlock(inputPosition.west(),Blocks.REDSTONE_BLOCK);
        var output=place(h,NodeKind.REDSTONE_OUTPUT,new BlockPos(7,2,2));
        CompoundTag outputConfig=output.getSettings(); outputConfig.putString("inputA","analog");
        outputConfig.putDouble("scale",10); output.applySettings(outputConfig);
        h.runAtTickTime(15,()->{
            near(h,input.clientSnapshot().getDouble("value"),1.5,1e-12,"Bridge internal double");
            h.assertTrue(output.redstoneLevel()==15,"Redstone output must reach 15");
            int actual=h.getLevel().getSignal(h.absolutePos(new BlockPos(7,2,2)),Direction.EAST);
            h.assertTrue(actual==15,"World redstone API must see 15, not just UI state");
            h.setBlock(inputPosition.west(),Blocks.AIR);
        });
        h.runAtTickTime(25,()->{
            h.assertTrue(output.redstoneLevel()==0,"Removing redstone input must clear output");
            h.succeed();
        });
    }

    @GameTest(template = "empty", timeoutTicks = 100)
    public static void disconnected_and_conflicting_sources_stop_actuator(GameTestHelper h) {
        BlockPos first=new BlockPos(1,2,1),second=new BlockPos(3,2,1);
        var a=place(h,NodeKind.CONSTANT,first); config(a,"unused","rpm",32.75);
        var motor=place(h,NodeKind.RPM_OUTPUT,new BlockPos(6,2,4)); config(motor,"rpm","unused",0);
        h.runAtTickTime(12,()->{
            near(h,Math.abs(motor.getSpeed()),32.75,0.001,"Initial motor command");
            var b=place(h,NodeKind.CONSTANT,second); config(b,"unused","rpm",99.5);
        });
        h.runAtTickTime(22,()->{
            h.assertTrue(!motor.clientSnapshot().getBoolean("valid"),"Conflicting publishers must invalidate");
            near(h,motor.getGeneratedSpeed(),0,0.001,"Conflict must stop output");
            h.setBlock(second,Blocks.AIR);
        });
        h.runAtTickTime(32,()->{
            near(h,Math.abs(motor.getSpeed()),32.75,0.001,"Single source recovers");
            h.setBlock(first,Blocks.AIR);
        });
        h.runAtTickTime(42,()->{
            h.assertTrue(!motor.clientSnapshot().getBoolean("valid"),"Missing source must invalidate");
            near(h,motor.getGeneratedSpeed(),0,0.001,"Missing source stops output");
            h.succeed();
        });
    }

    @GameTest(template = "empty", timeoutTicks = 60)
    public static void motion_detector_does_not_fabricate_measurements(GameTestHelper h) {
        var detector=place(h,NodeKind.MOTION_SENSOR,new BlockPos(2,2,2));
        h.runAtTickTime(10,()->{
            h.assertTrue(!detector.clientSnapshot().getBoolean("valid"),"Unassembled detector must report unavailable");
            h.assertTrue(!detector.clientSnapshot().getString("status").isBlank(),"Unavailable sensor needs explanation");
            h.succeed();
        });
    }
}
