package dev.createautomation.gametest;

import com.simibubi.create.AllBlocks;
import com.simibubi.create.content.kinetics.base.KineticBlockEntity;
import dev.createautomation.engine.Graph;
import dev.createautomation.engine.GraphCodec;
import dev.createautomation.engine.Node;
import dev.createautomation.engine.Op;
import dev.createautomation.registry.ModRegistry;
import dev.createautomation.world.AutomationBlock;
import dev.createautomation.world.AutomationBlockEntity;
import dev.createautomation.world.NodeKind;
import java.util.List;
import java.util.Map;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.gametest.framework.GameTest;
import net.minecraft.gametest.framework.GameTestHelper;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.neoforged.neoforge.gametest.GameTestHolder;
import net.neoforged.neoforge.gametest.PrefixGameTestTemplate;

@GameTestHolder("create_automation")
@PrefixGameTestTemplate(false)
public final class DynamicRotationGameTests {
    @GameTest(template = "empty", timeoutTicks = 600)
    public static void sustained_fractional_control_does_not_destroy_real_shafts(GameTestHelper helper) {
        String network = "ramp_" + helper.absolutePos(BlockPos.ZERO).asLong();
        BlockPos builderPos = new BlockPos(1,2,1), motorPos = new BlockPos(3,2,4),
                shaftPos = motorPos.east(), sensorPos = shaftPos.east();
        var builder = place(helper, NodeKind.SYSTEM_BUILDER, builderPos, network);
        var graph = new Graph(List.of(
                new Node("rate", Op.CONSTANT, List.of(), Map.of("value",1.2345)),
                new Node("ramp", Op.INTEGRATE, List.of("rate"), Map.of("initial",40.0,"min",0.0,"max",200.0))), "ramp");
        CompoundTag settings = builder.getSettings();
        settings.putString("graph", GraphCodec.toJson(graph));
        settings.putString("output", "rpm");
        builder.applySettings(settings);
        var motor = place(helper, NodeKind.RPM_OUTPUT, motorPos, network);
        settings = motor.getSettings(); settings.putString("inputA", "rpm"); motor.applySettings(settings);
        helper.setBlock(shaftPos, AllBlocks.SHAFT.get().defaultBlockState().setValue(BlockStateProperties.AXIS, Direction.Axis.X));
        var sensor = place(helper, NodeKind.RPM_SENSOR, sensorPos, network);
        settings = sensor.getSettings(); settings.putString("output", "feedback"); sensor.applySettings(settings);

        helper.runAtTickTime(520, () -> {
            var actualMotor = helper.getLevel().getBlockEntity(helper.absolutePos(motorPos));
            var actualShaft = helper.getLevel().getBlockEntity(helper.absolutePos(shaftPos));
            var actualSensor = helper.getLevel().getBlockEntity(helper.absolutePos(sensorPos));
            helper.assertTrue(actualMotor == motor, "Servo must survive over 500 continuously changing commands");
            helper.assertTrue(actualShaft instanceof KineticBlockEntity, "Vanilla Create shaft must survive continuous retuning");
            helper.assertTrue(actualSensor == sensor, "Feedback sensor must survive continuous retuning");
            var shaft = (KineticBlockEntity) actualShaft;
            double target = builder.clientSnapshot().getDouble("value");
            helper.assertTrue(target > 65, "Integrator must genuinely vary the target for hundreds of ticks");
            helper.assertTrue(Math.abs(Math.abs(shaft.getSpeed()) - target) < 0.2,
                    "Actual shaft must track the changing fractional target: target=" + target + " shaft=" + shaft.getSpeed());
            helper.assertTrue(Math.abs(Math.abs(sensor.getSpeed()) - target) < 0.2, "Feedback shaft follows target");
            helper.assertTrue(shaft.getFlickerScore() < 20, "Internal detach/reattach must not accumulate false flicker");
            helper.succeed();
        });
    }

    private static AutomationBlockEntity place(GameTestHelper helper, NodeKind kind, BlockPos pos, String network) {
        helper.setBlock(pos, ModRegistry.NODES.get(kind).get().defaultBlockState().setValue(AutomationBlock.FACING, Direction.EAST));
        var result = (AutomationBlockEntity) helper.getLevel().getBlockEntity(helper.absolutePos(pos));
        CompoundTag settings = result.getSettings(); settings.putString("network", network); result.applySettings(settings);
        return result;
    }
}
