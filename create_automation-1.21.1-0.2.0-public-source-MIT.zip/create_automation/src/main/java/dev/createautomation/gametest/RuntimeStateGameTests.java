package dev.createautomation.gametest;

import dev.createautomation.engine.GraphCodec;
import dev.createautomation.registry.ModRegistry;
import dev.createautomation.world.AutomationBlock;
import dev.createautomation.world.AutomationBlockEntity;
import dev.createautomation.world.NodeKind;
import java.util.LinkedHashMap;
import java.util.Map;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.gametest.framework.GameTest;
import net.minecraft.gametest.framework.GameTestHelper;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.neoforged.neoforge.gametest.GameTestHolder;
import net.neoforged.neoforge.gametest.PrefixGameTestTemplate;

@GameTestHolder("create_automation")
@PrefixGameTestTemplate(false)
public final class RuntimeStateGameTests {
    private static AutomationBlockEntity place(GameTestHelper h, NodeKind kind, BlockPos p, Direction facing,
                                                String input, String output, double value) {
        h.setBlock(p, ModRegistry.NODES.get(kind).get().defaultBlockState().setValue(AutomationBlock.FACING, facing));
        var entity = (AutomationBlockEntity) h.getLevel().getBlockEntity(h.absolutePos(p));
        CompoundTag settings = entity.getSettings();
        settings.putString("network", "state_" + h.absolutePos(BlockPos.ZERO).asLong());
        settings.putString("inputA", input);
        settings.putString("output", output);
        settings.putDouble("constant", value);
        entity.applySettings(settings);
        return entity;
    }

    private static void near(GameTestHelper h, double value, double target, String label) {
        h.assertTrue(Double.isFinite(value) && Math.abs(value - target) < 0.001,
                label + ": expected " + target + ", got " + value);
    }

    @GameTest(template = "empty", timeoutTicks = 80)
    public static void facing_and_negative_fractional_rpm_have_explicit_signs(GameTestHelper h) {
        var source = place(h, NodeKind.CONSTANT, new BlockPos(1,2,1), Direction.EAST,"unused","rpm",37.625);
        var east = place(h, NodeKind.RPM_OUTPUT, new BlockPos(3,2,3), Direction.EAST,"rpm","unused",0);
        var eastSensor = place(h, NodeKind.RPM_SENSOR, new BlockPos(4,2,3), Direction.EAST,"unused","east",0);
        var west = place(h, NodeKind.RPM_OUTPUT, new BlockPos(8,2,6), Direction.WEST,"rpm","unused",0);
        var westSensor = place(h, NodeKind.RPM_SENSOR, new BlockPos(7,2,6), Direction.WEST,"unused","west",0);
        h.runAtTickTime(16, () -> {
            near(h,east.getSpeed(),37.625,"East motor world-axis speed");
            near(h,eastSensor.clientSnapshot().getDouble("value"),37.625,"East feedback");
            near(h,west.getSpeed(),-37.625,"West motor world-axis speed");
            near(h,westSensor.clientSnapshot().getDouble("value"),-37.625,"West feedback");
            CompoundTag settings=source.getSettings();
            settings.putDouble("constant",-37.625); source.applySettings(settings);
        });
        h.runAtTickTime(32, () -> {
            near(h,east.getSpeed(),-37.625,"East reversed motor");
            near(h,eastSensor.getSpeed(),-37.625,"East reversed shaft");
            near(h,west.getSpeed(),37.625,"West reversed motor");
            near(h,westSensor.getSpeed(),37.625,"West reversed shaft");
            h.succeed();
        });
    }

    @GameTest(template = "empty", timeoutTicks = 80)
    public static void serialized_configuration_recovers_a_running_network(GameTestHelper h) {
        BlockPos sourcePos=new BlockPos(1,2,1), builderPos=new BlockPos(3,2,1), motorPos=new BlockPos(5,2,4);
        Map<BlockPos,AutomationBlockEntity> originals=new LinkedHashMap<>();
        originals.put(sourcePos,place(h,NodeKind.CONSTANT,sourcePos,Direction.EAST,"unused","reference",7.8125));
        originals.put(builderPos,place(h,NodeKind.SYSTEM_BUILDER,builderPos,Direction.EAST,"reference","rpm",0));
        originals.put(motorPos,place(h,NodeKind.RPM_OUTPUT,motorPos,Direction.EAST,"rpm","unused",0));
        Map<BlockPos,CompoundTag> saved=new LinkedHashMap<>();
        Map<BlockPos,BlockState> states=new LinkedHashMap<>();
        h.runAtTickTime(18, () -> {
            near(h,originals.get(motorPos).getSpeed(),7.8125,"Network before serialization");
            originals.forEach((position,entity)->{
                saved.put(position,entity.saveWithFullMetadata(h.getLevel().registryAccess()));
                states.put(position,entity.getBlockState());
                h.setBlock(position,Blocks.AIR);
            });
            saved.forEach((position,tag)->{
                BlockState state=states.get(position);
                h.setBlock(position,state);
                BlockEntity restored=BlockEntity.loadStatic(h.absolutePos(position),state,tag,h.getLevel().registryAccess());
                h.assertTrue(restored instanceof AutomationBlockEntity,"Registered block entity must deserialize");
                h.getLevel().setBlockEntity(restored);
                h.assertTrue(((AutomationBlockEntity)restored).getSettings().equals(originals.get(position).getSettings()),
                        "Configuration must survive real Minecraft NBT serialization");
            });
        });
        h.runAtTickTime(40, () -> {
            var motor=(AutomationBlockEntity)h.getLevel().getBlockEntity(h.absolutePos(motorPos));
            h.assertTrue(motor.clientSnapshot().getBoolean("valid"),"Reloaded bus must recover without manual resave");
            near(h,motor.getSpeed(),7.8125,"Reloaded real kinetic network");
            h.succeed();
        });
    }

    @GameTest(template = "empty", timeoutTicks = 30)
    public static void all_blocks_preserve_settings_and_reject_bad_updates(GameTestHelper h) {
        int index=0;
        for(NodeKind kind:NodeKind.values()) {
            BlockPos position=new BlockPos(1+(index%4)*3,2,1+(index/4)*3); index++;
            var entity=place(h,kind,position,Direction.NORTH,"in","out_"+index,-12.345);
            CompoundTag valid=entity.getSettings(); valid.putDouble("scale",0.125);
            valid.putString("graph",GraphCodec.toJson(GraphCodec.preset("sum")));
            valid.putBoolean("enabled",false); entity.applySettings(valid);
            CompoundTag saved=entity.saveWithFullMetadata(h.getLevel().registryAccess());
            var copy=(AutomationBlockEntity)BlockEntity.loadStatic(entity.getBlockPos(),entity.getBlockState(),saved,h.getLevel().registryAccess());
            h.assertTrue(copy!=null && copy.getSettings().equals(entity.getSettings()),kind+" saved fields differ");
            CompoundTag invalid=valid.copy(); invalid.putDouble("scale",Double.NaN);
            boolean rejected=false;
            try { entity.applySettings(invalid); } catch(IllegalArgumentException expected) { rejected=true; }
            h.assertTrue(rejected && entity.getSettings().equals(valid),kind+" invalid update must be atomic");
        }
        h.succeed();
    }
}
