package dev.createautomation.gametest;

import dev.createautomation.registry.ModRegistry;
import dev.createautomation.world.AutomationBlockEntity;
import dev.createautomation.world.MotionBridge;
import dev.createautomation.world.NodeKind;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.gametest.framework.GameTest;
import net.minecraft.gametest.framework.GameTestHelper;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.Unit;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.neoforged.fml.ModList;
import net.neoforged.neoforge.gametest.GameTestHolder;
import net.neoforged.neoforge.gametest.PrefixGameTestTemplate;
import org.joml.Vector3d;
import org.joml.Vector3dc;

/** New sensors sample a real assembled Sable body, not a synthetic pose or numeric stand-in. */
@GameTestHolder("create_automation")
@PrefixGameTestTemplate(false)
public final class BodySensorGameTests {
    @GameTest(template = "empty", timeoutTicks = 100)
    public static void dedicated_sensors_share_body_reference_and_physics(GameTestHelper h) {
        h.assertTrue(ModList.get().isLoaded("sable"), "Integration test requires Sable 2.0.6");
        BlockPos anchor = h.absolutePos(new BlockPos(2, 48, 2));
        BlockPos[] positions = {anchor, anchor.offset(4, 0, 0), anchor.offset(1, 0, 0), anchor.offset(3, 0, 0)};
        NodeKind[] kinds = {NodeKind.HEIGHT_SENSOR, NodeKind.HEIGHT_SENSOR, NodeKind.SPEED_SENSOR, NodeKind.ATTITUDE_SENSOR};
        List<BlockPos> assembly = new ArrayList<>();
        for (int i = 0; i < 5; i++) {
            BlockPos p = anchor.offset(i, -1, 0);
            h.getLevel().setBlockAndUpdate(p, Blocks.STONE.defaultBlockState());
            assembly.add(p);
        }
        for (int i = 0; i < positions.length; i++) {
            h.getLevel().setBlockAndUpdate(positions[i], ModRegistry.NODES.get(kinds[i]).get().defaultBlockState());
            AutomationBlockEntity entity = (AutomationBlockEntity) h.getLevel().getBlockEntity(positions[i]);
            CompoundTag settings = entity.getSettings();
            settings.putString("network", "body_sensor_" + anchor.asLong());
            settings.putString("output", "sensor_" + i);
            entity.applySettings(settings);
            assembly.add(positions[i]);
        }
        Object[] body = new Object[1];
        AutomationBlockEntity[] sensors = new AutomationBlockEntity[4];
        double[] origin = new double[1];
        h.runAtTickTime(5, () -> checked(() -> {
            Class<?> boundsType = Class.forName("dev.ryanhcode.sable.companion.math.BoundingBox3i");
            Class<?> boundsInterface = Class.forName("dev.ryanhcode.sable.companion.math.BoundingBox3ic");
            Object bounds = boundsType.getConstructor(BlockPos.class, BlockPos.class)
                    .newInstance(anchor.below(), anchor.offset(4, 0, 0));
            Class<?> helper = Class.forName("dev.ryanhcode.sable.api.SubLevelAssemblyHelper");
            body[0] = helper.getMethod("assembleBlocks", ServerLevel.class, BlockPos.class, Iterable.class, boundsInterface)
                    .invoke(null, h.getLevel(), anchor, assembly, bounds);
            Class<?> serverBody = Class.forName("dev.ryanhcode.sable.sublevel.ServerSubLevel");
            Class<?> ticket = Class.forName("dev.ryanhcode.sable.api.sublevel.ticket.SubLevelLoadingTicketType");
            Object container = container(h);
            container.getClass().getMethod("addForceLoadTicket", serverBody, ticket, Object.class)
                    .invoke(container, body[0], ticket.getField("COMMAND_FORCED").get(null), Unit.INSTANCE);
            Object plot = body[0].getClass().getMethod("getPlot").invoke(body[0]);
            BlockPos migrated = (BlockPos) plot.getClass().getMethod("getCenterBlock").invoke(plot);
            for (int i = 0; i < sensors.length; i++) {
                sensors[i] = (AutomationBlockEntity) h.getLevel().getBlockEntity(migrated.offset(positions[i].subtract(anchor)));
                h.assertTrue(sensors[i] != null, "Actual detector must migrate with body: " + i);
            }
        }));
        h.runAtTickTime(12, () -> checked(() -> {
            MotionBridge.Sample sample = MotionBridge.sampleBody(sensors[0]);
            h.assertTrue(sample.valid(), "Assembled body must provide a rigid-body sample: " + sample.status());
            origin[0] = sample.height();
            mode(sensors[0], "RELATIVE_HEIGHT", true);
            mode(sensors[2], "VELOCITY_X", false);
            CompoundTag saved = sensors[0].saveWithFullMetadata(h.getLevel().registryAccess());
            var restored = (AutomationBlockEntity) BlockEntity.loadStatic(sensors[0].getBlockPos(), sensors[0].getBlockState(),
                    saved, h.getLevel().registryAccess());
            h.assertTrue(restored != null && restored.getSettings().equals(sensors[0].getSettings()), "Height mode must survive NBT");
            h.assertTrue(restored.clientSnapshot().getBoolean("calibrated"), "Height calibration must survive NBT");
            near(h, restored.clientSnapshot().getDouble("originY"), origin[0], 1e-9, "Persisted zero reference");
            Object handle = handle(body[0]);
            handle.getClass().getMethod("addLinearAndAngularVelocity", Vector3dc.class, Vector3dc.class)
                    .invoke(handle, new Vector3d(3.25, 1.0, -0.75), new Vector3d(0.2, 0.1, 0.6));
        }));
        h.runAtTickTime(24, () -> checked(() -> {
            MotionBridge.Sample a = MotionBridge.sampleBody(sensors[0]);
            MotionBridge.Sample b = MotionBridge.sampleBody(sensors[1]);
            h.assertTrue(a.valid() && b.valid() && a.body().equals(b.body()), "Separated detectors must report one body");
            near(h, a.height(), b.height(), 1e-9, "Whole-body height must be independent of mounting position");
            near(h, a.vx(), b.vx(), 1e-9, "Whole-body translation must be independent of mounting position");
            near(h, a.roll(), b.roll(), 1e-9, "Whole-body attitude must be independent of mounting position");
            h.assertTrue(Math.abs(MotionBridge.sample(sensors[0]).height() - MotionBridge.sample(sensors[1]).height()) > 0.2,
                    "Rotation must separate physical block heights, proving the body reference is not the detector point");
            value(h, sensors[0], a.height() - origin[0], 1.5, "Relative whole-body height");
            value(h, sensors[1], a.height(), 1.5, "World-Y whole-body height");
            value(h, sensors[2], a.vx(), 0.5, "Actual world-X velocity");
            value(h, sensors[3], a.roll(), 5, "Actual roll degrees");
            Vector3dc velocity = (Vector3dc) handle(body[0]).getClass().getMethod("getLinearVelocity").invoke(handle(body[0]));
            near(h, a.vx(), velocity.x(), 1e-9, "Rigid-body native velocity");
            mode(sensors[2], "VELOCITY_Y", false);
            mode(sensors[3], "PITCH", false);
        }));
        h.runAtTickTime(32, () -> {
            MotionBridge.Sample sample = MotionBridge.sampleBody(sensors[2]);
            value(h, sensors[2], sample.vy(), 0.75, "Actual world-Y velocity");
            value(h, sensors[3], sample.pitch(), 5, "Actual pitch degrees");
            mode(sensors[2], "VELOCITY_Z", false);
            mode(sensors[3], "YAW", false);
        });
        h.runAtTickTime(40, () -> {
            MotionBridge.Sample sample = MotionBridge.sampleBody(sensors[2]);
            value(h, sensors[2], sample.vz(), 0.5, "Actual world-Z velocity");
            value(h, sensors[3], sample.yaw(), 5, "Actual yaw degrees");
            mode(sensors[2], "SPEED", false);
        });
        h.runAtTickTime(48, () -> checked(() -> {
            MotionBridge.Sample sample = MotionBridge.sampleBody(sensors[2]);
            value(h, sensors[2], Math.sqrt(sample.vx()*sample.vx()+sample.vy()*sample.vy()+sample.vz()*sample.vz()), 0.75,
                    "Whole-body speed magnitude");
            h.assertTrue(sensors[0].clientSnapshot().getString("reference").contains("rigid-body"), "Reference must be explicit");
            Class<?> containers = Class.forName("dev.ryanhcode.sable.api.sublevel.SubLevelContainer");
            Class<?> reasonType = Class.forName("dev.ryanhcode.sable.sublevel.storage.SubLevelRemovalReason");
            Object reason = reasonType.getField("REMOVED").get(null);
            Class<?> subLevel = Class.forName("dev.ryanhcode.sable.sublevel.SubLevel");
            try {
                MethodHandles.publicLookup().findVirtual(containers, "removeSubLevel", MethodType.methodType(void.class, subLevel, reasonType))
                        .invoke(container(h), body[0], reason);
            } catch (Throwable error) { throw new IllegalStateException("Cannot remove test body", error); }
            h.succeed();
        }));
    }

    @GameTest(template = "empty", timeoutTicks = 30)
    public static void dedicated_sensors_reject_unassembled_blocks(GameTestHelper h) {
        NodeKind[] kinds = {NodeKind.HEIGHT_SENSOR, NodeKind.SPEED_SENSOR, NodeKind.ATTITUDE_SENSOR};
        AutomationBlockEntity[] sensors = new AutomationBlockEntity[3];
        for (int i=0;i<3;i++) {
            BlockPos p = new BlockPos(2+i*2, 2, 2);
            h.setBlock(p, ModRegistry.NODES.get(kinds[i]).get().defaultBlockState());
            sensors[i] = (AutomationBlockEntity) h.getLevel().getBlockEntity(h.absolutePos(p));
            CompoundTag settings = sensors[i].getSettings();
            settings.putString("network", "unassembled_"+h.absolutePos(BlockPos.ZERO).asLong());
            settings.putString("output", "sensor_"+i);
            sensors[i].applySettings(settings);
        }
        h.runAtTickTime(10, () -> {
            for (AutomationBlockEntity sensor:sensors) {
                CompoundTag state=sensor.clientSnapshot();
                h.assertTrue(!state.getBoolean("valid") && state.getString("status").contains("no moving body"),
                        "Unassembled "+sensor.getNodeKind()+" must explain unavailable data");
            }
            CompoundTag prior=sensors[0].getSettings();
            CompoundTag request=prior.copy(); request.putBoolean("calibrate", true);
            boolean rejected=false;
            try { sensors[0].applySettings(request); } catch(IllegalArgumentException expected) { rejected=true; }
            h.assertTrue(rejected && prior.equals(sensors[0].getSettings()), "Unavailable calibration must reject atomically");
            h.succeed();
        });
    }

    private static void mode(AutomationBlockEntity sensor,String mode,boolean calibrate) {
        CompoundTag settings=sensor.getSettings(); settings.putString("mode",mode);
        if(calibrate)settings.putBoolean("calibrate",true);
        sensor.applySettings(settings);
    }
    private static void value(GameTestHelper h,AutomationBlockEntity sensor,double expected,double tolerance,String label) {
        CompoundTag snapshot=sensor.clientSnapshot();
        h.assertTrue(snapshot.getBoolean("valid"),label+": "+snapshot.getString("status"));
        near(h,snapshot.getDouble("value"),expected,tolerance,label);
    }
    private static void near(GameTestHelper h,double actual,double expected,double tolerance,String label) {
        h.assertTrue(Double.isFinite(actual)&&Double.isFinite(expected)&&Math.abs(actual-expected)<tolerance,
                label+": expected "+expected+", got "+actual);
    }
    private static Object handle(Object body)throws ReflectiveOperationException {
        return Class.forName("dev.ryanhcode.sable.api.physics.handle.RigidBodyHandle")
                .getMethod("of",Class.forName("dev.ryanhcode.sable.sublevel.ServerSubLevel")).invoke(null,body);
    }
    private static Object container(GameTestHelper h)throws ReflectiveOperationException {
        Class<?> containers=Class.forName("dev.ryanhcode.sable.api.sublevel.SubLevelContainer");
        Class<?> serverContainers=Class.forName("dev.ryanhcode.sable.api.sublevel.ServerSubLevelContainer");
        try {
            return MethodHandles.publicLookup().findStatic(containers,"getContainer",MethodType.methodType(serverContainers,ServerLevel.class))
                    .invoke(h.getLevel());
        } catch(Throwable error) { throw new IllegalStateException("Cannot locate Sable server container",error); }
    }
    private interface Action { void run()throws ReflectiveOperationException; }
    private static void checked(Action action) {
        try { action.run(); }
        catch(InvocationTargetException error) { throw new IllegalStateException("Sable physics test failed",error.getCause()); }
        catch(ReflectiveOperationException error) { throw new IllegalStateException("Sable test API unavailable",error); }
    }
}
