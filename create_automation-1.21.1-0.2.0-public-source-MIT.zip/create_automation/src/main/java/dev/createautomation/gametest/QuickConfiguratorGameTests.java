package dev.createautomation.gametest;

import com.simibubi.create.AllBlocks;
import com.simibubi.create.content.kinetics.base.KineticBlockEntity;
import dev.createautomation.engine.QuickSettings;
import dev.createautomation.engine.QuickSettingsCodec;
import dev.createautomation.registry.ModRegistry;
import dev.createautomation.world.AutomationBlock;
import dev.createautomation.world.AutomationBlockEntity;
import dev.createautomation.world.NodeKind;
import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.gametest.framework.GameTest;
import net.minecraft.gametest.framework.GameTestHelper;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.neoforged.neoforge.gametest.GameTestHolder;
import net.neoforged.neoforge.gametest.PrefixGameTestTemplate;

/** Exercises the configured block, numerical bus, monitor and real Create shaft together. */
@GameTestHolder("create_automation")
@PrefixGameTestTemplate(false)
public final class QuickConfiguratorGameTests {
    @GameTest(template="empty", timeoutTicks=200)
    public static void quick_closed_loop_drives_real_rpm_and_resets_after_disconnect(GameTestHelper h) {
        BlockPos sourcePos=new BlockPos(1,2,1),shaftPos=new BlockPos(4,2,5);
        source(h,sourcePos);
        var quick=place(h,NodeKind.QUICK_CONFIGURATOR,new BlockPos(3,2,1));
        CompoundTag settings=quick.getSettings();
        settings.putString("inputA","setpoint"); settings.putString("output","command");
        settings.putString("quick",QuickSettingsCodec.toJson(new QuickSettings(QuickSettings.Mode.CLOSED_LOOP,
                2,List.of(),List.of(new QuickSettings.Root(-1,0)))));
        quick.applySettings(settings); // L(s)=2/(s+1), T(s)=2/(s+3), A=3 -> Y(infinity)=2.
        var monitor=place(h,NodeKind.MONITOR,new BlockPos(5,2,1));
        input(monitor,"command");
        var motor=place(h,NodeKind.RPM_OUTPUT,new BlockPos(3,2,5));
        input(motor,"command");
        h.setBlock(shaftPos,AllBlocks.SHAFT.get().defaultBlockState().setValue(BlockStateProperties.AXIS,Direction.Axis.X));
        var sensor=place(h,NodeKind.RPM_SENSOR,new BlockPos(5,2,5));
        settings=sensor.getSettings();settings.putString("output","actual_rpm");sensor.applySettings(settings);
        boolean[] sawFirstRecoveredSample={false};

        h.runAtTickTime(80,()->{
            validNear(h,quick,2,0.001,"Configured L/(1+L) block steady response");
            validNear(h,monitor,2,0.001,"Monitor receives fractional closed-loop response");
            near(h,motor.getSpeed(),2,0.001,"Actual motor RPM");
            near(h,sensor.getSpeed(),2,0.001,"Actual connected sensor shaft RPM");
            CompoundTag state=quick.clientSnapshot();
            for(char port='B';port<='D';port++)
                h.assertTrue(state.getBoolean("unused"+port)&&!state.getBoolean("valid"+port),
                        "Theoretical closed loop must not require NULL port "+port);
            h.setBlock(sourcePos,Blocks.AIR);
        });
        h.runAtTickTime(88,()->{
            h.assertTrue(!quick.clientSnapshot().getBoolean("valid"),"Removing A must invalidate the dynamic block");
            h.assertTrue(!monitor.clientSnapshot().getBoolean("valid"),"Missing A must propagate through the numerical bus");
            h.assertTrue(!motor.clientSnapshot().getBoolean("valid"),"Missing A must invalidate the actuator command");
            near(h,motor.getGeneratedSpeed(),0,1e-9,"Disconnected motor must stop");
            near(h,sensor.getSpeed(),0,1e-9,"Physical shaft must stop too");
        });
        h.runAtTickTime(90,()->source(h,sourcePos));
        for(int tick=91;tick<=105;tick++) h.runAtTickTime(tick,()->{
            CompoundTag state=quick.clientSnapshot();
            if(!sawFirstRecoveredSample[0]&&state.getBoolean("valid")) {
                // At dt=.05, T(z) has b0=2/43. A cold first step of magnitude 3 is exactly 6/43.
                // A controller retaining its pre-fault memory would instead resume close to 2.
                near(h,state.getDouble("value"),6.0/43.0,1e-10,"First post-fault sample must restart from zero state");
                sawFirstRecoveredSample[0]=true;
            }
        });
        h.runAtTickTime(170,()->{
            h.assertTrue(sawFirstRecoveredSample[0],"Reconnected source must produce a fresh first sample");
            validNear(h,quick,2,0.001,"Recovered configured transfer function");
            validNear(h,monitor,2,0.001,"Recovered numerical monitor");
            near(h,motor.getSpeed(),2,0.001,"Recovered actual motor RPM");
            near(h,sensor.getSpeed(),2,0.001,"Recovered actual feedback RPM");
            BlockEntity shaft=h.getLevel().getBlockEntity(h.absolutePos(shaftPos));
            h.assertTrue(shaft instanceof KineticBlockEntity,"Real Create shaft must survive continuous dynamic tuning");
            near(h,((KineticBlockEntity)shaft).getSpeed(),2,0.001,"Surviving Create shaft tracks transfer output");
            h.succeed();
        });
    }

    @GameTest(template="empty", timeoutTicks=50)
    public static void edited_quick_roots_persist_and_invalid_updates_are_atomic(GameTestHelper h) {
        source(h,new BlockPos(1,2,1));
        var quick=place(h,NodeKind.QUICK_CONFIGURATOR,new BlockPos(3,2,1));
        var edited=new QuickSettings(QuickSettings.Mode.CLOSED_LOOP,3.75,
                List.of(new QuickSettings.Root(-2,1)),List.of(new QuickSettings.Root(-1,2),new QuickSettings.Root(-3,0)));
        CompoundTag settings=quick.getSettings();settings.putString("inputA","setpoint");
        settings.putString("quick",QuickSettingsCodec.toJson(edited));quick.applySettings(settings);
        h.runAtTickTime(20,()->{
            h.assertTrue(quick.clientSnapshot().getBoolean("valid"),"Edited complex-root definition must run on the actual block");
            CompoundTag saved=quick.saveWithFullMetadata(h.getLevel().registryAccess());
            var restored=(AutomationBlockEntity)BlockEntity.loadStatic(quick.getBlockPos(),quick.getBlockState(),saved,h.getLevel().registryAccess());
            h.assertTrue(restored!=null&&restored.getSettings().equals(quick.getSettings()),"All edited quick settings must survive Minecraft NBT");
            h.assertTrue(QuickSettingsCodec.fromJson(restored.getSettings().getString("quick")).equals(edited),
                    "Gain and real/complex zero-pole values must survive, not only the selected mode");
            List<String> invalid=List.of(
                    "{\"mode\":\"CLOSED_LOOP\",\"gain\":1,\"zeros\":[{\"real\":-1}],\"poles\":[]}",
                    "{\"mode\":\"CLOSED_LOOP\",\"gain\":-1,\"zeros\":[],\"poles\":[]}",
                    "{\"mode\":\"CLOSED_LOOP\",\"gain\":1e999,\"zeros\":[],\"poles\":[{\"real\":-1}]}");
            for(String json:invalid) {
                CompoundTag prior=quick.getSettings(),runtime=quick.clientSnapshot();
                CompoundTag request=prior.copy();request.putString("quick",json);request.putString("output","must_not_commit");
                boolean rejected=false;
                try { quick.applySettings(request); }catch(IllegalArgumentException expected){rejected=true;}
                h.assertTrue(rejected,"Improper, singular and nonfinite definitions must reject at the block boundary");
                h.assertTrue(quick.getSettings().equals(prior),"A rejected quick edit must not partially commit any settings");
                h.assertTrue(quick.clientSnapshot().equals(runtime),"A rejected edit must not clear the current response or runtime state");
            }
            h.succeed();
        });
    }

    private static void source(GameTestHelper h,BlockPos position) {
        var source=place(h,NodeKind.CONSTANT,position);
        CompoundTag settings=source.getSettings();settings.putString("output","setpoint");settings.putDouble("constant",3);
        source.applySettings(settings);
    }
    private static void input(AutomationBlockEntity entity,String channel) {
        CompoundTag settings=entity.getSettings();settings.putString("inputA",channel);entity.applySettings(settings);
    }
    private static AutomationBlockEntity place(GameTestHelper h,NodeKind kind,BlockPos position) {
        h.setBlock(position,ModRegistry.NODES.get(kind).get().defaultBlockState().setValue(AutomationBlock.FACING,Direction.EAST));
        var entity=(AutomationBlockEntity)h.getLevel().getBlockEntity(h.absolutePos(position));
        CompoundTag settings=entity.getSettings();settings.putString("network","quick_"+h.absolutePos(BlockPos.ZERO).asLong());
        settings.putString("output","out_"+position.asLong());entity.applySettings(settings);
        return entity;
    }
    private static void validNear(GameTestHelper h,AutomationBlockEntity entity,double expected,double tolerance,String label) {
        CompoundTag state=entity.clientSnapshot();h.assertTrue(state.getBoolean("valid"),label+": "+state.getString("status"));
        near(h,state.getDouble("value"),expected,tolerance,label);
    }
    private static void near(GameTestHelper h,double actual,double expected,double tolerance,String label) {
        h.assertTrue(Double.isFinite(actual)&&Math.abs(actual-expected)<tolerance,label+": expected "+expected+", got "+actual);
    }
}
