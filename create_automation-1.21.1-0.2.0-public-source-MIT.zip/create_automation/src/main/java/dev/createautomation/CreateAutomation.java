package dev.createautomation;

import dev.createautomation.network.AutomationNetwork;
import dev.createautomation.registry.ModRegistry;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;

@Mod(CreateAutomation.MOD_ID)
public final class CreateAutomation {
    public static final String MOD_ID = "create_automation";

    public CreateAutomation(IEventBus modBus) {
        ModRegistry.register(modBus);
        modBus.addListener(AutomationNetwork::register);
    }
}
