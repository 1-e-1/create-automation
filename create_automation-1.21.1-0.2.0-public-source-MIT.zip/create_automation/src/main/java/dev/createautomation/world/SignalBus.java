package dev.createautomation.world;

import dev.createautomation.engine.Signal;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.WeakHashMap;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.neoforged.neoforge.event.level.LevelEvent;
import net.neoforged.neoforge.event.tick.LevelTickEvent;

/** Server-thread transport. Never fetches an unloaded chunk and never evaluates in block tick order. */
public final class SignalBus {
    public record Channel(String network, String name) { }
    private record Source(BlockPos position, Signal signal, long tick) { }
    private record Seen(WeakReference<AutomationBlockEntity> reference, long tick) { }
    private static final class State {
        final Map<BlockPos, Seen> nodes = new HashMap<>();
        Map<Channel, List<Source>> previous = Map.of();
    }
    private static final Map<ServerLevel, State> LEVELS = new WeakHashMap<>();

    private SignalBus() { }

    static void seen(AutomationBlockEntity node) {
        if (node.getLevel() instanceof ServerLevel level) {
            LEVELS.computeIfAbsent(level, ignored -> new State()).nodes.put(node.getBlockPos().immutable(),
                    new Seen(new WeakReference<>(node), level.getGameTime()));
        }
    }

    static void forget(AutomationBlockEntity node) {
        if (node.getLevel() instanceof ServerLevel level) {
            State state = LEVELS.get(level);
            if (state != null) state.nodes.remove(node.getBlockPos());
        }
        invalidatePublication(node);
    }

    static void invalidatePublication(AutomationBlockEntity node) {
        if (node.getLevel() instanceof ServerLevel level) {
            State state = LEVELS.get(level);
            if (state == null) return;
            Map<Channel, List<Source>> cleaned = new HashMap<>();
            state.previous.forEach((channel, values) -> {
                List<Source> retained = values.stream().filter(source -> !source.position.equals(node.getBlockPos())).toList();
                if (!retained.isEmpty()) cleaned.put(channel, retained);
            });
            state.previous = cleaned;
        }
    }

    public static void unloadLevel(LevelEvent.Unload event) {
        if (event.getLevel() instanceof ServerLevel level) LEVELS.remove(level);
    }

    public static void endLevelTick(LevelTickEvent.Post event) {
        if (!(event.getLevel() instanceof ServerLevel level)) return;
        State state = LEVELS.get(level);
        if (state == null) return;
        long tick = level.getGameTime();
        List<AutomationBlockEntity> active = new ArrayList<>();
        state.nodes.entrySet().removeIf(entry -> {
            AutomationBlockEntity node = entry.getValue().reference.get();
            boolean expired = node == null || node.isRemoved() || tick - entry.getValue().tick >= 2
                    || !level.hasChunkAt(entry.getKey()) || level.getBlockEntity(entry.getKey()) != node;
            if (!expired) active.add(node);
            return expired;
        });
        active.sort(Comparator.comparingLong(node -> node.getBlockPos().asLong()));

        // Detect configuration changes and conflicts before ANY consumer is evaluated.
        Map<Channel, List<BlockPos>> currentPublishers = new HashMap<>();
        for (AutomationBlockEntity node : active) {
            if (node.getNodeKind().publishes()) currentPublishers
                    .computeIfAbsent(node.outputChannel(), ignored -> new ArrayList<>()).add(node.getBlockPos());
        }
        Map<Channel, Signal> snapshot = new HashMap<>();
        currentPublishers.forEach((channel, publishers) -> {
            if (publishers.size() != 1) {
                snapshot.put(channel, Signal.invalid("同频道存在多个输出源 / duplicate publishers"));
                return;
            }
            List<Source> sources = state.previous.get(channel);
            if (sources == null || sources.size() != 1) {
                snapshot.put(channel, Signal.invalid("等待上一 tick 的唯一信号 / awaiting source"));
                return;
            }
            Source source = sources.getFirst();
            if (tick - source.tick >= 2 || !source.position.equals(publishers.getFirst())) {
                snapshot.put(channel, Signal.invalid("信号已过期 / expired signal"));
            } else snapshot.put(channel, source.signal);
        });

        Map<Channel, Signal> inputs = Map.copyOf(snapshot);
        Map<AutomationBlockEntity, Signal> evaluated = new HashMap<>();
        Map<Channel, List<Source>> next = new HashMap<>();
        for (AutomationBlockEntity node : active) {
            Signal signal = node.evaluate(inputs);
            if (node.getNodeKind().publishes()) {
                Channel channel = node.outputChannel();
                if (currentPublishers.get(channel).size() > 1) {
                    node.resetController();
                    signal = Signal.invalid("同频道存在多个输出源 / duplicate publishers");
                }
                next.computeIfAbsent(channel, ignored -> new ArrayList<>())
                        .add(new Source(node.getBlockPos().immutable(), signal, tick));
            }
            evaluated.put(node, signal);
        }
        // Physical effects occur only after every sensor and graph has sampled the same tick.
        for (AutomationBlockEntity node : active) node.acceptEvaluation(evaluated.get(node));
        state.previous = next;
    }
}
