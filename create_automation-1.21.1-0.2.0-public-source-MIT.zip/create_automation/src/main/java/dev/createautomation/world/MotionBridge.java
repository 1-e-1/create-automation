package dev.createautomation.world;

import java.lang.reflect.Method;
import java.util.UUID;
import net.minecraft.core.Vec3i;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.phys.Vec3;
import net.neoforged.fml.ModList;
import org.joml.Quaterniondc;
import org.joml.Vector3d;
import org.joml.Vector3dc;

/** Optional Sable 2.0.6 bridge; no Sable class appears in a JVM signature. */
public final class MotionBridge {
    public record Sample(boolean valid, String status, UUID body, double height,
                         double vx, double vy, double vz, double roll, double pitch, double yaw,
                         double wx, double wy, double wz) {
        static Sample invalid(String status) {
            return new Sample(false, status, null, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
        }
    }

    private static Access access;
    private static boolean tried;
    private static String loadError = "未安装 Sable / Sable unavailable";

    private static synchronized Access access() {
        if (tried) return access;
        tried = true;
        if (!ModList.get().isLoaded("sable")) return null;
        try { access = new Access(); }
        catch (ReflectiveOperationException | LinkageError exception) {
            loadError = "Sable 接口版本不兼容 / incompatible API: " + exception.getClass().getSimpleName();
        }
        return access;
    }

    private static final class Access {
        final Object companion;
        final Method containing, project, distance, pose, id, orientation, position, removed;
        final Method handleOf, handleValid, linear, angular;
        final Class<?> serverBody;
        Access() throws ReflectiveOperationException {
            Class<?> api = Class.forName("dev.ryanhcode.sable.companion.SableCompanion");
            Class<?> body = Class.forName("dev.ryanhcode.sable.companion.SubLevelAccess");
            Class<?> poseType = Class.forName("dev.ryanhcode.sable.companion.math.Pose3dc");
            serverBody = Class.forName("dev.ryanhcode.sable.sublevel.ServerSubLevel");
            companion = api.getField("INSTANCE").get(null);
            containing = api.getMethod("getContaining", Level.class, Vec3i.class);
            project = api.getMethod("projectOutOfSubLevel", Level.class, Vec3.class);
            distance = api.getMethod("distanceSquaredWithSubLevels", Level.class,
                    double.class, double.class, double.class, double.class, double.class, double.class);
            pose = body.getMethod("logicalPose");
            id = body.getMethod("getUniqueId");
            orientation = poseType.getMethod("orientation");
            position = poseType.getMethod("position");
            Class<?> handle = Class.forName("dev.ryanhcode.sable.api.physics.handle.RigidBodyHandle");
            handleOf = handle.getMethod("of", serverBody);
            handleValid = handle.getMethod("isValid");
            linear = handle.getMethod("getLinearVelocity");
            angular = handle.getMethod("getAngularVelocity");
            removed = serverBody.getMethod("isRemoved");
        }
    }

    /** Legacy sensor semantics: height is the transformed center of this particular detector block. */
    public static Sample sample(BlockEntity entity) { return sample(entity, false); }

    /** Whole-body state. Position is Sable's world rigid-body reference, independent of detector placement.
     * Sable 2.0.6 assembly sets logicalPose.position to the transformed center of mass and passes
     * that same position to PhysicsPipeline.teleport. Keep the precise reference name: changing the
     * body's mass distribution can move its reference even when an individual block stays fixed.
     */
    public static Sample sampleBody(BlockEntity entity) { return sample(entity, true); }

    private static Sample sample(BlockEntity entity, boolean wholeBody) {
        if (!(entity.getLevel() instanceof ServerLevel level) || !level.getServer().isSameThread())
            return Sample.invalid("仅允许服务端主线程采样 / server thread required");
        Access api = access();
        if (api == null) return Sample.invalid(loadError);
        try {
            Object body = api.containing.invoke(api.companion, entity.getLevel(), entity.getBlockPos());
            if (body == null || !api.serverBody.isInstance(body) || (boolean) api.removed.invoke(body))
                return Sample.invalid("检测器不在已组装飞行器上 / no moving body");
            Object pose = api.pose.invoke(body);
            double height = wholeBody ? ((Vector3dc) api.position.invoke(pose)).y()
                    : ((Vec3) api.project.invoke(api.companion, entity.getLevel(), Vec3.atCenterOf(entity.getBlockPos()))).y;
            Object handle = api.handleOf.invoke(null, body);
            if (!(boolean) api.handleValid.invoke(handle)) return Sample.invalid("物理刚体不可用 / invalid physics body");
            // Sable 2.0.6 ticks synchronously: ServerLevelMixin.sable$tickPlotContainer ->
            // SubLevelContainer observers -> SubLevelPhysicsSystem.tick -> native Rapier3D.step;
            // native stepping returns before pose reads and before our LevelTickEvent.Post handler.
            // The server-thread guard above also applies to calibration packets. No worker reads JNI.
            // Read physical state directly: Sable's latest* fields are pose differences and lose
            // sub-block velocity precision at distant world coordinates.
            Vector3d linear = new Vector3d((Vector3dc) api.linear.invoke(handle));
            Vector3d angular = new Vector3d((Vector3dc) api.angular.invoke(handle));
            Quaterniondc quaternion = (Quaterniondc) api.orientation.invoke(pose);
            Vector3d angles = quaternion.getEulerAnglesYXZ(new Vector3d());
            if (!Double.isFinite(height) || !linear.isFinite() || !angular.isFinite() || !angles.isFinite())
                return Sample.invalid("运动数据非有限数 / invalid motion sample");
            // Minecraft: Y up. YXZ Euler: pitch=X, yaw=Y, roll=Z, all exposed in degrees.
            return new Sample(true, "正常 / OK", (UUID) api.id.invoke(body), height,
                    linear.x, linear.y, linear.z, Math.toDegrees(angles.z), Math.toDegrees(angles.x),
                    Math.toDegrees(angles.y), angular.x, angular.y, angular.z);
        } catch (ReflectiveOperationException | RuntimeException | LinkageError exception) {
            return Sample.invalid("Sable 读取失败 / read failed: " + exception.getClass().getSimpleName());
        }
    }

    /** Includes ship transforms so a legitimate player can configure a block stored in a Sable plot. */
    public static double distanceSquared(Level level, Vec3 first, Vec3 second) {
        Access api = access();
        if (api == null) return first.distanceToSqr(second);
        try {
            double result = (double) api.distance.invoke(api.companion, level,
                    first.x, first.y, first.z, second.x, second.y, second.z);
            return Double.isFinite(result) ? result : Double.POSITIVE_INFINITY;
        } catch (ReflectiveOperationException | RuntimeException exception) {
            return Double.POSITIVE_INFINITY;
        }
    }

    private MotionBridge() { }
}
