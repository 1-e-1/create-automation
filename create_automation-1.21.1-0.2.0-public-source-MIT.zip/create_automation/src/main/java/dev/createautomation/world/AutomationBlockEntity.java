package dev.createautomation.world;

import com.simibubi.create.content.kinetics.base.GeneratingKineticBlockEntity;
import dev.createautomation.engine.ControlEngine;
import dev.createautomation.engine.GraphCodec;
import dev.createautomation.engine.Signal;
import dev.createautomation.engine.QuickSettingsCodec;
import dev.createautomation.engine.QuickTransferEngine;
import dev.createautomation.integration.ServoSpeedUpdate;
import dev.createautomation.registry.ModRegistry;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.regex.Pattern;
import java.nio.charset.StandardCharsets;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.level.block.state.BlockState;

public final class AutomationBlockEntity extends GeneratingKineticBlockEntity {
    private static final Pattern CHANNEL = Pattern.compile("[A-Za-z0-9_.:/-]{1,48}");
    private static final String[] CHANNEL_KEYS = {"network", "inputA", "inputB", "inputC", "inputD", "output"};
    private static final String[] NUMBER_KEYS = {"constant", "scale", "offset", "min", "max"};
    private static final Set<String> MODES = Set.of("HEIGHT", "VELOCITY_X", "VELOCITY_Y", "VELOCITY_Z", "SPEED",
            "ROLL", "PITCH", "YAW", "ANGULAR_X", "ANGULAR_Y", "ANGULAR_Z");
    private static final Signal WAITING = Signal.invalid("等待信号 / awaiting signal");
    private final NodeKind kind;
    private CompoundTag settings;
    private ControlEngine controller;
    private QuickTransferEngine quickController;
    private Signal result = WAITING;
    private final Signal[] portValues = {WAITING, WAITING, WAITING, WAITING};
    private float generatedOutput;
    private int redstoneOutput;
    private boolean calibrated;
    private double originY;
    private UUID originBody;

    public AutomationBlockEntity(BlockPos position, BlockState state) {
        super(ModRegistry.NODE_ENTITY.get(), position, state);
        kind = ((AutomationBlock) state.getBlock()).kind();
        settings = defaults(kind);
    }

    private static CompoundTag defaults(NodeKind kind) {
        CompoundTag tag = new CompoundTag();
        tag.putString("network", "main");
        tag.putString("inputA", switch (kind) {
            case SYSTEM_OUTPUT, RPM_OUTPUT, REDSTONE_OUTPUT, MONITOR -> "output";
            case SYSTEM_BUILDER -> "input";
            case QUICK_CONFIGURATOR -> "setpoint";
            default -> "NULL";
        });
        tag.putString("inputB", "NULL");
        tag.putString("inputC", "NULL");
        tag.putString("inputD", "NULL");
        tag.putString("output", switch (kind) {
            case SYSTEM_BUILDER, QUICK_CONFIGURATOR -> "output";
            case SYSTEM_OUTPUT -> "actuator";
            default -> "input";
        });
        tag.putString("graph", GraphCodec.toJson(GraphCodec.preset("passthrough")));
        if (kind == NodeKind.QUICK_CONFIGURATOR)
            tag.putString("quick", QuickSettingsCodec.toJson(QuickSettingsCodec.defaults()));
        tag.putString("mode", switch (kind) {
            case HEIGHT_SENSOR -> "WORLD_Y";
            case SPEED_SENSOR -> "SPEED";
            case ATTITUDE_SENSOR -> "ROLL";
            default -> "HEIGHT";
        });
        tag.putDouble("constant", 0);
        tag.putDouble("scale", 1);
        tag.putDouble("offset", 0);
        tag.putDouble("min", kind == NodeKind.RPM_OUTPUT ? -256 : kind == NodeKind.REDSTONE_OUTPUT ? 0 : -1e12);
        tag.putDouble("max", kind == NodeKind.RPM_OUTPUT ? 256 : kind == NodeKind.REDSTONE_OUTPUT ? 15 : 1e12);
        tag.putBoolean("enabled", true);
        return tag;
    }

    public NodeKind getNodeKind() { return kind; }
    public CompoundTag getSettings() { return settings.copy(); }
    public int redstoneLevel() { return redstoneOutput; }

    /** Validates the complete candidate before changing any live configuration or calibration. */
    public void applySettings(CompoundTag requested) {
        CompoundTag candidate = validatedSettings(requested, settings);
        ControlEngine candidateController = kind == NodeKind.SYSTEM_BUILDER
                ? new ControlEngine(GraphCodec.fromJson(candidate.getString("graph"))) : null;
        QuickTransferEngine candidateQuick = kind == NodeKind.QUICK_CONFIGURATOR
                ? new QuickTransferEngine(QuickSettingsCodec.fromJson(candidate.getString("quick"))) : null;
        MotionBridge.Sample calibration = null;
        if (requested.getBoolean("calibrate")) {
            if (kind != NodeKind.MOTION_SENSOR && kind != NodeKind.HEIGHT_SENSOR)
                throw new IllegalArgumentException("仅高度或旧运动检测器支持高度归零");
            calibration = kind == NodeKind.MOTION_SENSOR ? MotionBridge.sample(this) : MotionBridge.sampleBody(this);
            if (!calibration.valid()) throw new IllegalArgumentException(calibration.status());
        }
        settings = candidate;
        controller = candidateController;
        quickController = candidateQuick;
        if (calibration != null) {
            calibrated = true;
            originY = calibration.height();
            originBody = calibration.body();
        }
        result = WAITING;
        for (int index = 0; index < 4; index++) portValues[index] = WAITING;
        stopActuators();
        SignalBus.invalidatePublication(this);
        setChanged();
        sendData();
    }

    private CompoundTag validatedSettings(CompoundTag requested, CompoundTag prior) {
        CompoundTag candidate = prior.copy();
        for (String key : CHANNEL_KEYS) {
            if (!requested.contains(key)) continue;
            if (!requested.contains(key, Tag.TAG_STRING)) throw new IllegalArgumentException(key + " 必须是字符串");
            String value = requested.getString(key).trim();
            if (key.startsWith("input") && isUnusedInput(value)) {
                candidate.putString(key, "NULL");
                continue;
            }
            if (!key.startsWith("input") && "NULL".equalsIgnoreCase(value))
                throw new IllegalArgumentException(key + " 不能使用保留字 NULL / reserved channel");
            if (!CHANNEL.matcher(value).matches())
                throw new IllegalArgumentException(key + " 请使用 1–48 位字母、数字或 _ . : / -");
            candidate.putString(key, value);
        }
        for (String key : NUMBER_KEYS) {
            if (!requested.contains(key)) continue;
            if (!requested.contains(key, Tag.TAG_ANY_NUMERIC)) throw new IllegalArgumentException(key + " 必须是数字");
            double value = requested.getDouble(key);
            if (!Double.isFinite(value) || Math.abs(value) > 1e12)
                throw new IllegalArgumentException(key + " 必须是 ±1e12 内的有限数");
            candidate.putDouble(key, value);
        }
        if (candidate.getDouble("min") > candidate.getDouble("max"))
            throw new IllegalArgumentException("下限不得大于上限 / min > max");
        if (requested.contains("mode")) {
            String mode = requested.getString("mode");
            Set<String> allowed = switch (kind) {
                case HEIGHT_SENSOR -> Set.of("WORLD_Y", "RELATIVE_HEIGHT");
                case SPEED_SENSOR -> Set.of("SPEED", "VELOCITY_X", "VELOCITY_Y", "VELOCITY_Z");
                case ATTITUDE_SENSOR -> Set.of("ROLL", "PITCH", "YAW");
                default -> MODES;
            };
            if (!allowed.contains(mode)) throw new IllegalArgumentException("此检测器不支持该模式 / invalid sensor mode");
            candidate.putString("mode", mode);
        }
        if (requested.contains("graph")) {
            if (!requested.contains("graph", Tag.TAG_STRING)) throw new IllegalArgumentException("graph 必须是字符串");
            String json = requested.getString("graph");
            if (json.length() > 49152) throw new IllegalArgumentException("控制图过大 / graph too large");
            candidate.putString("graph", GraphCodec.toJson(GraphCodec.fromJson(json)));
        }
        if (requested.contains("quick")) {
            if (!requested.contains("quick", Tag.TAG_STRING)) throw new IllegalArgumentException("quick 必须是字符串");
            String json = requested.getString("quick");
            if (json.length() > 12000) throw new IllegalArgumentException("快速配置过大 / quick configuration too large");
            candidate.putString("quick", QuickSettingsCodec.toJson(QuickSettingsCodec.fromJson(json)));
        }
        if (requested.contains("enabled")) {
            if (!requested.contains("enabled", Tag.TAG_BYTE)) throw new IllegalArgumentException("enabled 必须是布尔值");
            candidate.putBoolean("enabled", requested.getBoolean("enabled"));
        }
        // Leave transport headroom for telemetry and the surrounding payload (<32 KiB serverbound).
        if (candidate.toString().getBytes(StandardCharsets.UTF_8).length > 20000)
            throw new IllegalArgumentException("配置超过 20 KB，请减少节点参数 / configuration exceeds 20 KB");
        return candidate;
    }

    @Override
    public void initialize() {
        super.initialize();
        if (kind == NodeKind.RPM_OUTPUT && level != null && !level.isClientSide) updateGeneratedRotation();
    }

    @Override
    public void tick() {
        super.tick();
        if (level != null && !level.isClientSide) SignalBus.seen(this);
    }

    @Override
    public void invalidate() {
        SignalBus.forget(this);
        super.invalidate();
    }

    @Override
    public void onChunkUnloaded() {
        SignalBus.forget(this);
        super.onChunkUnloaded();
    }

    SignalBus.Channel outputChannel() {
        return new SignalBus.Channel(settings.getString("network"), settings.getString("output"));
    }

    /** NULL is a disconnected port, never a signal channel or a valid numeric zero. */
    public static boolean isUnusedInput(String channel) {
        return channel == null || channel.isBlank() || "NULL".equalsIgnoreCase(channel.trim());
    }

    Signal evaluate(Map<SignalBus.Channel, Signal> snapshot) {
        for (int i = 0; i < 4; i++) {
            String channel = settings.getString("input" + (char) ('A' + i));
            portValues[i] = isUnusedInput(channel)
                    ? Signal.invalid("输入 " + (char) ('A' + i) + " 未使用（NULL） / unused input")
                    : snapshot.getOrDefault(new SignalBus.Channel(settings.getString("network"), channel),
                            Signal.invalid("频道无信号 / no signal: " + channel));
        }
        if (!settings.getBoolean("enabled")) {
            resetController();
            return Signal.invalid("已停用 / disabled");
        }
        try {
            return switch (kind) {
                case RPM_SENSOR -> transform(Signal.valid(getSpeed()));
                case MOTION_SENSOR, HEIGHT_SENSOR, SPEED_SENSOR, ATTITUDE_SENSOR -> transform(motionSignal());
                case CONSTANT -> transform(Signal.valid(settings.getDouble("constant")));
                case REDSTONE_INPUT -> transform(Signal.valid(level.getBestNeighborSignal(worldPosition)));
                case SYSTEM_BUILDER -> stepController();
                case QUICK_CONFIGURATOR -> transform(stepQuickController());
                case SYSTEM_OUTPUT, RPM_OUTPUT, REDSTONE_OUTPUT -> transform(portValues[0]);
                case MONITOR -> portValues[0];
            };
        } catch (RuntimeException exception) {
            resetController();
            return Signal.invalid("计算失败 / evaluation failed: " + exception.getClass().getSimpleName());
        }
    }

    private Signal stepController() {
        if (controller == null) controller = new ControlEngine(GraphCodec.fromJson(settings.getString("graph")));
        Map<String, Signal> inputs = new HashMap<>();
        for (int index = 0; index < 4; index++) inputs.put(String.valueOf((char) ('a' + index)), portValues[index]);
        return controller.step(inputs, 0.05); // Simulation seconds, independent of wall-clock TPS.
    }

    private Signal stepQuickController() {
        if (quickController == null) quickController = new QuickTransferEngine(QuickSettingsCodec.fromJson(settings.getString("quick")));
        Map<String, Signal> inputs = new HashMap<>();
        for (int index = 0; index < 4; index++) inputs.put(String.valueOf((char) ('a' + index)), portValues[index]);
        return quickController.step(inputs, 0.05);
    }

    void resetController() {
        if (controller != null) controller.reset();
        if (quickController != null) quickController.reset();
    }

    private Signal transform(Signal input) {
        if (!input.valid()) return input;
        double scaled = input.value() * settings.getDouble("scale") + settings.getDouble("offset");
        if (!Double.isFinite(scaled)) return Signal.invalid("变换结果非有限数 / nonfinite signal");
        return Signal.valid(Math.max(settings.getDouble("min"), Math.min(settings.getDouble("max"), scaled)));
    }

    private Signal motionSignal() {
        MotionBridge.Sample sample = kind == NodeKind.MOTION_SENSOR
                ? MotionBridge.sample(this) : MotionBridge.sampleBody(this);
        if (!sample.valid()) return Signal.invalid(sample.status());
        if (!calibrated || !sample.body().equals(originBody)) {
            originY = sample.height();
            originBody = sample.body();
            calibrated = true;
            setChanged();
        }
        double value = switch (settings.getString("mode")) {
            case "HEIGHT", "RELATIVE_HEIGHT" -> sample.height() - originY;
            case "WORLD_Y" -> sample.height();
            case "VELOCITY_X" -> sample.vx();
            case "VELOCITY_Y" -> sample.vy();
            case "VELOCITY_Z" -> sample.vz();
            case "SPEED" -> Math.sqrt(sample.vx() * sample.vx() + sample.vy() * sample.vy() + sample.vz() * sample.vz());
            case "ROLL" -> sample.roll();
            case "PITCH" -> sample.pitch();
            case "YAW" -> sample.yaw();
            case "ANGULAR_X" -> sample.wx();
            case "ANGULAR_Y" -> sample.wy();
            case "ANGULAR_Z" -> sample.wz();
            default -> throw new IllegalArgumentException("Unknown mode");
        };
        return Double.isFinite(value) ? Signal.valid(value) : Signal.invalid("无效运动量 / invalid motion value");
    }

    void acceptEvaluation(Signal signal) {
        result = signal;
        if (kind == NodeKind.RPM_OUTPUT) {
            // A servo must own its kinetic network. Do not fight a second motor and break the block.
            if (hasSource() && signal.valid()) result = Signal.invalid("轴上有外部动力 / external kinetic source");
            float requested = result.valid() ? (float) Math.max(-256, Math.min(256, result.value())) : 0;
            setGeneratedOutput(requested);
        } else if (kind == NodeKind.REDSTONE_OUTPUT) {
            setRedstoneOutput(result.valid() ? (int) Math.round(Math.max(0, Math.min(15, result.value()))) : 0);
        }
        if (level != null && level.getGameTime() % 10 == 0) sendData();
    }

    private void setGeneratedOutput(float requested) {
        if (!Float.isFinite(requested)) requested = 0;
        if (Float.compare(generatedOutput, requested) == 0) return;
        generatedOutput = requested;
        if (level != null && !level.isClientSide) ServoSpeedUpdate.update(this);
    }

    private void setRedstoneOutput(int strength) {
        if (redstoneOutput == strength) return;
        redstoneOutput = strength;
        if (level != null && !level.isClientSide) {
            level.updateNeighborsAt(worldPosition, getBlockState().getBlock());
            for (var direction : net.minecraft.core.Direction.values())
                level.updateNeighborsAt(worldPosition.relative(direction), getBlockState().getBlock());
            sendData();
        }
    }

    private void stopActuators() {
        setGeneratedOutput(0);
        setRedstoneOutput(0);
    }

    @Override
    public float getGeneratedSpeed() {
        return kind == NodeKind.RPM_OUTPUT
                ? convertToDirection(generatedOutput, getBlockState().getValue(AutomationBlock.FACING)) : 0;
    }

    @Override
    public float calculateAddedStressCapacity() {
        lastCapacityProvided = kind == NodeKind.RPM_OUTPUT ? 64 : 0;
        return lastCapacityProvided;
    }

    @Override
    public float calculateStressApplied() { lastStressApplied = 0; return 0; }

    public CompoundTag clientSnapshot() {
        CompoundTag snapshot = new CompoundTag();
        snapshot.put("settings", settings.copy());
        snapshot.putDouble("value", result.valid() ? result.value() : 0);
        snapshot.putBoolean("valid", result.valid());
        snapshot.putString("status", result.status());
        snapshot.putDouble("speed", getSpeed());
        snapshot.putDouble("commandedSpeed", generatedOutput);
        snapshot.putInt("redstone", redstoneOutput);
        snapshot.putBoolean("calibrated", calibrated);
        snapshot.putDouble("originY", originY);
        if (kind.motionSensor()) snapshot.putString("reference", kind == NodeKind.MOTION_SENSOR
                ? "传感器方块中心 / detector block center" : "Sable 刚体参考点（整个结构） / rigid-body reference");
        snapshot.putString("unit", switch (kind) {
            case RPM_SENSOR, RPM_OUTPUT -> "RPM";
            case REDSTONE_INPUT, REDSTONE_OUTPUT -> "redstone (0–15)";
            case MOTION_SENSOR, HEIGHT_SENSOR, SPEED_SENSOR, ATTITUDE_SENSOR -> switch (settings.getString("mode")) {
                case "HEIGHT", "WORLD_Y", "RELATIVE_HEIGHT" -> "block";
                case "ROLL", "PITCH", "YAW" -> "deg (YXZ)";
                case "ANGULAR_X", "ANGULAR_Y", "ANGULAR_Z" -> "rad/s (world)";
                default -> "block/s (world)";
            };
            default -> "numeric";
        });
        for (int index = 0; index < 4; index++) {
            snapshot.putDouble(String.valueOf((char) ('a' + index)), portValues[index].valid() ? portValues[index].value() : 0);
            snapshot.putBoolean("valid" + (char) ('A' + index), portValues[index].valid());
            snapshot.putBoolean("unused" + (char) ('A' + index), isUnusedInput(settings.getString("input" + (char) ('A' + index))));
            snapshot.putString("status" + (char) ('A' + index), portValues[index].status());
        }
        return snapshot;
    }

    @Override
    protected void write(CompoundTag tag, HolderLookup.Provider registries, boolean clientPacket) {
        super.write(tag, registries, clientPacket);
        tag.put("AutomationSettings", settings.copy());
        tag.putBoolean("Calibrated", calibrated);
        tag.putDouble("OriginY", originY);
        if (originBody != null) tag.putUUID("OriginBody", originBody);
        if (clientPacket) {
            tag.put("AutomationRuntime", clientSnapshot());
        }
    }

    @Override
    protected void read(CompoundTag tag, HolderLookup.Provider registries, boolean clientPacket) {
        super.read(tag, registries, clientPacket);
        try {
            settings = validatedSettings(tag.getCompound("AutomationSettings"), defaults(kind));
        } catch (RuntimeException exception) {
            settings = defaults(kind);
            settings.putBoolean("enabled", false);
            result = Signal.invalid("存档设置损坏，已停用 / invalid saved settings");
        }
        controller = null;
        quickController = null;
        calibrated = tag.getBoolean("Calibrated") && tag.hasUUID("OriginBody") && Double.isFinite(tag.getDouble("OriginY"));
        originY = calibrated ? tag.getDouble("OriginY") : 0;
        originBody = calibrated ? tag.getUUID("OriginBody") : null;
        generatedOutput = 0;
        redstoneOutput = 0;
        if (clientPacket && tag.contains("AutomationRuntime", Tag.TAG_COMPOUND)) {
            CompoundTag runtime = tag.getCompound("AutomationRuntime");
            result = runtime.getBoolean("valid") ? Signal.valid(runtime.getDouble("value")) : Signal.invalid(runtime.getString("status"));
            generatedOutput = (float) runtime.getDouble("commandedSpeed");
            redstoneOutput = runtime.getInt("redstone");
        }
    }

    @Override
    public boolean addToGoggleTooltip(List<Component> tooltip, boolean sneaking) {
        super.addToGoggleTooltip(tooltip, sneaking);
        tooltip.add(Component.translatable("block.create_automation." + kind.id()).withStyle(ChatFormatting.AQUA));
        tooltip.add(Component.literal("  " + settings.getString("network") + " / "
                + settings.getString(kind.publishes() ? "output" : "inputA")).withStyle(ChatFormatting.GRAY));
        tooltip.add(Component.literal("  " + (result.valid() ? String.format(Locale.ROOT, "%.6f", result.value())
                : result.status())).withStyle(result.valid() ? ChatFormatting.GREEN : ChatFormatting.RED));
        return true;
    }
}
