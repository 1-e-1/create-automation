package dev.createautomation.world;

import java.util.Locale;

/** All functional blocks share settings and transport, but expose distinct ports. */
public enum NodeKind {
    RPM_SENSOR, MOTION_SENSOR, SYSTEM_BUILDER, SYSTEM_OUTPUT, RPM_OUTPUT,
    REDSTONE_INPUT, REDSTONE_OUTPUT, CONSTANT, MONITOR,
    HEIGHT_SENSOR, SPEED_SENSOR, ATTITUDE_SENSOR, QUICK_CONFIGURATOR;

    public String id() { return name().toLowerCase(Locale.ROOT); }

    public boolean publishes() {
        return switch (this) {
            case RPM_SENSOR, MOTION_SENSOR, HEIGHT_SENSOR, SPEED_SENSOR, ATTITUDE_SENSOR,
                    SYSTEM_BUILDER, QUICK_CONFIGURATOR, SYSTEM_OUTPUT, REDSTONE_INPUT, CONSTANT -> true;
            default -> false;
        };
    }

    public boolean motionSensor() {
        return this == MOTION_SENSOR || this == HEIGHT_SENSOR || this == SPEED_SENSOR || this == ATTITUDE_SENSOR;
    }

    public boolean kinetic() { return this == RPM_SENSOR || this == RPM_OUTPUT; }
}
