package dev.createautomation.world;

import com.simibubi.create.content.kinetics.base.DirectionalKineticBlock;
import com.simibubi.create.foundation.block.IBE;
import dev.createautomation.network.AutomationNetwork;
import dev.createautomation.registry.ModRegistry;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;

public final class AutomationBlock extends DirectionalKineticBlock implements IBE<AutomationBlockEntity> {
    private final NodeKind kind;

    public AutomationBlock(Properties properties, NodeKind kind) {
        super(properties);
        this.kind = kind;
    }

    public NodeKind kind() { return kind; }

    @Override
    public boolean hasShaftTowards(LevelReader level, BlockPos pos, BlockState state, Direction face) {
        Direction facing = state.getValue(FACING);
        return kind == NodeKind.RPM_OUTPUT ? face == facing
                : kind == NodeKind.RPM_SENSOR && face.getAxis() == facing.getAxis();
    }

    @Override
    public Direction.Axis getRotationAxis(BlockState state) { return state.getValue(FACING).getAxis(); }

    @Override
    protected InteractionResult useWithoutItem(BlockState state, Level level, BlockPos pos,
                                               Player player, BlockHitResult hit) {
        if (!level.isClientSide && player instanceof ServerPlayer serverPlayer
                && level.getBlockEntity(pos) instanceof AutomationBlockEntity entity) {
            AutomationNetwork.open(serverPlayer, entity);
        }
        return InteractionResult.sidedSuccess(level.isClientSide);
    }

    @Override
    protected boolean isSignalSource(BlockState state) { return kind == NodeKind.REDSTONE_OUTPUT; }

    @Override
    protected int getSignal(BlockState state, BlockGetter level, BlockPos pos, Direction direction) {
        return kind == NodeKind.REDSTONE_OUTPUT
                && level.getBlockEntity(pos) instanceof AutomationBlockEntity entity ? entity.redstoneLevel() : 0;
    }

    @Override
    protected int getDirectSignal(BlockState state, BlockGetter level, BlockPos pos, Direction direction) {
        return getSignal(state, level, pos, direction);
    }

    @Override
    public void onRemove(BlockState state, Level level, BlockPos pos, BlockState next, boolean moving) {
        super.onRemove(state, level, pos, next, moving);
        if (kind == NodeKind.REDSTONE_OUTPUT && state.getBlock() != next.getBlock()) {
            level.updateNeighborsAt(pos, this);
        }
    }

    @Override
    public Class<AutomationBlockEntity> getBlockEntityClass() { return AutomationBlockEntity.class; }

    @Override
    public BlockEntityType<? extends AutomationBlockEntity> getBlockEntityType() { return ModRegistry.NODE_ENTITY.get(); }
}
