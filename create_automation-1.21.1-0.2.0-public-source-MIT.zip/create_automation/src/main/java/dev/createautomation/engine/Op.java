package dev.createautomation.engine;

/** Operations available to the in-game control graph editor. */
public enum Op {
    INPUT, CONSTANT, ADD, SUBTRACT, MULTIPLY, DIVIDE, GAIN, CLAMP,
    PID, INTEGRATE, DERIVATIVE, LOW_PASS, DELAY, NEGATE, ABS, MIN, MAX
}
