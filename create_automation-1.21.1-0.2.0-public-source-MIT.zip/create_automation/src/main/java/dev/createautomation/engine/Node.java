package dev.createautomation.engine;

import java.util.List;
import java.util.Map;

/** Immutable graph definition; dynamic state is owned by a ControlEngine. */
public record Node(String id, Op op, List<String> inputs, Map<String, Double> parameters) {
    public Node {
        if (id == null || op == null || inputs == null || parameters == null)
            throw new IllegalArgumentException("Node fields must not be null");
        if (inputs.stream().anyMatch(java.util.Objects::isNull)
                || parameters.entrySet().stream().anyMatch(e -> e.getKey() == null || e.getValue() == null))
            throw new IllegalArgumentException("Node inputs and parameters must not contain null");
        inputs = List.copyOf(inputs);
        parameters = Map.copyOf(parameters);
    }
}
