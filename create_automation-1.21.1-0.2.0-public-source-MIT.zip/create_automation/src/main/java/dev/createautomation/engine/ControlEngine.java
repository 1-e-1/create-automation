package dev.createautomation.engine;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Pattern;

/**
 * Deterministic, double-precision sampled control graph. One instance belongs to one controller.
 * DELAY emits the previous sample; all delay inputs are committed simultaneously at the end.
 * Only the output dependency closure is evaluated, including future delay dependencies.
 * A fault anywhere in that closure resets every dynamic node and immediately invalidates output.
 * Call from the owning server thread; this class deliberately has no game or world dependencies.
 */
public final class ControlEngine {
    public static final int MAX_NODES = 64;
    private static final Pattern ID = Pattern.compile("[A-Za-z0-9_-]{1,48}");
    private static final String[] PORTS = {"a", "b", "c", "d"};
    private final Graph graph;
    private final List<Node> order;
    private final Map<String, State> states = new HashMap<>();

    private static final class State {
        double value;
        double previous;
        boolean initialized;
    }

    public ControlEngine(Graph graph) {
        validate(graph);
        this.graph = graph;
        Map<String, Node> nodes = index(graph);
        Set<String> active = new HashSet<>();
        collect(graph.output(), nodes, active);
        List<Node> sorted = new ArrayList<>();
        Set<String> visited = new HashSet<>();
        for (Node node : graph.nodes()) {
            if (active.contains(node.id())) sort(node, nodes, visited, new HashSet<>(), sorted);
        }
        order = List.copyOf(sorted);
    }

    public Graph graph() { return graph; }

    /** Clears PID integral/history, derivative/filter history, and delay/integrator memory. */
    public void reset() { states.clear(); }

    public Signal step(Map<String, Signal> inputs, double dt) {
        if (inputs == null || !Double.isFinite(dt) || dt <= 0.0) return fail("invalid_dt_or_inputs");
        Map<String, Signal> values = new HashMap<>();
        for (Node node : order) {
            if (node.op() != Op.DELAY) {
                for (String reference : node.inputs()) {
                    Signal dependency = values.get(reference);
                    if (dependency == null || !dependency.valid())
                        return fail(node.id() + ": " + (dependency == null ? "missing_dependency" : dependency.status()));
                }
            }
            Signal value = evaluate(node, inputs, values, dt);
            if (!value.valid()) return fail(node.id() + ": " + value.status());
            values.put(node.id(), value);
        }
        // Dependencies of delays were evaluated with OLD memory, so declaration order is irrelevant.
        for (Node node : order) {
            if (node.op() == Op.DELAY) {
                Signal next = values.get(node.inputs().getFirst());
                if (next == null || !next.valid()) return fail(node.id() + ": invalid_delay_input");
                State state = states.computeIfAbsent(node.id(), ignored -> new State());
                state.value = next.value();
                state.initialized = true;
            }
        }
        return values.get(graph.output());
    }

    private Signal fail(String status) {
        reset();
        return Signal.invalid(status);
    }

    private Signal evaluate(Node n, Map<String, Signal> external, Map<String, Signal> values, double dt) {
        double a = n.inputs().isEmpty() || n.op() == Op.DELAY ? 0.0 : values.get(n.inputs().getFirst()).value();
        double b = n.inputs().size() < 2 ? 0.0 : values.get(n.inputs().get(1)).value();
        return switch (n.op()) {
            case INPUT -> {
                String port = PORTS[(int) parameter(n, "port", 0)];
                Signal incoming = external.get(port);
                yield incoming == null ? Signal.invalid("missing_input_" + port) : incoming;
            }
            case CONSTANT -> finite(parameter(n, "value", 0));
            case ADD -> finite(a + b);
            case SUBTRACT -> finite(a - b);
            case MULTIPLY -> finite(a * b);
            case DIVIDE -> b == 0.0 ? Signal.invalid("division_by_zero") : finite(a / b);
            case GAIN -> finite(a * parameter(n, "gain", 1));
            case CLAMP -> finite(clamp(a, parameter(n, "min", -256), parameter(n, "max", 256)));
            case NEGATE -> finite(-a);
            case ABS -> finite(Math.abs(a));
            case MIN -> finite(Math.min(a, b));
            case MAX -> finite(Math.max(a, b));
            case PID -> pid(n, a, b, dt);
            case INTEGRATE -> integrate(n, a, dt);
            case DERIVATIVE -> derivative(n, a, dt);
            case LOW_PASS -> lowPass(n, a, dt);
            case DELAY -> {
                State state = states.get(n.id());
                yield finite(state == null || !state.initialized ? parameter(n, "initial", 0) : state.value);
            }
        };
    }

    private Signal pid(Node n, double setpoint, double measurement, double dt) {
        State state = states.computeIfAbsent(n.id(), ignored -> new State());
        double error = setpoint - measurement;
        double proportional = parameter(n, "kp", 1) * error;
        // Derivative on measurement avoids setpoint kick; the first valid sample has no derivative.
        double kd = parameter(n, "kd", 0);
        double differential = !state.initialized || kd == 0.0 ? 0.0 : -kd * ((measurement - state.previous) / dt);
        double increment = parameter(n, "ki", 0) * error * dt;
        double proposedIntegral = state.value + increment;
        double currentOutput = proportional + state.value + differential;
        double proposedOutput = proportional + proposedIntegral + differential;
        if (!allFinite(error, proportional, differential, increment, proposedIntegral, currentOutput, proposedOutput))
            return Signal.invalid("arithmetic_overflow");
        double min = parameter(n, "min", -256), max = parameter(n, "max", 256);
        // Conditional integration with a partial step to the boundary. A pure integral controller
        // can reach its limit without either stalling at zero or issuing an output absent from its
        // stored state. If P/D already saturate the output, freeze outward integration completely.
        if (proposedOutput > max && increment > 0)
            increment = Math.max(0, Math.min(increment, max - currentOutput));
        else if (proposedOutput < min && increment < 0)
            increment = Math.min(0, Math.max(increment, min - currentOutput));
        state.value += increment;
        state.previous = measurement;
        state.initialized = true;
        double output = proportional + state.value + differential;
        return Double.isFinite(output) ? finite(clamp(output, min, max)) : Signal.invalid("arithmetic_overflow");
    }

    private Signal integrate(Node n, double input, double dt) {
        State state = states.computeIfAbsent(n.id(), ignored -> new State());
        double previous = state.initialized ? state.value : parameter(n, "initial", 0);
        double next = previous + input * dt;
        if (!Double.isFinite(next)) return Signal.invalid("arithmetic_overflow");
        state.value = clamp(next, parameter(n, "min", -1e12), parameter(n, "max", 1e12));
        state.initialized = true;
        return finite(state.value);
    }

    private Signal derivative(Node n, double input, double dt) {
        State state = states.computeIfAbsent(n.id(), ignored -> new State());
        double result = state.initialized ? (input - state.previous) / dt : 0.0;
        state.previous = input;
        state.initialized = true;
        return finite(result);
    }

    private Signal lowPass(Node n, double input, double dt) {
        State state = states.computeIfAbsent(n.id(), ignored -> new State());
        if (!state.initialized) {
            state.value = input;
            state.initialized = true;
        } else {
            // Exact first-order zero-order-hold discretization; expm1 retains tiny dt/tau precision.
            double tau = parameter(n, "tau", 0.1);
            double alpha = tau == 0.0 ? 1.0 : -Math.expm1(-dt / tau);
            // Weighted form avoids overflow of (input - previous) for opposite large inputs.
            state.value = (1.0 - alpha) * state.value + alpha * input;
        }
        return finite(state.value);
    }

    private static Signal finite(double value) {
        return Double.isFinite(value) ? Signal.valid(value) : Signal.invalid("arithmetic_overflow");
    }

    private static boolean allFinite(double... values) {
        for (double value : values) if (!Double.isFinite(value)) return false;
        return true;
    }

    private static double clamp(double value, double min, double max) {
        return Math.max(min, Math.min(max, value));
    }

    private static double parameter(Node node, String key, double fallback) {
        return node.parameters().getOrDefault(key, fallback);
    }

    /** Validates even disconnected nodes, preventing malformed graphs from being saved. */
    public static void validate(Graph graph) {
        if (graph == null || graph.nodes().isEmpty() || graph.nodes().size() > MAX_NODES)
            throw new IllegalArgumentException("Graph must contain 1 to " + MAX_NODES + " nodes");
        Map<String, Node> nodes = index(graph);
        if (!nodes.containsKey(graph.output())) throw new IllegalArgumentException("Unknown graph output: " + graph.output());
        for (Node node : graph.nodes()) {
            if (!ID.matcher(node.id()).matches()) throw new IllegalArgumentException("Invalid node id: " + node.id());
            int arity = switch (node.op()) {
                case INPUT, CONSTANT -> 0;
                case ADD, SUBTRACT, MULTIPLY, DIVIDE, PID, MIN, MAX -> 2;
                default -> 1;
            };
            if (node.inputs().size() != arity)
                throw new IllegalArgumentException(node.id() + ": " + node.op() + " needs " + arity + " inputs");
            for (String ref : node.inputs()) if (!nodes.containsKey(ref))
                throw new IllegalArgumentException(node.id() + ": unknown input " + ref);
            Set<String> allowed = switch (node.op()) {
                case INPUT -> Set.of("port");
                case CONSTANT -> Set.of("value");
                case GAIN -> Set.of("gain");
                case CLAMP -> Set.of("min", "max");
                case PID -> Set.of("kp", "ki", "kd", "min", "max");
                case INTEGRATE -> Set.of("initial", "min", "max");
                case DELAY -> Set.of("initial");
                case LOW_PASS -> Set.of("tau");
                default -> Set.of();
            };
            for (var entry : node.parameters().entrySet()) {
                if (!allowed.contains(entry.getKey()) || !Double.isFinite(entry.getValue()))
                    throw new IllegalArgumentException(node.id() + ": invalid parameter " + entry.getKey());
            }
            if (node.op() == Op.INPUT) {
                double port = parameter(node, "port", 0);
                if (port != Math.rint(port) || port < 0 || port > 3)
                    throw new IllegalArgumentException(node.id() + ": port must be 0, 1, 2 or 3");
            }
            if (node.op() == Op.PID || node.op() == Op.CLAMP || node.op() == Op.INTEGRATE) {
                double min = parameter(node, "min", node.op() == Op.INTEGRATE ? -1e12 : -256);
                double max = parameter(node, "max", node.op() == Op.INTEGRATE ? 1e12 : 256);
                if (min > max) throw new IllegalArgumentException(node.id() + ": min exceeds max");
                if (node.op() == Op.INTEGRATE) {
                    double initial = parameter(node, "initial", 0);
                    if (initial < min || initial > max)
                        throw new IllegalArgumentException(node.id() + ": initial outside integration limits");
                }
            }
            if (node.op() == Op.LOW_PASS && parameter(node, "tau", 0.1) < 0)
                throw new IllegalArgumentException(node.id() + ": tau must be nonnegative");
        }
        Set<String> visited = new HashSet<>();
        List<Node> discarded = new ArrayList<>();
        for (Node node : graph.nodes()) sort(node, nodes, visited, new HashSet<>(), discarded);
    }

    private static Map<String, Node> index(Graph graph) {
        Map<String, Node> nodes = new LinkedHashMap<>();
        for (Node node : graph.nodes()) if (nodes.putIfAbsent(node.id(), node) != null)
            throw new IllegalArgumentException("Duplicate node id: " + node.id());
        return nodes;
    }

    private static void collect(String id, Map<String, Node> nodes, Set<String> active) {
        if (!active.add(id)) return;
        for (String reference : nodes.get(id).inputs()) collect(reference, nodes, active);
    }

    private static void sort(Node node, Map<String, Node> nodes, Set<String> visited, Set<String> path, List<Node> result) {
        if (visited.contains(node.id())) return;
        if (!path.add(node.id())) throw new IllegalArgumentException("Algebraic cycle at " + node.id() + "; insert DELAY");
        if (node.op() != Op.DELAY)
            for (String reference : node.inputs()) sort(nodes.get(reference), nodes, visited, path, result);
        path.remove(node.id());
        visited.add(node.id());
        result.add(node);
    }
}
