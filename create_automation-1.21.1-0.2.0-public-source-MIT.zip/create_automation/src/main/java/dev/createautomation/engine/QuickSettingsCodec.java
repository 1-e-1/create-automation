package dev.createautomation.engine;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonToken;
import java.io.IOException;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** Strict flat-string JSON payload, leaving the original graph format unchanged. */
public final class QuickSettingsCodec {
    public static final int MAX_JSON_LENGTH = 4096;
    private QuickSettingsCodec() { }
    public static QuickSettings defaults() {
        return new QuickSettings(QuickSettings.Mode.CLOSED_LOOP, 1, List.of(), List.of(new QuickSettings.Root(-1, 0)));
    }
    public static String toJson(QuickSettings settings) {
        QuickTransferMath.discrete(settings, QuickTransferEngine.DT);
        JsonObject result = new JsonObject();
        result.addProperty("mode", settings.mode().name());
        result.addProperty("gain", settings.gain());
        result.add("zeros", rootsJson(settings.zeros()));
        result.add("poles", rootsJson(settings.poles()));
        return new Gson().toJson(result);
    }
    private static JsonArray rootsJson(List<QuickSettings.Root> roots) {
        JsonArray array = new JsonArray();
        for (var root : roots) {
            JsonObject item = new JsonObject();
            item.addProperty("real", root.real());
            item.addProperty("imaginary", root.imaginary());
            array.add(item);
        }
        return array;
    }
    public static QuickSettings fromJson(String json) {
        if (json == null || json.isBlank() || json.length() > MAX_JSON_LENGTH)
            throw new IllegalArgumentException("Quick configuration must contain 1..4096 characters");
        try (JsonReader reader = new JsonReader(new StringReader(json))) {
            reader.setLenient(false);
            reader.beginObject();
            Set<String> fields = new HashSet<>();
            QuickSettings.Mode mode = null;
            Double gain = null;
            List<QuickSettings.Root> zeros = null, poles = null;
            while (reader.hasNext()) {
                String key = name(reader, fields);
                switch (key) {
                    case "mode" -> {
                        if (reader.peek() != JsonToken.STRING) throw new IllegalArgumentException("Mode must be a string");
                        mode = QuickSettings.Mode.valueOf(reader.nextString());
                    }
                    case "gain" -> gain = number(reader);
                    case "zeros" -> zeros = roots(reader);
                    case "poles" -> poles = roots(reader);
                    default -> throw new IllegalArgumentException("Unknown quick field: " + key);
                }
            }
            reader.endObject();
            if (reader.peek() != JsonToken.END_DOCUMENT || gain == null)
                throw new IllegalArgumentException("Missing gain or trailing JSON");
            QuickSettings settings = new QuickSettings(mode, gain, zeros, poles);
            QuickTransferMath.discrete(settings, QuickTransferEngine.DT);
            return settings;
        } catch (IOException | IllegalStateException e) {
            throw new IllegalArgumentException("Malformed quick configuration: " + e.getMessage(), e);
        }
    }
    private static List<QuickSettings.Root> roots(JsonReader reader) throws IOException {
        List<QuickSettings.Root> roots = new ArrayList<>();
        reader.beginArray();
        while (reader.hasNext()) {
            if (roots.size() >= QuickSettings.MAX_ORDER) throw new IllegalArgumentException("Too many roots");
            reader.beginObject();
            Set<String> fields = new HashSet<>();
            Double real = null;
            double imaginary = 0;
            while (reader.hasNext()) {
                String key = name(reader, fields);
                if (key.equals("real")) real = number(reader);
                else if (key.equals("imaginary")) imaginary = number(reader);
                else throw new IllegalArgumentException("Unknown root field: " + key);
            }
            reader.endObject();
            if (real == null) throw new IllegalArgumentException("A root needs its real component");
            roots.add(new QuickSettings.Root(real, imaginary));
        }
        reader.endArray();
        return roots;
    }
    private static String name(JsonReader reader, Set<String> fields) throws IOException {
        String key = reader.nextName();
        if (!fields.add(key)) throw new IllegalArgumentException("Duplicate field: " + key);
        return key;
    }
    private static double number(JsonReader reader) throws IOException {
        if (reader.peek() != JsonToken.NUMBER) throw new IllegalArgumentException("Expected a finite JSON number");
        double value = reader.nextDouble();
        if (!Double.isFinite(value)) throw new IllegalArgumentException("Expected a finite JSON number");
        return value;
    }
}
