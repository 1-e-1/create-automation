package dev.createautomation.engine;

import java.util.Arrays;
import java.util.Map;
import java.util.List;

/** Fixed-20-Hz Tustin transfer function, realized with first/second-order transposed sections. */
public final class QuickTransferEngine {
    public static final double DT = .05;
    private final QuickSettings settings;
    private final List<Section> sections;
    private final double direct;
    private static final class Section {
        final double[] b, a, state;
        Section(QuickTransferMath.Coefficients coefficients) {
            b = coefficients.numerator(); a = coefficients.denominator(); state = new double[a.length - 1];
        }
        double peek(double input) { return b[0] * input + (state.length == 0 ? 0 : state[0]); }
        double step(double input) {
            double output = peek(input);
            for (int i = 0; i < state.length; i++) {
                state[i] = (i + 1 < state.length ? state[i + 1] : 0) + b[i + 1] * input - a[i + 1] * output;
                if (!Double.isFinite(state[i])) return Double.NaN;
            }
            return output;
        }
    }
    public QuickTransferEngine(QuickSettings settings) {
        this.settings = settings;
        QuickTransferMath.discrete(settings, DT);
        sections = QuickTransferMath.sections(settings).stream().map(Section::new).toList();
        double d = 1;
        for (Section section : sections) d *= section.b[0];
        direct = d;
        if (!Double.isFinite(direct) || (settings.mode() == QuickSettings.Mode.CLOSED_LOOP
                && Math.abs(1 + direct) <= 1e-12 * Math.max(1, Math.abs(direct))))
            throw new IllegalArgumentException("Singular closed-loop direct feedthrough");
    }
    public QuickSettings settings() { return settings; }
    public void reset() { sections.forEach(section -> Arrays.fill(section.state, 0)); }
    public Signal step(Map<String, Signal> inputs, double dt) {
        if (inputs == null || !Double.isFinite(dt) || Math.abs(dt - DT) > 1e-12) return invalid("quick_requires_20Hz");
        Signal input = inputs.get("a");
        if (input == null) return invalid("quick_missing_A");
        if (!input.valid()) return invalid("quick_A: " + input.status());
        double value = input.value();
        if (settings.mode() == QuickSettings.Mode.CONTROLLER) {
            Signal measurement = inputs.get("b");
            if (measurement == null) return invalid("quick_missing_B");
            if (!measurement.valid()) return invalid("quick_B: " + measurement.status());
            value -= measurement.value();
        }
        if (!Double.isFinite(value)) return invalid("quick_nonfinite_error");
        double theoreticalOutput = 0;
        if (settings.mode() == QuickSettings.Mode.CLOSED_LOOP) {
            double history = 0;
            for (Section section : sections) history = section.peek(history);
            theoreticalOutput = (direct * value + history) / (1 + direct);
            value -= theoreticalOutput;
            if (!Double.isFinite(value) || !Double.isFinite(theoreticalOutput)) return invalid("quick_numeric_overflow");
        }
        for (Section section : sections) {
            value = section.step(value);
            if (!Double.isFinite(value)) return invalid("quick_numeric_overflow");
        }
        return Signal.valid(settings.mode() == QuickSettings.Mode.CLOSED_LOOP ? theoreticalOutput : value);
    }
    private Signal invalid(String status) { reset(); return Signal.invalid(status); }
}
