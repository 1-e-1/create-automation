package dev.createautomation.engine;

import java.util.List;

/** Continuous-time zero/pole/gain definition; complex entries represent an automatic conjugate pair. */
public record QuickSettings(Mode mode, double gain, List<Root> zeros, List<Root> poles) {
    public static final int MAX_ORDER = 6;
    public enum Mode { CONTROLLER, CLOSED_LOOP, FILTER }
    public record Root(double real, double imaginary) {
        public Root {
            if (!Double.isFinite(real) || !Double.isFinite(imaginary) || imaginary < 0
                    || Math.abs(real) > 1e6 || imaginary > 1e6)
                throw new IllegalArgumentException("Root must be finite, |real| <= 1e6, 0 <= imaginary <= 1e6");
        }
        public int order() { return imaginary == 0 ? 1 : 2; }
    }

    public QuickSettings {
        if (mode == null || zeros == null || poles == null || zeros.stream().anyMatch(java.util.Objects::isNull)
                || poles.stream().anyMatch(java.util.Objects::isNull))
            throw new IllegalArgumentException("Mode and root lists are required");
        if (!Double.isFinite(gain) || Math.abs(gain) > 1e12)
            throw new IllegalArgumentException("Gain must be finite and within +/-1e12");
        zeros = List.copyOf(zeros);
        poles = List.copyOf(poles);
        int numeratorOrder = zeros.stream().mapToInt(Root::order).sum();
        int denominatorOrder = poles.stream().mapToInt(Root::order).sum();
        if (denominatorOrder > MAX_ORDER || numeratorOrder > denominatorOrder)
            throw new IllegalArgumentException("Require numerator order <= denominator order <= " + MAX_ORDER);
    }
}
