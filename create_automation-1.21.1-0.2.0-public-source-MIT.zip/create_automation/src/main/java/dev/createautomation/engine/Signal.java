package dev.createautomation.engine;

/** Invalid values are always physically safe zeros, never NaN/Infinity or stale values. */
public record Signal(double value, boolean valid, String status) {
    public Signal {
        if (valid && !Double.isFinite(value)) {
            valid = false;
            status = "nonfinite";
        }
        if (!valid) value = 0.0;
        if (status == null || status.isBlank()) status = valid ? "ok" : "invalid";
        if (status.length() > 256) status = status.substring(0, 256);
    }

    public static Signal valid(double value) {
        return new Signal(value, true, "ok");
    }

    public static Signal invalid(String status) {
        return new Signal(0.0, false, status);
    }
}
