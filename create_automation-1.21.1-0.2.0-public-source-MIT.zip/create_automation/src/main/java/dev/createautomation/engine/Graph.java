package dev.createautomation.engine;

import java.util.List;

public record Graph(List<Node> nodes, String output) {
    public Graph {
        if (nodes == null || output == null || nodes.stream().anyMatch(java.util.Objects::isNull))
            throw new IllegalArgumentException("Graph nodes and output must not be null");
        nodes = List.copyOf(nodes);
    }
}
