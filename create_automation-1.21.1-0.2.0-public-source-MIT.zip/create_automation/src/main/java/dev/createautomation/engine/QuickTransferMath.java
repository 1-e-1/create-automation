package dev.createautomation.engine;

import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.ArrayList;

/** Real polynomial algebra and bilinear (Tustin) conversion, with coefficients in descending s order. */
public final class QuickTransferMath {
    public record Coefficients(double[] numerator, double[] denominator) {
        public Coefficients { numerator = numerator.clone(); denominator = denominator.clone(); }
        @Override public double[] numerator() { return numerator.clone(); }
        @Override public double[] denominator() { return denominator.clone(); }
    }
    private QuickTransferMath() { }

    public static Coefficients analog(QuickSettings settings) {
        double[] numerator = factors(settings.zeros());
        for (int i = 0; i < numerator.length; i++) numerator[i] *= settings.gain();
        double[] denominator = factors(settings.poles());
        if (settings.mode() == QuickSettings.Mode.CLOSED_LOOP) denominator = add(denominator, numerator);
        numerator = trim(numerator);
        denominator = trim(denominator);
        if (denominator.length == 1 && denominator[0] == 0)
            throw new IllegalArgumentException("1 + L(s) is identically zero; closed loop is undefined");
        if (numerator.length > denominator.length)
            throw new IllegalArgumentException("Feedback cancellation makes the selected transfer function improper");
        finite(numerator); finite(denominator);
        return new Coefficients(numerator, denominator);
    }

    /** Returned arrays are b[0..n], a[0..n] in ascending z^-1 order, with a[0] = 1. */
    public static Coefficients discrete(QuickSettings settings, double dt) {
        if (!Double.isFinite(dt) || dt <= 0) throw new IllegalArgumentException("dt must be finite and positive");
        for (var pole : settings.poles()) if (pole.imaginary() == 0 && pole.real() == 2 / dt)
            throw new IllegalArgumentException("Pole at +2/dt is singular under Tustin");
        Coefficients analog = analog(settings);
        return convert(analog, dt);
    }
    private static Coefficients convert(Coefficients analog, double dt) {
        int order = analog.denominator.length - 1;
        double[] b = substitute(analog.numerator, order, 2 / dt);
        double[] a = substitute(analog.denominator, order, 2 / dt);
        finite(b); finite(a);
        double norm = Arrays.stream(a).map(Math::abs).max().orElse(0);
        if (norm == 0 || Math.abs(a[0]) <= norm * 1e-12)
            throw new IllegalArgumentException("Singular or ill-conditioned Tustin denominator; adjust poles/gain");
        double leading = a[0];
        for (int i = 0; i < a.length; i++) { a[i] /= leading; b[i] /= leading; }
        finite(a); finite(b);
        return new Coefficients(b, a);
    }

    /** Low-order sections preserve numerical conditioning for repeated slow poles. */
    static List<Coefficients> sections(QuickSettings settings) {
        List<double[]> numerator = groupedFactors(settings.zeros()), denominator = groupedFactors(settings.poles());
        if (denominator.isEmpty()) return List.of(new Coefficients(new double[]{settings.gain()}, new double[]{1}));
        List<Coefficients> result = new ArrayList<>();
        double gainPerSection = Math.pow(Math.abs(settings.gain()), 1.0 / denominator.size());
        for (int i = 0; i < denominator.size(); i++) {
            double[] n = i < numerator.size() ? numerator.get(i).clone() : new double[]{1};
            double gain = gainPerSection * (i == 0 && settings.gain() < 0 ? -1 : 1);
            for (int j = 0; j < n.length; j++) n[j] *= gain;
            result.add(convert(new Coefficients(n, denominator.get(i)), QuickTransferEngine.DT));
        }
        return List.copyOf(result);
    }
    private static List<double[]> groupedFactors(List<QuickSettings.Root> roots) {
        List<double[]> result = new ArrayList<>();
        List<Double> real = new ArrayList<>();
        for (var root : roots) {
            if (root.imaginary() == 0) real.add(root.real());
            else result.add(new double[]{1, -2 * root.real(), root.real() * root.real() + root.imaginary() * root.imaginary()});
        }
        for (int i = 0; i < real.size(); i += 2) {
            double first = real.get(i);
            result.add(i + 1 < real.size() ? new double[]{1, -first - real.get(i + 1), first * real.get(i + 1)}
                    : new double[]{1, -first});
        }
        return result;
    }

    /** Conservative Schur recursion; a failed/borderline numerical check is not a proof of stability. */
    public static boolean strictlyStable(QuickSettings settings) {
        if (settings.mode() != QuickSettings.Mode.CLOSED_LOOP)
            return settings.poles().stream().allMatch(root -> root.real() < 0);
        double[] a = discrete(settings, QuickTransferEngine.DT).denominator();
        while (a.length > 1) {
            double scale = Math.abs(a[0]);
            if (!Double.isFinite(scale) || scale == 0 || Math.abs(a[a.length - 1]) >= scale * (1 - 1e-10)) return false;
            double tail = a[a.length - 1] / a[0];
            double[] next = new double[a.length - 1];
            for (int i = 0; i < next.length; i++) next[i] = a[i] / a[0] - tail * a[a.length - i - 1] / a[0];
            a = next;
        }
        return true;
    }

    private static double[] factors(List<QuickSettings.Root> roots) {
        double[] result = {1};
        for (var root : roots) {
            double re = root.real(), im = root.imaginary();
            result = multiply(result, im == 0 ? new double[]{1, -re}
                    : new double[]{1, -2 * re, re * re + im * im});
        }
        return result;
    }
    private static double[] add(double[] first, double[] second) {
        double[] result = new double[Math.max(first.length, second.length)];
        for (int i = 0; i < first.length; i++) result[result.length - first.length + i] += first[i];
        for (int i = 0; i < second.length; i++) result[result.length - second.length + i] += second[i];
        return result;
    }
    private static double[] multiply(double[] first, double[] second) {
        double[] result = new double[first.length + second.length - 1];
        for (int i = 0; i < first.length; i++)
            for (int j = 0; j < second.length; j++) result[i + j] += first[i] * second[j];
        return result;
    }
    private static double[] trim(double[] values) {
        int first = 0;
        while (first < values.length - 1 && values[first] == 0) first++;
        return Arrays.copyOfRange(values, first, values.length);
    }
    private static double[] substitute(double[] polynomial, int order, double alpha) {
        double[] result = new double[order + 1];
        for (int i = 0; i < polynomial.length; i++) {
            int power = polynomial.length - i - 1;
            double[] term = {1};
            for (int j = 0; j < power; j++) term = multiply(term, new double[]{1, -1});
            for (int j = power; j < order; j++) term = multiply(term, new double[]{1, 1});
            double scale = polynomial[i] * Math.pow(alpha, power);
            for (int j = 0; j < term.length; j++) result[j] += term[j] * scale;
        }
        return result;
    }
    private static void finite(double[] values) {
        for (double value : values) if (!Double.isFinite(value))
            throw new IllegalArgumentException("Transfer coefficients overflowed");
    }

    public static String factorFormula(QuickSettings settings) {
        String name = settings.mode() == QuickSettings.Mode.CONTROLLER ? "C" : settings.mode() == QuickSettings.Mode.CLOSED_LOOP ? "L" : "G";
        return name + "(s) = " + number(settings.gain()) + factorText(settings.zeros()) + " / ("
                + (settings.poles().isEmpty() ? "1" : factorText(settings.poles()).substring(1)) + ")";
    }
    private static String factorText(List<QuickSettings.Root> roots) {
        StringBuilder text = new StringBuilder();
        for (var root : roots) {
            String offset = root.real() < 0 ? "+" + number(-root.real()) : root.real() > 0 ? "-" + number(root.real()) : "";
            if (root.imaginary() == 0) text.append("*(s").append(offset).append(')');
            else text.append("*((s").append(offset).append(")^2+").append(number(root.imaginary() * root.imaginary())).append(')');
        }
        return text.toString();
    }
    public static String expandedFormula(QuickSettings settings) {
        Coefficients coefficients = analog(settings);
        String name = settings.mode() == QuickSettings.Mode.CLOSED_LOOP ? "T(s)=L(s)/(1+L(s))" : settings.mode() == QuickSettings.Mode.CONTROLLER ? "C(s)" : "G(s)";
        return name + " = (" + polynomial(coefficients.numerator) + ") / (" + polynomial(coefficients.denominator) + ")";
    }
    public static String polynomial(double[] coefficients) {
        StringBuilder result = new StringBuilder();
        for (int i = 0; i < coefficients.length; i++) {
            double coefficient = coefficients[i];
            if (coefficient == 0) continue;
            int power = coefficients.length - i - 1;
            if (result.length() > 0) result.append(coefficient < 0 ? " - " : " + ");
            else if (coefficient < 0) result.append('-');
            if (Math.abs(coefficient) != 1 || power == 0) result.append(number(Math.abs(coefficient)));
            if (power > 0) result.append('s');
            if (power > 1) result.append('^').append(power);
        }
        return result.isEmpty() ? "0" : result.toString();
    }
    private static String number(double value) { return String.format(Locale.ROOT, "%.6g", value); }
}
