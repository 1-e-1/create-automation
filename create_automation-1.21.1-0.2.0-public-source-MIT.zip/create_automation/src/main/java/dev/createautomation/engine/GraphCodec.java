package dev.createautomation.engine;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonToken;

import java.io.IOException;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/** Small, strict and version-independent graph format shared by disk, editor and server validation. */
public final class GraphCodec {
    public static final int MAX_JSON_LENGTH = 32_768;
    private static final Gson GSON = new GsonBuilder().disableHtmlEscaping().create();
    private GraphCodec() {}

    public static Graph fromJson(String json) {
        if (json == null || json.isBlank() || json.length() > MAX_JSON_LENGTH)
            throw new IllegalArgumentException("Graph JSON must contain 1 to " + MAX_JSON_LENGTH + " characters");
        Graph graph;
        try (JsonReader reader = new JsonReader(new StringReader(json))) {
            reader.setLenient(false);
            reader.beginObject();
            Set<String> seen = new HashSet<>();
            List<Node> nodes = null;
            String output = null;
            while (reader.hasNext()) {
                String field = uniqueName(reader, seen);
                switch (field) {
                    case "nodes" -> {
                        nodes = new ArrayList<>();
                        reader.beginArray();
                        while (reader.hasNext()) {
                            if (nodes.size() >= ControlEngine.MAX_NODES)
                                throw new IllegalArgumentException("Too many graph nodes");
                            nodes.add(readNode(reader));
                        }
                        reader.endArray();
                    }
                    case "output" -> output = string(reader);
                    default -> throw new IllegalArgumentException("Unknown graph field: " + field);
                }
            }
            reader.endObject();
            if (reader.peek() != JsonToken.END_DOCUMENT) throw new IllegalArgumentException("Trailing JSON content");
            graph = new Graph(nodes, output);
        } catch (IOException | IllegalStateException | NumberFormatException e) {
            throw new IllegalArgumentException("Malformed graph JSON: " + e.getMessage(), e);
        }
        ControlEngine.validate(graph);
        return graph;
    }

    private static Node readNode(JsonReader reader) throws IOException {
        reader.beginObject();
        Set<String> seen = new HashSet<>();
        String id = null;
        Op op = null;
        List<String> inputs = new ArrayList<>();
        Map<String, Double> parameters = new LinkedHashMap<>();
        while (reader.hasNext()) {
            String field = uniqueName(reader, seen);
            switch (field) {
                case "id" -> id = string(reader);
                case "op" -> op = Op.valueOf(string(reader).toUpperCase(Locale.ROOT));
                case "inputs" -> {
                    reader.beginArray();
                    while (reader.hasNext()) {
                        if (inputs.size() >= 2) throw new IllegalArgumentException("A node has at most two inputs");
                        inputs.add(string(reader));
                    }
                    reader.endArray();
                }
                case "parameters" -> {
                    reader.beginObject();
                    Set<String> parameterNames = new HashSet<>();
                    while (reader.hasNext()) {
                        String parameter = uniqueName(reader, parameterNames);
                        if (parameters.size() >= 5) throw new IllegalArgumentException("Too many node parameters");
                        if (reader.peek() != JsonToken.NUMBER) throw new IllegalArgumentException("Parameter must be a number: " + parameter);
                        parameters.put(parameter, reader.nextDouble());
                    }
                    reader.endObject();
                }
                default -> throw new IllegalArgumentException("Unknown node field: " + field);
            }
        }
        reader.endObject();
        return new Node(id, op, inputs, parameters);
    }

    private static String uniqueName(JsonReader reader, Set<String> seen) throws IOException {
        String name = reader.nextName();
        if (!seen.add(name)) throw new IllegalArgumentException("Duplicate JSON field: " + name);
        return name;
    }

    private static String string(JsonReader reader) throws IOException {
        if (reader.peek() != JsonToken.STRING) throw new IllegalArgumentException("Expected JSON string");
        return reader.nextString();
    }

    public static String toJson(Graph graph) {
        ControlEngine.validate(graph);
        JsonObject root = new JsonObject();
        JsonArray nodes = new JsonArray();
        for (Node node : graph.nodes()) {
            JsonObject item = new JsonObject();
            item.addProperty("id", node.id());
            item.addProperty("op", node.op().name());
            JsonArray inputs = new JsonArray();
            node.inputs().forEach(inputs::add);
            item.add("inputs", inputs);
            JsonObject parameters = new JsonObject();
            node.parameters().entrySet().stream().sorted(Map.Entry.comparingByKey())
                    .forEach(entry -> parameters.addProperty(entry.getKey(), entry.getValue()));
            item.add("parameters", parameters);
            nodes.add(item);
        }
        root.add("nodes", nodes);
        root.addProperty("output", graph.output());
        return GSON.toJson(root);
    }

    /** Editable starting points, not special engine behavior or pre-tuned aircraft controllers. */
    public static Graph preset(String name) {
        if (name == null) throw new IllegalArgumentException("Preset name is required");
        Graph graph = switch (name.toLowerCase(Locale.ROOT)) {
            case "passthrough" -> new Graph(List.of(input("input", 0)), "input");
            case "sum" -> new Graph(List.of(input("a", 0), input("b", 1),
                    node("sum", Op.ADD, List.of("a", "b"), Map.of())), "sum");
            case "pid" -> new Graph(List.of(input("target", 0), input("measurement", 1),
                    node("pid", Op.PID, List.of("target", "measurement"),
                            Map.of("kp", 1.0, "ki", 0.0, "kd", 0.0, "min", -256.0, "max", 256.0))), "pid");
            case "altitude" -> new Graph(List.of(
                    input("target", 0), input("height", 1), input("vertical_speed", 2),
                    node("height_error", Op.SUBTRACT, List.of("target", "height"), Map.of()),
                    node("height_gain", Op.GAIN, List.of("height_error"), Map.of("gain", 0.8)),
                    node("climb_target", Op.CLAMP, List.of("height_gain"), Map.of("min", -4.0, "max", 4.0)),
                    node("speed_pid", Op.PID, List.of("climb_target", "vertical_speed"),
                            Map.of("kp", 16.0, "ki", 4.0, "kd", 1.0, "min", -96.0, "max", 160.0)),
                    node("hover_bias", Op.CONSTANT, List.of(), Map.of("value", 96.0)),
                    node("collective", Op.ADD, List.of("hover_bias", "speed_pid"), Map.of()),
                    node("rpm", Op.CLAMP, List.of("collective"), Map.of("min", 0.0, "max", 256.0))), "rpm");
            default -> throw new IllegalArgumentException("Unknown graph preset: " + name);
        };
        ControlEngine.validate(graph);
        return graph;
    }

    private static Node input(String id, int port) {
        return node(id, Op.INPUT, List.of(), Map.of("port", (double) port));
    }

    private static Node node(String id, Op op, List<String> inputs, Map<String, Double> parameters) {
        return new Node(id, op, inputs, parameters);
    }
}
