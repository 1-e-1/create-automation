package dev.createautomation.engine;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

class ControlEngineTest {
    private static Node input(String id, int port) {
        return new Node(id, Op.INPUT, List.of(), Map.of("port", (double) port));
    }

    private static Node node(String id, Op op, List<String> inputs, Map<String, Double> parameters) {
        return new Node(id, op, inputs, parameters);
    }

    private static ControlEngine unary(Op op, Map<String, Double> parameters) {
        return new ControlEngine(new Graph(List.of(input("input", 0), node("out", op, List.of("input"), parameters)), "out"));
    }

    private static ControlEngine pid(double kp, double ki, double kd, double min, double max) {
        return new ControlEngine(new Graph(List.of(input("target", 0), input("actual", 1),
                node("pid", Op.PID, List.of("target", "actual"),
                        Map.of("kp", kp, "ki", ki, "kd", kd, "min", min, "max", max))), "pid"));
    }

    private static Map<String, Signal> signals(double a, double b) {
        return Map.of("a", Signal.valid(a), "b", Signal.valid(b));
    }

    private static double step(ControlEngine engine, double value, double dt) {
        Signal signal = engine.step(Map.of("a", Signal.valid(value)), dt);
        assertTrue(signal.valid(), signal.status());
        return signal.value();
    }

    @Test void fractionalValuesArePreservedAcrossEveryInputPort() {
        for (int port = 0; port < 4; port++) {
            ControlEngine engine = new ControlEngine(new Graph(List.of(input("sensor", port)), "sensor"));
            Signal output = engine.step(Map.of("a", Signal.valid(.123456789), "b", Signal.valid(-1.25),
                    "c", Signal.valid(87.12345), "d", Signal.valid(.0000001)), .05);
            assertTrue(output.valid());
            assertEquals(new double[]{.123456789, -1.25, 87.12345, .0000001}[port], output.value());
        }
    }

    @Test void arithmeticOperationsComposeIntoUserDefinedGraphs() {
        Map<Op, Double> expected = Map.of(Op.ADD, 2.5, Op.SUBTRACT, -1.5, Op.MULTIPLY, 1.0,
                Op.DIVIDE, .25, Op.MIN, .5, Op.MAX, 2.0);
        expected.forEach((operation, result) -> {
            ControlEngine engine = new ControlEngine(new Graph(List.of(
                    node("out", operation, List.of("a", "b"), Map.of()), input("b", 1), input("a", 0)), "out"));
            Signal output = engine.step(signals(.5, 2), .05);
            assertTrue(output.valid(), operation.name());
            assertEquals(result, output.value(), operation.name());
        });
        assertEquals(-.5, step(unary(Op.NEGATE, Map.of()), .5, .05));
        assertEquals(.5, step(unary(Op.ABS, Map.of()), -.5, .05));
        assertEquals(.1875, step(unary(Op.GAIN, Map.of("gain", .375)), .5, .05));
        assertEquals(.75, step(unary(Op.CLAMP, Map.of("min", -.75, "max", .75)), 200, .05));
    }

    @Test void explicitFeedbackDelayAccumulatesAndIsIndependentOfNodeOrder() {
        Node one = node("one", Op.CONSTANT, List.of(), Map.of("value", .125));
        Node memory = node("memory", Op.DELAY, List.of("sum"), Map.of("initial", 0.0));
        Node sum = node("sum", Op.ADD, List.of("memory", "one"), Map.of());
        ControlEngine first = new ControlEngine(new Graph(List.of(one, memory, sum), "sum"));
        ControlEngine second = new ControlEngine(new Graph(List.of(sum, one, memory), "sum"));
        for (int i = 1; i <= 20; i++) {
            assertEquals(i * .125, first.step(Map.of(), .05).value());
            assertEquals(i * .125, second.step(Map.of(), .05).value());
        }
        first.reset();
        assertEquals(.125, first.step(Map.of(), .05).value());
    }

    @Test void delayStatesAreCommittedSimultaneously() {
        ControlEngine engine = new ControlEngine(new Graph(List.of(
                node("left", Op.DELAY, List.of("right"), Map.of("initial", 1.0)),
                node("right", Op.DELAY, List.of("left"), Map.of("initial", 2.0))), "left"));
        assertEquals(1, engine.step(Map.of(), .05).value());
        assertEquals(2, engine.step(Map.of(), .05).value());
        assertEquals(1, engine.step(Map.of(), .05).value());
        assertEquals(2, engine.step(Map.of(), .05).value());
    }

    @Test void delayCannotHideSensorLossAndRestartsAtInitialValue() {
        ControlEngine engine = unary(Op.DELAY, Map.of("initial", 7.0));
        assertEquals(7, step(engine, 2, .05));
        assertEquals(2, step(engine, 3, .05));
        Signal failed = engine.step(Map.of(), .05);
        assertFalse(failed.valid());
        assertEquals(0, failed.value());
        assertEquals(7, step(engine, 9, .05));
    }

    @Test void disconnectedInputsDoNotInvalidateUsefulOutput() {
        ControlEngine engine = new ControlEngine(new Graph(List.of(input("unused", 3),
                node("answer", Op.CONSTANT, List.of(), Map.of("value", .537))), "answer"));
        Signal signal = engine.step(Map.of(), .05);
        assertTrue(signal.valid());
        assertEquals(.537, signal.value());
    }

    @Test void integratorUsesSecondsClampsAndResetsOnFault() {
        ControlEngine engine = unary(Op.INTEGRATE, Map.of("initial", 2.0, "min", -3.0, "max", 3.0));
        assertEquals(2.05, step(engine, .25, .2), 1e-12);
        for (int i = 0; i < 100; i++) step(engine, .25, .2);
        assertEquals(3, step(engine, .25, .2));
        assertFalse(engine.step(Map.of("a", Signal.invalid("sensor_unloaded")), .2).valid());
        assertEquals(2, step(engine, 0, .2));
    }

    @Test void derivativeAndFilterResetAfterMissingSample() {
        ControlEngine derivative = unary(Op.DERIVATIVE, Map.of());
        assertEquals(0, step(derivative, 10, .05));
        assertEquals(4, step(derivative, 10.2, .05), 1e-12);
        assertFalse(derivative.step(Map.of(), .05).valid());
        assertEquals(0, step(derivative, 100, .05));
        ControlEngine filter = unary(Op.LOW_PASS, Map.of("tau", .5));
        assertEquals(0, step(filter, 0, .1));
        assertEquals(1 - Math.exp(-.2), step(filter, 1, .1), 1e-12);
        assertFalse(filter.step(Map.of(), .1).valid());
        assertEquals(8, step(filter, 8, .1));
    }

    @Test void filteringIsStableAcrossDifferentTimeStepsAndLargeFiniteInputs() {
        ControlEngine first = unary(Op.LOW_PASS, Map.of("tau", .5));
        ControlEngine second = unary(Op.LOW_PASS, Map.of("tau", .5));
        step(first, 0, .1);
        step(second, 0, .1);
        double result = 0;
        for (int i = 0; i < 10; i++) result = step(first, 1, .01);
        assertEquals(step(second, 1, .1), result, 1e-12);
        ControlEngine huge = unary(Op.LOW_PASS, Map.of("tau", 1.0));
        step(huge, Double.MAX_VALUE, .05);
        assertTrue(Double.isFinite(step(huge, -Double.MAX_VALUE, .05)));
        assertEquals(-123, step(unary(Op.LOW_PASS, Map.of("tau", 0.0)), -123, .05));
    }

    @Test void pidDerivativeActsOnMeasurementAndDoesNotKickOnSetpointChange() {
        ControlEngine engine = pid(0, 0, 5, -1000, 1000);
        assertEquals(0, engine.step(signals(0, 0), .1).value());
        assertEquals(0, engine.step(signals(10, 0), .1).value());
        assertEquals(-50, engine.step(signals(10, 1), .1).value());
        assertFalse(engine.step(Map.of("a", Signal.valid(10)), .1).valid());
        assertEquals(0, engine.step(signals(10, 20), .1).value());
    }

    @Test void antiWindupPreventsStoredSaturationAfterUnreachableSetpoint() {
        ControlEngine engine = pid(2, 1, 0, 0, 1);
        for (int i = 0; i < 2_000; i++) assertEquals(1, engine.step(signals(100, 0), .05).value());
        assertEquals(0, engine.step(signals(0, 0), .05).value());
        assertTrue(engine.step(signals(.1, 0), .05).value() < .3);
        ControlEngine negative = pid(2, 1, 0, -1, 1);
        for (int i = 0; i < 2_000; i++) assertEquals(-1, negative.step(signals(-100, 0), .05).value());
        assertEquals(0, negative.step(signals(0, 0), .05).value());
    }

    @Test void integralOnlyControllerStoresOnlyThePartialStepToItsOutputLimit() {
        ControlEngine engine = pid(0, 20, 0, -1, 1);
        assertEquals(1, engine.step(signals(10, 0), .05).value());
        // A zero error must retain the actual integral command, rather than exposing a hidden zero.
        assertEquals(1, engine.step(signals(0, 0), .05).value());
        for (int i = 0; i < 100; i++) assertEquals(1, engine.step(signals(10, 0), .05).value());
        assertEquals(.5, engine.step(signals(-.5, 0), .05).value());
        assertEquals(-1, engine.step(signals(-10, 0), .05).value());
        assertEquals(-1, engine.step(signals(0, 0), .05).value());
        assertEquals(-.5, engine.step(signals(.5, 0), .05).value());
    }

    @Test void pidPartialIntegralStepKeepsOutputAndStateConsistentAtEitherLimit() {
        ControlEngine engine = pid(.2, 20, 0, -1, 1);
        // P=.2, proposed I=1: keep exactly I=.8 to reach U=1.
        assertEquals(1, engine.step(signals(1, 0), .05).value(), 1e-12);
        assertEquals(.8, engine.step(signals(0, 0), .05).value(), 1e-12);
        engine.reset();
        assertEquals(-1, engine.step(signals(-1, 0), .05).value(), 1e-12);
        assertEquals(-.8, engine.step(signals(0, 0), .05).value(), 1e-12);
    }

    @Test void pidTracksFirstOrderPlantAndRejectsLoadDisturbance() {
        ControlEngine engine = pid(2, 1, .05, 0, 1);
        double actual = 0;
        double dt = .02;
        for (int i = 0; i < 3_000; i++) {
            Signal output = engine.step(signals(.6, actual), dt);
            assertTrue(output.valid(), output.status());
            assertTrue(output.value() >= 0 && output.value() <= 1);
            double disturbance = i >= 1_000 ? .15 : 0;
            actual += dt * (-actual + output.value() - disturbance) / .7;
            if (i == 999) assertEquals(.6, actual, .001);
        }
        assertEquals(.6, actual, .001, "Integral control must remove a constant load error");
    }

    @Test void altitudePresetClosesHeightAndVelocityLoopsOnAnIllustrativePlant() {
        ControlEngine engine = new ControlEngine(GraphCodec.preset("altitude"));
        double height = 0, velocity = 0;
        double dt = .05;
        for (int i = 0; i < 2_000; i++) {
            Signal output = engine.step(Map.of("a", Signal.valid(10), "b", Signal.valid(height), "c", Signal.valid(velocity)), dt);
            assertTrue(output.valid(), output.status());
            assertTrue(output.value() >= 0 && output.value() <= 256);
            // Illustrative continuous plant; this is an engine test, not a claimed Sable aircraft model.
            velocity += dt * ((output.value() - 96) * .08 - .2 * velocity);
            height += dt * velocity;
            if (i == 700) velocity -= 1.5;
            assertTrue(Double.isFinite(height));
        }
        assertEquals(10, height, .01);
        assertEquals(0, velocity, .01);
    }

    @Test void numericFaultsAreInvalidZerosAndClearPreviouslyAccumulatedState() {
        ControlEngine engine = new ControlEngine(new Graph(List.of(input("a", 0), input("b", 1),
                node("integral", Op.INTEGRATE, List.of("a"), Map.of()),
                node("quotient", Op.DIVIDE, List.of("integral", "b"), Map.of())), "quotient"));
        assertEquals(.5, engine.step(signals(1, 1), .5).value());
        Signal failed = engine.step(signals(1, 0), .5);
        assertFalse(failed.valid());
        assertEquals(0, failed.value());
        assertEquals(.5, engine.step(signals(1, 1), .5).value());
        ControlEngine overflow = unary(Op.GAIN, Map.of("gain", 2.0));
        assertFalse(overflow.step(Map.of("a", Signal.valid(Double.MAX_VALUE)), .05).valid());
        for (double badDt : new double[]{0, -1, Double.NaN, Double.POSITIVE_INFINITY}) {
            assertFalse(engine.step(signals(1, 1), badDt).valid());
            assertEquals(.5, engine.step(signals(1, 1), .5).value());
        }
        assertFalse(engine.step(null, .05).valid());
    }

    @Test void signalConstructorNeverExposesNonfiniteOrInvalidValuesAsActuatorCommands() {
        for (double value : new double[]{Double.NaN, Double.POSITIVE_INFINITY, Double.NEGATIVE_INFINITY}) {
            Signal signal = Signal.valid(value);
            assertFalse(signal.valid());
            assertEquals(0, signal.value());
        }
        assertEquals(0, new Signal(500, false, "stale").value());
    }

    @Test void invalidDefinitionsAreRejectedBeforeTheyReachRuntime() {
        List<Graph> bad = List.of(
                new Graph(List.of(), "x"),
                new Graph(List.of(input("a", 0)), "missing"),
                new Graph(List.of(input("a", 0), input("a", 1)), "a"),
                new Graph(List.of(input("a", 4)), "a"),
                new Graph(List.of(node("a", Op.INPUT, List.of(), Map.of("port", .5))), "a"),
                new Graph(List.of(node("a", Op.CONSTANT, List.of(), Map.of("value", Double.NaN))), "a"),
                new Graph(List.of(node("a", Op.CONSTANT, List.of(), Map.of("typo", 1.0))), "a"),
                new Graph(List.of(node("a", Op.ADD, List.of("a"), Map.of())), "a"),
                new Graph(List.of(node("a", Op.GAIN, List.of("missing"), Map.of())), "a"),
                new Graph(List.of(node("a", Op.GAIN, List.of("a"), Map.of())), "a"),
                new Graph(List.of(node("a", Op.NEGATE, List.of("b"), Map.of()), node("b", Op.NEGATE, List.of("a"), Map.of())), "a"),
                new Graph(List.of(input("a", 0), node("clamp", Op.CLAMP, List.of("a"), Map.of("min", 10.0, "max", 1.0))), "clamp"),
                new Graph(List.of(input("a", 0), node("filter", Op.LOW_PASS, List.of("a"), Map.of("tau", -1.0))), "filter"),
                new Graph(List.of(input("a", 0), node("int", Op.INTEGRATE, List.of("a"), Map.of("initial", 3.0, "max", 2.0))), "int")
        );
        for (Graph graph : bad) assertThrows(IllegalArgumentException.class, () -> new ControlEngine(graph), graph.toString());
        List<Node> tooMany = new ArrayList<>();
        for (int i = 0; i <= ControlEngine.MAX_NODES; i++) tooMany.add(input("n" + i, 0));
        assertThrows(IllegalArgumentException.class, () -> ControlEngine.validate(new Graph(tooMany, "n0")));
    }

    @Test void definitionsAreImmutableAndEngineInstancesDoNotShareMemory() {
        List<String> inputs = new ArrayList<>(List.of("in"));
        Node integral = new Node("out", Op.INTEGRATE, inputs, Map.of());
        inputs.clear();
        assertEquals(List.of("in"), integral.inputs());
        List<Node> nodes = new ArrayList<>(List.of(input("in", 0), integral));
        Graph graph = new Graph(nodes, "out");
        nodes.clear();
        ControlEngine first = new ControlEngine(graph), second = new ControlEngine(graph);
        step(first, 10, .5);
        assertEquals(1, step(second, 2, .5));
        assertEquals(6, step(first, 2, .5));
        assertThrows(UnsupportedOperationException.class, () -> graph.nodes().clear());
        assertThrows(UnsupportedOperationException.class, () -> integral.parameters().put("initial", 2.0));
    }
}
