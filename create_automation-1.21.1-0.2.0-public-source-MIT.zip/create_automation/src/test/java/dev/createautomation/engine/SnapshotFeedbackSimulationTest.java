package dev.createautomation.engine;

import org.junit.jupiter.api.Test;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Pure-JVM simulation of the audited SignalBus transport contract, NOT a Minecraft integration
 * test. Sensors sample an independent physical state, all consumers read a previous-tick snapshot,
 * and actuators apply after sampling. This exposes cold-start, latency and recovery behavior without
 * introducing made-up valid zeros for missing bus inputs. Actual Create propagation requires separate
 * in-game verification.
 */
class SnapshotFeedbackSimulationTest {
    private static final Signal MISSING = Signal.invalid("awaiting_source");
    private static final double TARGET = 64.125;

    private static ControlEngine speedController() {
        return new ControlEngine(new Graph(List.of(
                new Node("target", Op.INPUT, List.of(), Map.of("port", 0.0)),
                new Node("sensor", Op.INPUT, List.of(), Map.of("port", 1.0)),
                new Node("controller", Op.PID, List.of("target", "sensor"),
                        Map.of("kp", .15, "ki", .4, "kd", 0.0, "min", -256.0, "max", 256.0))), "controller"));
    }

    private record Frame(Signal controller, Signal actuator, Signal sensor, double shaft) { }

    private static final class Loop {
        final ControlEngine controller = speedController();
        final boolean terminal;
        Map<String, Signal> previous = Map.of();
        double shaft;
        boolean sourceLoaded = true;
        boolean sensorLoaded = true;
        boolean duplicateCommand;

        Loop(boolean terminal) { this.terminal = terminal; }

        Frame tick() {
            // As in SignalBus, current publisher presence/conflicts invalidate the previous snapshot.
            Map<String, Signal> snapshot = new HashMap<>(previous);
            if (!sourceLoaded) snapshot.remove("target");
            if (!sensorLoaded) snapshot.remove("measurement");
            if (duplicateCommand) snapshot.put("command", Signal.invalid("duplicate_publishers"));
            Signal control = controller.step(Map.of("a", snapshot.getOrDefault("target", MISSING),
                    "b", snapshot.getOrDefault("measurement", MISSING)), .05);
            if (duplicateCommand) {
                controller.reset();
                control = Signal.invalid("duplicate_publishers");
            }
            Signal terminalOutput = snapshot.getOrDefault("command", MISSING);
            Signal actuator = snapshot.getOrDefault(terminal ? "terminal" : "command", MISSING);
            // AutomationBlockEntity RPM_SENSOR evaluates getSpeed() independently of command validity.
            Signal measured = sensorLoaded ? Signal.valid(shaft) : MISSING;
            Map<String, Signal> next = new HashMap<>();
            if (sourceLoaded) next.put("target", Signal.valid(TARGET));
            if (sensorLoaded) next.put("measurement", measured);
            next.put("command", control);
            if (terminal) next.put("terminal", terminalOutput);
            // Physical update occurs after ALL readings, matching SignalBus.acceptEvaluation phase.
            shaft = actuator.valid() ? (float) Math.max(-256, Math.min(256, actuator.value())) : 0;
            previous = Map.copyOf(next);
            return new Frame(control, actuator, measured, shaft);
        }
    }

    @Test void independentRpmSensorStartsTheClosedLoopFromAnEmptyBus() {
        Loop loop = new Loop(false);
        Frame t0 = loop.tick();
        assertFalse(t0.controller.valid());
        assertFalse(t0.actuator.valid());
        assertTrue(t0.sensor.valid(), "A stopped physical shaft is a valid zero measurement");
        assertEquals(0, t0.sensor.value());
        Frame t1 = loop.tick();
        assertTrue(t1.controller.valid());
        assertFalse(t1.actuator.valid(), "Controller publication reaches consumers on the next tick");
        Frame t2 = loop.tick();
        assertTrue(t2.actuator.valid());
        assertTrue(t2.shaft > 0);
        assertEquals(0, t2.sensor.value(), "The sensor is sampled before this tick's actuator update");
        Frame t3 = loop.tick();
        assertEquals(t2.shaft, t3.sensor.value());
        for (int tick = 0; tick < 1_200; tick++) assertTrue(loop.tick().controller.valid());
        assertEquals(TARGET, loop.shaft, .001, "PI tracking must survive transport delay and float RPM conversion");
    }

    @Test void systemOutputAddsOneTickButDoesNotPreventColdStartOrConvergence() {
        Loop loop = new Loop(true);
        for (int tick = 0; tick < 3; tick++) assertEquals(0, loop.tick().shaft);
        assertTrue(loop.tick().shaft > 0);
        for (int tick = 0; tick < 1_200; tick++) assertTrue(loop.tick().controller.valid());
        assertEquals(TARGET, loop.shaft, .001);
    }

    @Test void sensorLossStopsTheActuatorAfterPropagationAndCanRecoverFromZero() {
        Loop loop = new Loop(false);
        for (int tick = 0; tick < 500; tick++) loop.tick();
        loop.sensorLoaded = false;
        assertFalse(loop.tick().controller.valid());
        Frame stopped = loop.tick();
        assertFalse(stopped.actuator.valid());
        assertEquals(0, stopped.shaft);
        for (int tick = 0; tick < 5; tick++) assertFalse(loop.tick().controller.valid());
        loop.sensorLoaded = true;
        Frame restored = loop.tick();
        assertTrue(restored.sensor.valid());
        assertFalse(restored.controller.valid(), "Restored sensor still has one transport tick");
        assertTrue(loop.tick().controller.valid());
        assertTrue(loop.tick().actuator.valid());
        for (int tick = 0; tick < 1_200; tick++) loop.tick();
        assertEquals(TARGET, loop.shaft, .001);
    }

    @Test void lostSourceAndDuplicateCommandCannotLatchTheControllerPermanentlyInvalid() {
        Loop loop = new Loop(false);
        for (int tick = 0; tick < 500; tick++) loop.tick();
        loop.sourceLoaded = false;
        assertFalse(loop.tick().controller.valid());
        assertEquals(0, loop.tick().shaft);
        loop.sourceLoaded = true;
        for (int tick = 0; tick < 5; tick++) loop.tick();
        assertTrue(loop.shaft > 0);
        loop.duplicateCommand = true;
        Frame conflict = loop.tick();
        assertFalse(conflict.actuator.valid());
        assertFalse(conflict.controller.valid());
        assertEquals(0, conflict.shaft, "A present duplicate is invalidated before consumer evaluation");
        loop.duplicateCommand = false;
        assertTrue(loop.tick().controller.valid());
        assertTrue(loop.tick().actuator.valid());
        for (int tick = 0; tick < 1_200; tick++) loop.tick();
        assertEquals(TARGET, loop.shaft, .001);
    }

    @Test void unseededExternalNumericFeedbackCannotInventValidInputs() {
        ControlEngine engine = speedController();
        Signal previous = MISSING;
        for (int tick = 0; tick < 20; tick++) {
            previous = engine.step(Map.of("a", Signal.valid(TARGET), "b", previous), .05);
            assertFalse(previous.valid());
            assertEquals(0, previous.value());
        }
        // Internal numeric recursion has a real, explicitly configured initial state instead.
        ControlEngine initialized = new ControlEngine(new Graph(List.of(
                new Node("one", Op.CONSTANT, List.of(), Map.of("value", 1.0)),
                new Node("memory", Op.DELAY, List.of("sum"), Map.of("initial", 0.0)),
                new Node("sum", Op.ADD, List.of("memory", "one"), Map.of())), "sum"));
        for (int tick = 0; tick < 20; tick++) {
            Signal output = initialized.step(Map.of(), .05);
            assertTrue(output.valid());
            assertEquals(tick + 1, output.value());
        }
    }
}
