package dev.createautomation.engine;

import org.junit.jupiter.api.Test;

import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

class GraphCodecTest {
    @Test void everyPresetRoundTripsAndIsAnOrdinaryEditableGraph() {
        for (String preset : List.of("passthrough", "sum", "pid", "altitude")) {
            Graph graph = GraphCodec.preset(preset);
            String json = GraphCodec.toJson(graph);
            assertEquals(graph, GraphCodec.fromJson(json));
            assertEquals(json, GraphCodec.toJson(GraphCodec.fromJson(json)));
            Signal value = new ControlEngine(graph).step(Map.of("a", Signal.valid(1), "b", Signal.valid(.5),
                    "c", Signal.valid(.1), "d", Signal.valid(0)), .05);
            assertTrue(value.valid(), preset + ": " + value.status());
        }
    }

    @Test void absentOptionalNodeFieldsUseEngineDefaults() {
        Graph graph = GraphCodec.fromJson("{\"nodes\":[{\"id\":\"in\",\"op\":\"input\"}],\"output\":\"in\"}");
        assertEquals(.537, new ControlEngine(graph).step(Map.of("a", Signal.valid(.537)), .05).value());
    }

    @Test void arbitraryFeedbackGraphRoundTrips() {
        Graph graph = new Graph(List.of(new Node("sum", Op.ADD, List.of("in", "memory"), Map.of()),
                new Node("memory", Op.DELAY, List.of("sum"), Map.of("initial", 1.25)),
                new Node("in", Op.INPUT, List.of(), Map.of("port", 3.0))), "sum");
        ControlEngine engine = new ControlEngine(GraphCodec.fromJson(GraphCodec.toJson(graph)));
        assertEquals(1.5, engine.step(Map.of("d", Signal.valid(.25)), .05).value());
        assertEquals(1.75, engine.step(Map.of("d", Signal.valid(.25)), .05).value());
    }

    @Test void malformedAmbiguousAndNonfiniteJsonIsRejected() {
        for (String json : List.of(
                "{}", "[]", "null", "", "{", "/* comment */{}",
                "{\"nodes\":[],\"output\":\"a\",\"output\":\"b\"}",
                "{\"nodes\":[],\"output\":\"a\",\"unexpected\":1}",
                "{\"nodes\":[],\"output\":123}",
                "{\"nodes\":[{\"id\":\"a\",\"op\":\"CONSTANT\",\"parameters\":{\"value\":\"1\"}}],\"output\":\"a\"}",
                "{\"nodes\":[{\"id\":\"a\",\"op\":\"CONSTANT\",\"parameters\":{\"value\":1e999}}],\"output\":\"a\"}",
                "{\"nodes\":[{\"id\":\"a\",\"op\":\"CONSTANT\",\"parameters\":{\"value\":1,\"value\":2}}],\"output\":\"a\"}",
                "{\"nodes\":[{\"id\":\"a\",\"op\":\"SCRIPT\"}],\"output\":\"a\"}",
                "{\"nodes\":[{\"id\":\"a\",\"op\":\"INPUT\",\"extra\":true}],\"output\":\"a\"}",
                GraphCodec.toJson(GraphCodec.preset("passthrough")) + " {}"
        )) assertThrows(IllegalArgumentException.class, () -> GraphCodec.fromJson(json), json);
        assertThrows(IllegalArgumentException.class, () -> GraphCodec.fromJson(" ".repeat(GraphCodec.MAX_JSON_LENGTH + 1)));
        assertThrows(IllegalArgumentException.class, () -> GraphCodec.fromJson(null));
        assertThrows(IllegalArgumentException.class, () -> GraphCodec.preset("unknown"));
    }
}
