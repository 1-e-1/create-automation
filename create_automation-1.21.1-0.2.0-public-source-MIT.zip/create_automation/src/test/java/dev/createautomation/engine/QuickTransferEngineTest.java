package dev.createautomation.engine;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class QuickTransferEngineTest {
    private static QuickSettings.Root real(double value) { return new QuickSettings.Root(value, 0); }
    private static QuickSettings settings(QuickSettings.Mode mode, double gain, List<QuickSettings.Root> zeros, List<QuickSettings.Root> poles) {
        return new QuickSettings(mode, gain, zeros, poles);
    }
    private static double step(QuickTransferEngine engine, double a, double b) {
        Signal signal = engine.step(Map.of("a", Signal.valid(a), "b", Signal.valid(b)), .05);
        assertTrue(signal.valid(), signal.status());
        return signal.value();
    }
    @Test void staticGainAndMeasurementSemanticsAreDifferentInAllThreeModes() {
        assertEquals(6, step(new QuickTransferEngine(settings(QuickSettings.Mode.FILTER, 2, List.of(), List.of())), 3, 99));
        assertEquals(4, step(new QuickTransferEngine(settings(QuickSettings.Mode.CONTROLLER, 2, List.of(), List.of())), 3, 1));
        assertEquals(2, step(new QuickTransferEngine(settings(QuickSettings.Mode.CLOSED_LOOP, 2, List.of(), List.of())), 3, 99));
    }
    @Test void tustinFirstOrderMatchesKnownCoefficientsAndDcGain() {
        var config = settings(QuickSettings.Mode.FILTER, 1, List.of(), List.of(real(-1)));
        var coefficients = QuickTransferMath.discrete(config, .05);
        assertArrayEquals(new double[]{1.0/41, 1.0/41}, coefficients.numerator(), 1e-14);
        assertArrayEquals(new double[]{1, -39.0/41}, coefficients.denominator(), 1e-14);
        var engine = new QuickTransferEngine(config);
        assertEquals(1.0/41, step(engine, 1, 0), 1e-14);
        double y = 0;
        for (int i = 0; i < 1000; i++) y = step(engine, 1, 0);
        assertEquals(1, y, 1e-12);
    }
    @Test void zpkGainIsNotDcGainAndConjugatePairsProduceRealPolynomials() {
        var config = settings(QuickSettings.Mode.FILTER, 5, List.of(), List.of(new QuickSettings.Root(-1, 2)));
        assertArrayEquals(new double[]{1, 2, 5}, QuickTransferMath.analog(config).denominator());
        var engine = new QuickTransferEngine(config);
        double output = 0;
        for (int i = 0; i < 1000; i++) output = step(engine, 1, 0);
        assertEquals(1, output, 1e-12);
        var zeroConfig = settings(QuickSettings.Mode.FILTER, 2, List.of(real(-2)), List.of(real(-4)));
        engine = new QuickTransferEngine(zeroConfig);
        assertEquals(2.0 * 42 / 44, step(engine, 1, 0), 1e-12);
        for (int i = 0; i < 300; i++) output = step(engine, 1, 0);
        assertEquals(1, output, 1e-12);
    }
    @Test void theoreticalUnitFeedbackUsesLOverOnePlusL() {
        var config = settings(QuickSettings.Mode.CLOSED_LOOP, 1, List.of(), List.of(real(-1)));
        var coefficients = QuickTransferMath.analog(config);
        assertArrayEquals(new double[]{1}, coefficients.numerator());
        assertArrayEquals(new double[]{1, 2}, coefficients.denominator());
        var engine = new QuickTransferEngine(config);
        assertEquals(1.0/42, step(engine, 1, 1000), 1e-12);
        double output = 0;
        for (int i = 0; i < 1000; i++) output = step(engine, 1, -1000);
        assertEquals(.5, output, 1e-12);
    }
    @Test void unstableOpenLoopCanBecomeStableUnderTheoreticalFeedback() {
        var open = settings(QuickSettings.Mode.FILTER, 2, List.of(), List.of(real(1)));
        var closed = settings(QuickSettings.Mode.CLOSED_LOOP, 2, List.of(), List.of(real(1)));
        assertFalse(QuickTransferMath.strictlyStable(open));
        assertTrue(QuickTransferMath.strictlyStable(closed));
        var engine = new QuickTransferEngine(closed);
        double output = 0;
        for (int i = 0; i < 1000; i++) output = step(engine, 1, 0);
        assertEquals(2, output, 1e-10);
    }
    @Test void integratorUsesTrapezoidalTustinAndResetsAfterFaults() {
        var engine = new QuickTransferEngine(settings(QuickSettings.Mode.CONTROLLER, 1, List.of(), List.of(real(0))));
        assertEquals(.025, step(engine, 2, 1), 1e-14);
        assertEquals(.075, step(engine, 2, 1), 1e-14);
        assertFalse(engine.step(Map.of("a", Signal.valid(2)), .05).valid());
        assertEquals(.025, step(engine, 2, 1), 1e-14);
        assertEquals("quick_A: unused(NULL)", engine.step(Map.of("a", Signal.invalid("unused(NULL)")), .05).status());
        assertEquals(.025, step(engine, 2, 1), 1e-14);
        assertEquals("quick_B: unused(NULL)", engine.step(Map.of("a", Signal.valid(2), "b", Signal.invalid("unused(NULL)")), .05).status());
        assertEquals(.025, step(engine, 2, 1), 1e-14);
        engine.reset();
        assertEquals(.025, step(engine, 2, 1), 1e-14);
        assertFalse(engine.step(Map.of("a", Signal.valid(2), "b", Signal.valid(1)), .1).valid());
        assertEquals(.025, step(engine, 2, 1), 1e-14);
    }
    @Test void unusedMeasurementDoesNotInvalidateFilterOrTheoreticalMode() {
        for (var mode : List.of(QuickSettings.Mode.FILTER, QuickSettings.Mode.CLOSED_LOOP)) {
            var engine = new QuickTransferEngine(settings(mode, 1, List.of(), List.of(real(-1))));
            assertTrue(engine.step(Map.of("a", Signal.valid(1)), .05).valid());
            assertFalse(engine.step(Map.of(), .05).valid());
        }
    }
    @Test void highOrderSlowStablePolesStayAccurateWithLowOrderSections() {
        List<QuickSettings.Root> poles = new ArrayList<>();
        for (int i = 0; i < 6; i++) poles.add(real(-.01));
        var engine = new QuickTransferEngine(settings(QuickSettings.Mode.FILTER, 1e-12, List.of(), poles));
        double output = 0;
        for (int i = 0; i < 100_000; i++) output = step(engine, 1, 0);
        assertEquals(1, output, 1e-6);
    }
    @Test void cascadeAndExpandedDifferenceEquationAgreeForGeneralStableTransfer() {
        for (var mode : List.of(QuickSettings.Mode.FILTER, QuickSettings.Mode.CLOSED_LOOP)) {
            var config = settings(mode, 3.75, List.of(real(-2), new QuickSettings.Root(-3, 2)),
                    List.of(real(-1), new QuickSettings.Root(-4, 3), real(-5)));
            var engine = new QuickTransferEngine(config);
            var digital = QuickTransferMath.discrete(config, .05);
            double[] a = digital.denominator(), b = digital.numerator(), u = new double[a.length], y = new double[a.length];
            for (int i = 0; i < 500; i++) {
                System.arraycopy(u, 0, u, 1, u.length - 1);
                System.arraycopy(y, 0, y, 1, y.length - 1);
                u[0] = Math.sin(i * .03) + .2 * Math.cos(i * .1);
                double expected = b[0] * u[0];
                for (int j = 1; j < a.length; j++) expected += b[j] * u[j] - a[j] * y[j];
                y[0] = expected;
                assertEquals(expected, step(engine, u[0], 0), 1e-9);
            }
        }
    }
    @Test void rejectsImproperNonfiniteOversizedOrSingularDefinitions() {
        assertThrows(IllegalArgumentException.class, () -> settings(QuickSettings.Mode.FILTER, 1, List.of(real(1)), List.of()));
        assertThrows(IllegalArgumentException.class, () -> new QuickSettings.Root(Double.NaN, 0));
        assertThrows(IllegalArgumentException.class, () -> new QuickSettings.Root(1, -2));
        assertThrows(IllegalArgumentException.class, () -> settings(QuickSettings.Mode.FILTER, Double.POSITIVE_INFINITY, List.of(), List.of()));
        assertThrows(IllegalArgumentException.class, () -> settings(QuickSettings.Mode.FILTER, 1, List.of(), java.util.Collections.nCopies(7, real(-1))));
        assertThrows(IllegalArgumentException.class, () -> new QuickTransferEngine(settings(QuickSettings.Mode.FILTER, 1, List.of(), List.of(real(40)))));
        assertThrows(IllegalArgumentException.class, () -> new QuickTransferEngine(settings(QuickSettings.Mode.CLOSED_LOOP, -1, List.of(), List.of())));
        assertThrows(IllegalArgumentException.class, () -> new QuickTransferEngine(settings(QuickSettings.Mode.CLOSED_LOOP, -1, List.of(real(0)), List.of(real(-1)))));
    }
    @Test void numericalOverflowStopsOutputAndClearsState() {
        var engine = new QuickTransferEngine(settings(QuickSettings.Mode.FILTER, 1e12, List.of(), List.of()));
        Signal bad = engine.step(Map.of("a", Signal.valid(Double.MAX_VALUE)), .05);
        assertFalse(bad.valid()); assertEquals(0, bad.value());
        assertEquals(1e12, step(engine, 1, 0));
    }
    @Test void strictJsonRoundTripsAndRejectsAmbiguousFields() {
        var config = settings(QuickSettings.Mode.CONTROLLER, 2, List.of(real(-2)), List.of(new QuickSettings.Root(-1, 3)));
        assertEquals(config, QuickSettingsCodec.fromJson(QuickSettingsCodec.toJson(config)));
        for (String json : List.of("{}", "null", "{\"mode\":\"FILTER\",\"gain\":1,\"gain\":2,\"zeros\":[],\"poles\":[]}",
                "{\"mode\":\"FILTER\",\"gain\":\"1\",\"zeros\":[],\"poles\":[]}",
                "{\"mode\":\"FILTER\",\"gain\":1e999,\"zeros\":[],\"poles\":[]}",
                QuickSettingsCodec.toJson(config) + "{}"))
            assertThrows(IllegalArgumentException.class, () -> QuickSettingsCodec.fromJson(json));
    }
    @Test void displayedFormulaShowsGainFactorsAndEffectiveClosedLoop() {
        var config = settings(QuickSettings.Mode.CLOSED_LOOP, 2, List.of(real(-3)), List.of(real(-4)));
        assertTrue(QuickTransferMath.factorFormula(config).startsWith("L(s)"));
        assertTrue(QuickTransferMath.expandedFormula(config).contains("L(s)/(1+L(s))"));
        assertArrayEquals(new double[]{3, 10}, QuickTransferMath.analog(config).denominator());
    }
}
