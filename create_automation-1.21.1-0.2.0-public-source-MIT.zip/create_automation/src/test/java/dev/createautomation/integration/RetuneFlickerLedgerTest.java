package dev.createautomation.integration;

import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class RetuneFlickerLedgerTest {
    @Test void repeatedLegitimateRetunesDoNotAccumulateSyntheticFlicker() {
        Object shaft = new Object();
        int ordinary = 5, corrected = 5;
        float before = 64;
        boolean ordinaryWouldBreak = false;
        for (int tick = 0; tick < 500; tick++) {
            float after = tick % 2 == 0 ? 64.125f : 64.25f;
            ordinary = Math.max(0, ordinary - 1) + 10;
            ordinaryWouldBreak |= ordinary > 128;
            corrected = Math.max(0, corrected - 1);
            RetuneFlickerLedger<Object> ledger = new RetuneFlickerLedger<>(Map.of(shaft, before), before, after);
            corrected = ledger.adjust(shaft, before, 0, true, false, corrected, corrected + 5);
            corrected = ledger.adjust(shaft, 0, after, false, true, corrected, corrected + 5);
            ledger.finish((node, penalty) -> fail("A fully paired retune must not owe any penalty"));
            assertTrue(corrected <= 5);
            before = after;
        }
        assertTrue(ordinaryWouldBreak, "The exact +5/+5/-1 Create convention crosses its 128 threshold");
        assertEquals(0, corrected);
    }

    @Test void existingDangerousFlickerHistoryIsNeverCleared() {
        Object shaft = new Object();
        RetuneFlickerLedger<Object> ledger = new RetuneFlickerLedger<>(Map.of(shaft, 64f), 64, 80);
        int score = ledger.adjust(shaft, 64, 0, true, false, 129, 134);
        score = ledger.adjust(shaft, 0, 80, false, true, score, score + 5);
        assertEquals(129, score, "RotationPropagator's existing threshold remains effective");
    }

    @Test void reversalsStartsStopsAndNonfiniteCommandsCannotOpenTheScope() {
        for (float[] change : new float[][]{{0, 64}, {64, 0}, {64, -64}, {-64, 64},
                {64, 64}, {Float.NaN, 64}, {64, Float.POSITIVE_INFINITY}}) {
            assertFalse(RetuneFlickerLedger.isContinuousRetune(change[0], change[1]));
            assertThrows(IllegalArgumentException.class, () -> new RetuneFlickerLedger<>(Map.of(), change[0], change[1]));
        }
        assertTrue(RetuneFlickerLedger.isContinuousRetune(-64, -80));
    }

    @Test void unexpectedDirectionRatioOrNetworkRestoresBothOriginalPenalties() {
        Object shaft = new Object();
        for (float actual : new float[]{-80, 79, 0, Float.NaN}) {
            RetuneFlickerLedger<Object> ledger = new RetuneFlickerLedger<>(Map.of(shaft, 64f), 64, 80);
            int stopped = ledger.adjust(shaft, 64, 0, true, false, 20, 25);
            assertEquals(20, stopped);
            assertEquals(30, ledger.adjust(shaft, 0, actual, false, true, stopped, stopped + 5));
        }
        RetuneFlickerLedger<Object> changedNetwork = new RetuneFlickerLedger<>(Map.of(shaft, 64f), 64, 80);
        changedNetwork.adjust(shaft, 64, 0, true, false, 20, 25);
        assertEquals(30, changedNetwork.adjust(shaft, 0, 80, false, false, 20, 25));
    }

    @Test void exceptionsAndIncompleteReattachmentRestoreTheDeferredRealStopExactlyOnce() {
        Object shaft = new Object();
        RetuneFlickerLedger<Object> ledger = new RetuneFlickerLedger<>(Map.of(shaft, 64f), 64, 80);
        AtomicInteger score = new AtomicInteger(40);
        score.set(ledger.adjust(shaft, 64, 0, true, false, score.get(), score.get() + 5));
        ledger.finish((node, penalty) -> score.addAndGet(penalty));
        ledger.finish((node, penalty) -> score.addAndGet(penalty));
        assertEquals(45, score.get());
    }

    @Test void overstressAndUnrelatedShaftsRetainTheOriginalAccounting() {
        Object shaft = new Object(), unrelated = new Object();
        RetuneFlickerLedger<Object> ledger = new RetuneFlickerLedger<>(Map.of(shaft, 64f), 64, 80);
        assertEquals(25, ledger.adjust(unrelated, 64, 0, true, false, 20, 25));
        // An overstressed kinetic body keeps its theoretical rotation/network; it is not detached.
        assertEquals(25, ledger.adjust(shaft, 64, 0, false, false, 20, 25));
        assertEquals(30, ledger.adjust(shaft, 0, 80, false, true, 25, 30));
    }

    @Test void gearedNegativeShaftsArePairedAndAdditionalThrashingIsStillCounted() {
        Object gear = new Object();
        RetuneFlickerLedger<Object> ledger = new RetuneFlickerLedger<>(Map.of(gear, -32f), 64, 80);
        assertEquals(10, ledger.adjust(gear, -32, 0, true, false, 10, 15));
        assertEquals(10, ledger.adjust(gear, 0, -40, false, true, 10, 15));
        assertEquals(15, ledger.adjust(gear, -40, 0, true, false, 10, 15));
    }

    @Test void anotherModChangingTheCounterConventionDisablesTheExemption() {
        Object shaft = new Object();
        RetuneFlickerLedger<Object> ledger = new RetuneFlickerLedger<>(Map.of(shaft, 64f), 64, 80);
        assertEquals(27, ledger.adjust(shaft, 64, 0, true, false, 20, 27));
        assertEquals(32, ledger.adjust(shaft, 0, 80, false, true, 27, 32));
    }
}
