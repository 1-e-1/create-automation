# MIT public source release — 2026-10-23

The project owner selected the MIT license for the original addon code and original assets. The public source archive contains a root LICENSE, the same license as a game resource, and `license="MIT"` in the NeoForge metadata. The separate Gradle Wrapper retains its upstream Apache 2.0 license.

The public source is independently buildable against an explicitly configured installation of the verified Windows Minecraft/NeoForge runtime. The build and dependency staging scripts no longer contain personal paths or an instance-name fallback. The required variables and exact dependencies are documented in [BUILDING.md](../BUILDING.md). Historical report paths have been replaced with `<PROJECT_ROOT>`, `<MINECRAFT_ROOT>` and `<JAVA_HOME>`; test outcomes and artifact hashes remain intact.

## Artifact identity

| Artifact | SHA-256 |
|---|---|
| Previously game-tested v0.2.0 baseline | `7a1de319982a768f5321eaca85dbd563455a1e8be8078e2b668b1a98fb450100` |
| MIT public build | `5a45e1be32939169c714deff1fe5b86924c62ff41a36ad82d6b77045119eb3f8` |

The public source was compiled with Java 21 against the exact installed dependencies. An entry-by-entry comparison found all 74 `.class` files, the manifest and all gameplay assets identical to the baseline. The only changed entry is `META-INF/neoforge.mods.toml` (MIT license field); the only added entry is `LICENSE`. No entries were removed. The report is [public-build-equivalence.json](evidence/public-build-equivalence.json).

The baseline passed 17 real Minecraft GameTests and 143 actual client checks. Those game/UI checks were not rerun merely for the license-only artifact changes. The public build scripts were executed successfully, and 49 JUnit tests plus 37 independent SciPy reference cases were rerun successfully. Configuration failure messages, the explicitly selected mods directory, the adjacent-mods default and the PATH JDK fallback were also exercised. Gradle and non-Windows game launching remain outside this validation record.

Use the public JAR for the downloadable release and the extracted public source tree for the repository. Keep only one version of this addon in a game instance's mods directory.
