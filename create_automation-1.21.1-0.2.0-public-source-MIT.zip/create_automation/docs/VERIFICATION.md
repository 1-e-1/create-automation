> 本页的 Minecraft 和 GUI 测试记录对应原 v0.2.0 游戏代码基线。2026-10-23 的 MIT 公开包重新编译后，74 个 Java 类和全部游戏资源与该基线一致，仅许可元数据与 LICENSE 不同；公开包的新哈希及对照结果见 [PUBLIC_RELEASE.md](PUBLIC_RELEASE.md)。公开构建脚本另已重新通过 49 项 JUnit 和 37 组 SciPy 对照。

# v0.2.0 验证记录

日期：2026-10-22。环境：Minecraft 1.21.1 / NeoForge 21.1.248 / Create 6.0.10 / Create Aeronautics 1.3.2 / Sable 2.0.6 / Java 21。

## 控制算法

**49 项 JUnit 全部通过，0 跳过、0 失败。** 保留原控制图、PID、延迟、快照时序与连续调速保护测试，增加零极点展开、共轭根、Tustin、严格配置校验、理论闭环、缺失输入复位及六阶慢极点长期数值稳定性测试。

独立 **SciPy 对照 37/37 通过**：固定 seed 20261022，覆盖 0～6 阶、实根、复共轭根、直接通道，以及三个开环不稳定但闭环稳定的例子。分别使用 640 点阶跃和 1024 点混合输入。比较方法为 SciPy zpk2tf → N/(D+N) → bilinear(fs=20) → lfilter，与独立编译的 Java 系数和逐点输出比较，严格核对数组长度。

系数最大绝对误差 1.78e-15，响应最大绝对误差 9.51e-14。这组有限时间、适中根值的参考测试不等于对任意用户传递函数的稳定性保证。SciPy 1.17 对全零分子的例外处理及原始响应、软件版本、源代码 SHA256 均记录在报告中。

证据：[JUnit](evidence/unit-tests.log)、[SciPy](evidence/scipy-reference.json)。本机完整原始数据位于 `build/reference-check/1792680549114550100`。

## 真实游戏集成

**17 项 GameTests 全部通过，服务端退出码 0。** 使用 Create + Aeronautics + Sable 的完整核心组合。

- 保留原 11 项：小数 RPM 的真实轴网传递、自定义控制图、红石接口、冲突与失联停止、Sable 装配运动、正负朝向、NBT 恢复、连续调速保护，以及运行 520 tick 的实际转速 PI 闭环。
- 三种新检测器：真实装配刚体，比较不同安装点的刚体参考高度，验证相对高度归零/NBT、世界 XYZ 平移速度、速率与三个姿态角模式；未装配时明确无效。
- NULL：不订阅、未使用端口不影响图输出、实际引用的断开端口报错、下游停止、保留旧通道、保留字拒绝。
- 快速配置器：L(s)=2/(s+1)、A=3 的模型输出趋于 2，并进入真实 Create 轴网；断线停转、恢复后从零状态重启；零极点 NBT 与非法配置原子拒绝。

证据：[GameTests](evidence/game-tests.json)，完整日志 `run/local-gametest/console-1792682087.log`。

## 实际客户端与视觉检查

同一 JAR 的 **143 项客户端操作检查全部通过**。覆盖 13 种方块、三种新检测器模式保存、零极点增删、参数和通道保存、非法值拒绝、NULL 显示、实时响应及原系统构建器。检查 427×240 与 854×480 两种逻辑界面尺寸。

五个原生 Ponder 场景实际播放，结构非空且中文文本正常显示。十三种物品的原生 Ponder 注册与 Shift 介绍均检查，另保留原生 tooltip 的 W 提示和 Shift 介绍截图。Ponder 由测试程序调用原生入口打开，未将其宣称为实体键盘长按 W 测试。

已修复新配置器自绘文字和曲线被 Minecraft 背景模糊影响的问题。root 与 builder_ui 均审阅最终原始截图，检查公式、控件、曲线、提示与 Ponder 文本。

证据：[客户端操作](evidence/ui-smoke-report.json)、[启动记录及 JAR 哈希](evidence/client-launch.json)、[截图目录](screenshots/)。完整客户端日志 `run/local-client/console-1792682221.log`。

## 构建与验证边界

最终 JAR：`create_automation-1.21.1-0.2.0.jar`，247953 bytes。

```text
SHA256 7a1de319982a768f5321eaca85dbd563455a1e8be8078e2b668b1a98fb450100
```

所有游戏测试使用项目 `run/` 内的隔离世界，未修改用户的原存档。兼容验证针对上述精确核心模组组合；未验证整合包内每个无关模组，也未声称具体飞机已经完成定高或姿态控制整定。快速配置器运行用户输入模型的理论单位负反馈响应；真实测量闭环使用系统构建器。

发行包使用 `scripts/build_local.py` 对实际安装的精确 Mojang 命名 API 编译，并运行真实 Minecraft 验证。保留 Gradle 工程；本机曾遇 NeoForge Maven 下载超时，未以 Gradle 构建成功作为交付证据。

```powershell
python scripts/generate_ponder.py
python scripts/generate_resources.py
python scripts/test_engine_local.py
python scripts/verify_transfer_scipy.py
python scripts/build_local.py
python scripts/run_local_gametest.py --with-aeronautics
python scripts/run_local_client.py --world-source run/local-gametest/gametest-world --with-aeronautics --smoke --launch
```

复制测试世界前等待测试服务端退出。GUI 自动化仅在显式 `--smoke` 且目录为项目 `run/local-client` 时开启。
