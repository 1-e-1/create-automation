"""Stage installed dependencies for dev only, retaining their upstream licenses."""
import hashlib
import json
import shutil
import zipfile
from pathlib import Path
from local_config import mods_directory

ROOT = Path(__file__).resolve().parents[1]
LIBS = ROOT / 'libs'


def main():
    mods = mods_directory()
    files = ['create-1.21.1-6.0.10.jar', 'sable-neoforge-1.21.1-2.0.6.jar']
    missing = [name for name in files if not (mods / name).is_file()]
    if missing:
        raise SystemExit('Required installed mod JARs missing from CREATE_AUTOMATION_MODS: ' + ', '.join(missing))
    LIBS.mkdir(exist_ok=True)
    manifest = []
    for name in files:
        source = mods / name
        shutil.copyfile(source, LIBS / name)
        manifest.append({'file': name, 'source': str(source), 'sha256': hashlib.sha256(source.read_bytes()).hexdigest()})
        if name.startswith('create-'):
            with zipfile.ZipFile(source) as archive:
                for entry in archive.namelist():
                    if entry.startswith('META-INF/jarjar/') and entry.endswith('.jar'):
                        target = LIBS / Path(entry).name
                        target.write_bytes(archive.read(entry))
                        print('Create dependency:', target.name)
    (LIBS / 'DEPENDENCIES.json').write_text(json.dumps(manifest, indent=2, ensure_ascii=False), encoding='utf-8')
    print('Staged', len(list(LIBS.glob('*.jar'))), 'JARs for compilation and local testing only.')


if __name__ == '__main__':
    main()
