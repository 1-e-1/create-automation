"""Independently compare the 20 Hz Java transfer engine with SciPy.

Run with ``python scripts/verify_transfer_scipy.py``. Only pure Java engine
sources and Gson are compiled. Minecraft is neither loaded nor launched.
Reference: https://docs.scipy.org/doc/scipy/reference/generated/scipy.signal.bilinear_zpk.html
The Tustin substitution is s=2*fs*(z-1)/(z+1), without frequency prewarping.
"""
import hashlib
import json
import os
import platform
import subprocess
import sys
import time
import warnings
from pathlib import Path

import numpy as np
import scipy
from scipy import signal

from build_local import ROOT, JDK, libraries
from local_config import java_tool


SEED = 20261022
FS = 20.0
# Declared before comparison; failures must be investigated, not made to pass by widening.
COEFFICIENT_ATOL = COEFFICIENT_RTOL = 2e-12
RESPONSE_ATOL = RESPONSE_RTOL = 5e-10

RUNNER = r'''
import com.google.gson.*;
import dev.createautomation.engine.*;
import java.nio.file.*;
import java.util.*;

public final class TransferReferenceRunner {
    public static void main(String[] args) throws Exception {
        JsonArray inputs = JsonParser.parseString(Files.readString(Path.of(args[0]))).getAsJsonArray();
        JsonArray results = new JsonArray();
        Gson gson = new Gson();
        for (JsonElement element : inputs) {
            JsonObject request = element.getAsJsonObject(), result = new JsonObject();
            result.addProperty("name", request.get("name").getAsString());
            try {
                QuickSettings settings = QuickSettingsCodec.fromJson(request.get("settings").toString());
                var analog = QuickTransferMath.analog(settings);
                var discrete = QuickTransferMath.discrete(settings, QuickTransferEngine.DT);
                result.add("analog_b", gson.toJsonTree(analog.numerator()));
                result.add("analog_a", gson.toJsonTree(analog.denominator()));
                result.add("b", gson.toJsonTree(discrete.numerator()));
                result.add("a", gson.toJsonTree(discrete.denominator()));
                result.addProperty("strictly_stable", QuickTransferMath.strictlyStable(settings));
                JsonObject responses = new JsonObject();
                for (var input : request.getAsJsonObject("signals").entrySet()) {
                    QuickTransferEngine engine = new QuickTransferEngine(settings);
                    JsonArray output = new JsonArray();
                    for (var sample : input.getValue().getAsJsonArray()) {
                        // No measurement B: CLOSED_LOOP is the theoretical unity-feedback response.
                        Signal value = engine.step(Map.of("a", Signal.valid(sample.getAsDouble())), .05);
                        if (!value.valid()) throw new IllegalStateException(value.status());
                        output.add(value.value());
                    }
                    responses.add(input.getKey(), output);
                }
                result.add("responses", responses);
            } catch (RuntimeException failure) {
                result.addProperty("error", failure.toString());
            }
            results.add(result);
        }
        Files.writeString(Path.of(args[1]), new GsonBuilder().setPrettyPrinting().create().toJson(results));
    }
}
'''


def root(real, imaginary=0.0):
    return {"real": float(real), "imaginary": float(imaginary)}


def expanded_roots(roots):
    values = []
    for item in roots:
        real, imaginary = item["real"], item["imaginary"]
        values.append(complex(real, imaginary))
        if imaginary:
            values.append(complex(real, -imaginary))
    return values


def analog_reference(settings):
    numerator, denominator = signal.zpk2tf(expanded_roots(settings["zeros"]),
                                         expanded_roots(settings["poles"]), settings["gain"])
    numerator = np.atleast_1d(np.real_if_close(numerator)).astype(float)
    denominator = np.atleast_1d(np.real_if_close(denominator)).astype(float)
    # Unity negative feedback is N/(D+N), with descending s-power coefficient arrays.
    return numerator, np.polyadd(denominator, numerator)


def make_cases():
    rng = np.random.default_rng(SEED)
    cases = []

    def add(name, gain, zeros, poles, family):
        cases.append({"name": name, "family": family, "settings": {
            "mode": "CLOSED_LOOP", "gain": float(gain), "zeros": zeros, "poles": poles}})

    for gain in [0.0, .125, 2.0, -.25, -2.0]:
        add(f"static_{gain:g}", gain, [], [], "static")
    add("first_order", 1, [], [root(-1)], "analytic")
    add("integrator", 2, [], [root(0)], "analytic")
    add("complex_second_order", 5, [], [root(-1, 2)], "complex")
    add("biproper_real_zero", 2, [root(-4)], [root(-2)], "biproper")
    add("complex_zeros", .5, [root(-3, 4)], [root(-2, 6)], "complex_biproper")
    add("unstable_real_stabilized", 2, [], [root(1)], "unstable_open_stable_closed")
    add("unstable_second_order_stabilized", 10, [], [root(1), root(-3)], "unstable_open_stable_closed")
    add("unstable_complex_stabilized", 4, [root(-2)], [root(1, 2)], "unstable_open_stable_closed")

    def roots_of_order(order):
        roots = []
        while order:
            real = -float(rng.uniform(3, 16))
            if order >= 2 and rng.random() < .6:
                roots.append(root(real, rng.uniform(1, 14)))
                order -= 2
            else:
                roots.append(root(real))
                order -= 1
        return roots

    rejected = 0
    # Stable response population selected only by continuous closed-loop poles,
    # before any Java results are available. Roots stay moderate so lfilter's
    # expanded polynomial is itself an accurate floating-point reference.
    for order in range(1, 7):
        for variant in range(4):
            zero_order = [0, order // 2, max(0, order - 1), order][variant]
            for attempt in range(1000):
                poles, zeros = roots_of_order(order), roots_of_order(zero_order)
                gain = float(10 ** rng.uniform(-1, 1.2)) * (-1 if variant == 2 else 1)
                settings = {"gain": gain, "zeros": zeros, "poles": poles}
                _, closed_denominator = analog_reference(settings)
                if np.all(np.real(np.roots(closed_denominator)) < -.2):
                    add(f"seed_{SEED}_order{order}_variant{variant}", gain, zeros, poles, "seeded")
                    break
                rejected += 1
            else:
                raise AssertionError("Failed to generate stable deterministic case")

    for case in cases:
        t = np.arange(1024) / FS
        mixed = (.7 * np.sin(1.3 * t) + .2 * np.cos(4.7 * t)
                 + np.where((np.arange(t.size) // 91) % 2 == 0, .35, -.2)
                 + .025 * rng.standard_normal(t.size))
        case["signals"] = {"step": np.ones(640).tolist(), "mixed": mixed.tolist()}
    return cases, rejected


def compare(actual, expected, atol, rtol):
    actual, expected = np.asarray(actual, dtype=float), np.asarray(expected, dtype=float)
    shape_matches = actual.shape == expected.shape
    # Padding is only for useful error diagnostics after a shape mismatch. A
    # truncated all-zero sequence must never silently pass the comparison.
    count = max(actual.size, expected.size)
    actual = np.pad(actual, (0, count - actual.size))
    expected = np.pad(expected, (0, count - expected.size))
    error = np.abs(actual - expected)
    allowance = atol + rtol * np.abs(expected)
    finite = bool(np.all(np.isfinite(actual)) and np.all(np.isfinite(expected)))
    return {"passed": shape_matches and finite and bool(np.all(error <= allowance)),
            "shape_matches": shape_matches,
            "max_absolute_error": float(np.max(error, initial=0)),
            "max_fraction_of_tolerance": float(np.max(error / allowance, initial=0)),
            "worst_index": int(np.argmax(error)) if count else None}


def run_command(args, build, log_name):
    process = subprocess.run(args, cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    output = process.stdout.decode("utf-8", errors="replace")
    (build / log_name).write_text(output, encoding="utf-8")
    if process.returncode:
        print(output, flush=True)
        raise RuntimeError(f"Command failed: {args[0]} ({process.returncode})")
    return output.strip()


def main():
    build = ROOT / "build/reference-check" / str(time.time_ns())
    classes = build / "classes"
    classes.mkdir(parents=True)
    cases, rejected = make_cases()
    (build / "inputs.json").write_text(json.dumps(cases, indent=2), encoding="utf-8")
    runner = build / "TransferReferenceRunner.java"
    runner.write_text(RUNNER, encoding="utf-8")
    gson = next(path for path in libraries() if path.name.startswith("gson-"))
    source_dir = ROOT / "src/main/java/dev/createautomation/engine"
    sources = sorted(source_dir.glob("Quick*.java")) + [source_dir / "Signal.java"]
    args = ["-encoding", "UTF-8", "--release", "21", "-proc:none", "-d", str(classes),
            "-classpath", str(gson)] + [str(path) for path in sources] + [str(runner)]
    argfile = build / "javac.args"
    argfile.write_text("\n".join('"' + arg.replace('\\', '/') + '"' for arg in args), encoding="utf-8")
    run_command([str(java_tool("javac", JDK)), "-J-Duser.language=en", "@" + str(argfile)], build, "compile.log")
    java_version = run_command([str(java_tool("java", JDK)), "-version"], build, "java-version.log")
    run_command([str(java_tool("java", JDK)), "-Duser.language=en", "-classpath",
                 os.pathsep.join(map(str, [classes, gson])), "TransferReferenceRunner",
                 str(build / "inputs.json"), str(build / "java-results.json")], build, "java.log")
    java_results = json.loads((build / "java-results.json").read_text(encoding="utf-8"))
    assert [case["name"] for case in cases] == [result["name"] for result in java_results]

    checks, raw_reference = [], []
    for case, actual in zip(cases, java_results):
        numerator, denominator = analog_reference(case["settings"])
        with warnings.catch_warnings():
            # A zero static gain legitimately yields [0]; this warning only
            # concerns numerator normalization and does not alter the reference.
            warnings.filterwarnings("ignore", category=signal.BadCoefficients)
            if np.any(numerator):
                b, a = signal.bilinear(numerator, denominator, fs=FS)
            else:
                # SciPy 1.17 bilinear trims all-zero b to an empty array, then
                # accesses .coef on sum([])==0. Transform a unit numerator and
                # multiply the result by the exact zero gain; keep its computed a.
                b, a = signal.bilinear([1.0], denominator, fs=FS)
                b = np.zeros_like(b)
        reference = {"name": case["name"], "analog_b": numerator.tolist(), "analog_a": denominator.tolist(),
                     "b": b.tolist(), "a": a.tolist(), "responses": {
                         name: signal.lfilter(b, a, samples).tolist() for name, samples in case["signals"].items()}}
        raw_reference.append(reference)
        closed_poles = np.roots(denominator)
        check = {"name": case["name"], "family": case["family"],
                 "pole_order": len(expanded_roots(case["settings"]["poles"])),
                 "zero_order": len(expanded_roots(case["settings"]["zeros"])),
                 "open_loop_unstable": any(p.real > 0 for p in expanded_roots(case["settings"]["poles"])),
                 "closed_loop_stable": bool(np.all(np.real(closed_poles) < 0)),
                 "maximum_discrete_pole_magnitude": float(np.max(np.abs(np.roots(a)), initial=0))}
        if "error" in actual:
            check.update(passed=False, java_error=actual["error"])
        else:
            check["coefficients"] = {name: compare(actual[name], reference[name], COEFFICIENT_ATOL, COEFFICIENT_RTOL)
                                     for name in ["b", "a"]}
            check["responses"] = {name: compare(actual["responses"][name], values, RESPONSE_ATOL, RESPONSE_RTOL)
                                  for name, values in reference["responses"].items()}
            check["passed"] = all(item["passed"] for group in ["coefficients", "responses"]
                                   for item in check[group].values())
        checks.append(check)

    report = {"passed": all(check["passed"] for check in checks), "case_count": len(cases),
              "passed_cases": sum(check["passed"] for check in checks), "seed": SEED,
              "sample_rate_hz": FS, "step_samples": 640, "mixed_samples": 1024,
              "proper_pole_orders": sorted(set(check["pole_order"] for check in checks)),
              "unstable_open_stable_closed_cases": sum(check["open_loop_unstable"] and check["closed_loop_stable"] for check in checks),
              "stable_generation_rejections": rejected,
              "versions": {"python": platform.python_version(), "numpy": np.__version__, "scipy": scipy.__version__, "java": java_version},
              "method": "SciPy zpk2tf -> N/(D+N) -> bilinear(fs=20, no prewarp) -> lfilter; Java engine separately compiled from source",
              "reference_url": "https://docs.scipy.org/doc/scipy/reference/generated/scipy.signal.bilinear_zpk.html",
              "scope": "Finite-time, moderate-root reference cases. This does not prove stability of arbitrary user systems or expanded high-order lfilter conditioning near repeated unit poles.",
              "reference_workaround": "SciPy 1.17 bilinear([0],a) raises AttributeError after trimming b to empty. The zero-gain case uses bilinear([1],a) then exactly zeroes b; no tolerance changes.",
              "tolerances": {"coefficient_atol": COEFFICIENT_ATOL, "coefficient_rtol": COEFFICIENT_RTOL,
                             "response_atol": RESPONSE_ATOL, "response_rtol": RESPONSE_RTOL},
              "source_sha256": {str(path.relative_to(ROOT)): hashlib.sha256(path.read_bytes()).hexdigest() for path in sources},
              "script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(), "cases": checks}
    for group in ["coefficients", "responses"]:
        report[f"maximum_{group}_absolute_error"] = max((item["max_absolute_error"] for check in checks
                                                         for item in check.get(group, {}).values()), default=None)
    (build / "scipy-results.json").write_text(json.dumps(raw_reference, indent=2, allow_nan=False), encoding="utf-8")
    (build / "report.json").write_text(json.dumps(report, indent=2, allow_nan=False), encoding="utf-8")
    (ROOT / "build/latest-reference-check.txt").write_text(str(build), encoding="utf-8")
    print(json.dumps({key: report[key] for key in ["passed", "passed_cases", "case_count", "proper_pole_orders",
                                                  "maximum_coefficients_absolute_error", "maximum_responses_absolute_error"]}, indent=2))
    print(f"Evidence: {build / 'report.json'}")
    return 0 if report["passed"] else 1


if __name__ == "__main__":
    sys.exit(main())
