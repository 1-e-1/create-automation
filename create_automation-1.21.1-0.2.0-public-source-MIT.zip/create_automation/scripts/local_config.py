"""Explicit configuration for the verified Windows local-runtime build helpers.

Set CREATE_AUTOMATION_MINECRAFT to the existing Minecraft data directory,
CREATE_AUTOMATION_VERSION_JSON to the installed instance's complete version JSON,
and optionally CREATE_AUTOMATION_MODS to its mods directory. JAVA_HOME may select
a JDK; otherwise javac on PATH is used. No account data or other installations
are searched, and the configured installation is used read-only.

These helpers target the verified Minecraft 1.21.1 / NeoForge 21.1.248 Windows
runtime. Gradle is the separate development build entry point.
"""
import os
import shutil
from pathlib import Path


def _fail(message):
    raise SystemExit("Local build configuration: " + message)


def require_windows():
    if os.name != "nt":
        _fail("the installed-runtime helpers are verified for Windows only. "
              "Use the Gradle development build on other platforms.")


def _configured_path(name, *, directory):
    value = os.environ.get(name, "").strip()
    if not value:
        _fail(f"set {name} before running this script; no machine-specific default is provided.")
    path = Path(value).expanduser().resolve()
    if directory and not path.is_dir():
        _fail(f"{name} must point to an existing directory: {path}")
    if not directory and not path.is_file():
        _fail(f"{name} must point to an existing file: {path}")
    return path


def minecraft_root():
    require_windows()
    path = _configured_path("CREATE_AUTOMATION_MINECRAFT", directory=True)
    if not (path / "libraries").is_dir():
        _fail("CREATE_AUTOMATION_MINECRAFT must contain the installed libraries/ directory.")
    return path


def version_json():
    require_windows()
    return _configured_path("CREATE_AUTOMATION_VERSION_JSON", directory=False)


def mods_directory():
    require_windows()
    if os.environ.get("CREATE_AUTOMATION_MODS", "").strip():
        return _configured_path("CREATE_AUTOMATION_MODS", directory=True)
    path = version_json().parent / "mods"
    if not path.is_dir():
        _fail("the selected version JSON has no adjacent mods/ directory. "
              "Set CREATE_AUTOMATION_MODS explicitly for a shared mods directory.")
    return path


def java_home():
    require_windows()
    if os.environ.get("JAVA_HOME", "").strip():
        path = _configured_path("JAVA_HOME", directory=True)
    else:
        javac = shutil.which("javac")
        if not javac:
            _fail("set JAVA_HOME to a Java 21 JDK, or place that JDK's bin directory on PATH.")
        path = Path(javac).resolve().parent.parent
    missing = [name for name in ("java", "javac") if not (path / "bin" / (name + ".exe")).is_file()]
    if missing:
        _fail("JAVA_HOME/PATH must select a complete Java 21 JDK; missing " + ", ".join(missing))
    return path


def java_tool(name, jdk=None):
    if name not in ("java", "javac"):
        raise ValueError("Only java and javac are supported")
    require_windows()
    return (java_home() if jdk is None else jdk) / "bin" / (name + ".exe")
