"""Run engine and retune-accounting tests without a Minecraft development runtime."""
import os
import shutil
import subprocess
import sys
import tempfile
import time
import urllib.request
from pathlib import Path

from build_local import ROOT, JDK, libraries
from local_config import java_tool


def run(args):
    process = subprocess.run(args, cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    output = process.stdout.decode('utf-8', errors='replace')
    sys.stdout.reconfigure(errors='replace')
    print(output, end='', flush=True)
    return process.returncode, output


def main():
    tools = ROOT / 'build/test-tools'
    tools.mkdir(parents=True, exist_ok=True)
    name = 'junit-platform-console-standalone-1.11.4.jar'
    junit = tools / name
    if not junit.is_file():
        cached = Path(tempfile.gettempdir()) / name
        if cached.is_file():
            shutil.copy2(cached, junit)
        else:
            url = 'https://repo.maven.apache.org/maven2/org/junit/platform/junit-platform-console-standalone/1.11.4/' + name
            with urllib.request.urlopen(url, timeout=60) as response:
                junit.write_bytes(response.read())
    gson = next(p for p in libraries() if p.name.startswith('gson-'))
    build = ROOT / 'build/engine-tests' / str(time.time_ns())
    classes = build / 'classes'
    classes.mkdir(parents=True)
    sources = sorted((ROOT / 'src/main/java/dev/createautomation/engine').glob('*.java'))
    sources += sorted((ROOT / 'src/test/java/dev/createautomation/engine').glob('*.java'))
    # The accounting policy is pure Java; leave the Minecraft bridge and Mixin out of this runner.
    sources.append(ROOT / 'src/main/java/dev/createautomation/integration/RetuneFlickerLedger.java')
    sources += sorted((ROOT / 'src/test/java/dev/createautomation/integration').glob('*.java'))
    args = ['-encoding', 'UTF-8', '--release', '21', '-d', str(classes),
            '-classpath', os.pathsep.join(map(str, [gson, junit]))] + [str(p) for p in sources]
    argfile = build / 'javac.args'
    argfile.write_text('\n'.join('"' + s.replace('\\', '/') + '"' for s in args), encoding='utf-8')
    code, output = run([str(java_tool('javac', JDK)), '-J-Duser.language=en', '@' + str(argfile)])
    (build / 'compile.log').write_text(output, encoding='utf-8')
    if code:
        return code
    code, output = run([str(java_tool('java', JDK)), '-Duser.language=en', '-jar', str(junit), 'execute',
                        '--class-path', os.pathsep.join(map(str, [classes, gson])),
                        '--scan-class-path', '--fail-if-no-tests', '--disable-ansi-colors', '--details-theme', 'ascii',
                        '--reports-dir', str(build / 'reports')])
    (build / 'results.log').write_text(output, encoding='utf-8')
    (ROOT / 'build/latest-engine-tests.txt').write_text(str(build), encoding='utf-8')
    return code


if __name__ == '__main__':
    sys.exit(main())
