"""Compile against the exact installed, Mojang-named 1.21.1/NeoForge runtime.

NeoForge 1.21.1 uses Mojang names in production. This local build does not remap,
download, or package upstream dependencies; Gradle remains the portable build.
"""
import hashlib
import json
import os
import subprocess
import sys
import time
import zipfile
from pathlib import Path
from project_metadata import MOD_VERSION, JAR_NAME
from local_config import minecraft_root, version_json, java_home, java_tool

ROOT = Path(__file__).resolve().parents[1]
MC = minecraft_root()
VERSION = version_json()
JDK = java_home()


def libraries():
    try:
        metadata = json.loads(VERSION.read_text(encoding='utf-8'))
    except (OSError, ValueError) as error:
        raise SystemExit(f'Cannot read CREATE_AUTOMATION_VERSION_JSON: {error}') from error
    if not isinstance(metadata, dict) or not isinstance(metadata.get('libraries'), list):
        raise SystemExit('CREATE_AUTOMATION_VERSION_JSON must be the complete installed version JSON with libraries.')
    paths = [MC/'libraries/net/neoforged/neoforge/21.1.248/neoforge-21.1.248-client.jar',
             MC/'libraries/net/neoforged/neoforge/21.1.248/neoforge-21.1.248-universal.jar',
             MC/'libraries/net/minecraft/client/1.21.1-20240808.144430/client-1.21.1-20240808.144430-srg.jar']
    paths += sorted((ROOT/'libs').glob('*.jar'))
    for library in metadata['libraries']:
        artifact = library.get('downloads', {}).get('artifact', {})
        path = artifact.get('path')
        if path:
            candidate = MC/'libraries'/path
            if candidate.is_file():
                paths.append(candidate)
    # Keep the exact JSON versions, never scan other Minecraft installations/versions.
    return list(dict.fromkeys(p.resolve() for p in paths))


def main():
    required_addons = ['create-1.21.1-6.0.10.jar', 'sable-neoforge-1.21.1-2.0.6.jar',
                       'flywheel-neoforge-1.21.1-1.0.6.jar', 'ponder-neoforge-1.0.82+mc1.21.1.jar',
                       'Registrate-MC1.21-1.3.0+67.jar']
    missing_addons = [name for name in required_addons if not (ROOT/'libs'/name).is_file()]
    if missing_addons:
        raise SystemExit('Required development dependencies are missing from libs/: ' + ', '.join(missing_addons)
                         + '. Configure the installed mods directory and run python scripts/stage_dependencies.py first.')
    build = ROOT/'build/local'/str(time.time_ns())
    classes = build/'classes'
    classes.mkdir(parents=True)
    libs = libraries()
    missing = [p for p in libs if not p.is_file()]
    if missing:
        raise RuntimeError(f'Missing local compile dependencies: {missing}')
    args = ['-encoding','UTF-8','--release','21','-proc:none','-d',str(classes),'-classpath',os.pathsep.join(map(str,libs))]
    sources = sorted((ROOT/'src/main/java').rglob('*.java'))
    args += [str(p) for p in sources]
    argfile = build/'javac.args'
    argfile.write_text('\n'.join('"'+s.replace('\\','/')+'"' for s in args),encoding='utf-8')
    result = subprocess.run([str(java_tool('javac', JDK)),'-J-Duser.language=en','@'+str(argfile)],
                            cwd=ROOT,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
    compiler_output = result.stdout.decode('utf-8',errors='replace')
    (build/'javac.log').write_text(compiler_output,encoding='utf-8')
    if compiler_output:
        print(compiler_output,end='',flush=True)
    if result.returncode:
        sys.exit(result.returncode)
    dest = ROOT/'build/libs'/JAR_NAME
    dest.parent.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(dest,'w',zipfile.ZIP_DEFLATED) as jar:
        jar.writestr('META-INF/MANIFEST.MF',f'Manifest-Version: 1.0\nImplementation-Title: Create: Automation\nImplementation-Version: {MOD_VERSION}\n\n')
        for base in [classes,ROOT/'src/main/resources']:
            for p in sorted(base.rglob('*')):
                if p.is_file(): jar.write(p,p.relative_to(base).as_posix())
    report={'jar':str(dest),'sha256':hashlib.sha256(dest.read_bytes()).hexdigest(),
            'source_count':len(sources),'classes_dir':str(classes),
            'dependencies':[str(p) for p in libs], 'build_method':'Java21 against exact installed NeoForge21.1.248 production Mojmap API'}
    (ROOT/'build/local-build.json').write_text(json.dumps(report,indent=2,ensure_ascii=False),encoding='utf-8')
    print(f'Built {dest} ({dest.stat().st_size} bytes), {len(sources)} Java sources.',flush=True)


if __name__=='__main__': main()
