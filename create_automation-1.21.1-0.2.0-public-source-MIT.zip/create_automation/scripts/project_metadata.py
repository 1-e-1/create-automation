"""Addon artifact identity shared by local build, isolated runtimes and packaging."""
MOD_VERSION = '0.2.0'
JAR_NAME = f'create_automation-1.21.1-{MOD_VERSION}.jar'
