"""Generate original pixel-art block textures and Minecraft data assets."""
import gzip
import json
import struct
from pathlib import Path
from PIL import Image, ImageDraw

ROOT = Path(__file__).resolve().parents[1] / 'src/main/resources'
ASSET = ROOT / 'assets/create_automation'
DATA = ROOT / 'data/create_automation'
BLOCKS = {
    'rpm_sensor': ('转速检测器', 'Rotation Speed Detector', '#41BAA0', 'rpm', 'create:speedometer'),
    'height_sensor': ('高度检测器', 'Height Detector', '#70C4E6', 'height', 'minecraft:clock'),
    'speed_sensor': ('速度检测器', 'Velocity Detector', '#A6D57C', 'speed', 'minecraft:feather'),
    'attitude_sensor': ('姿态检测器', 'Attitude Detector', '#C496DE', 'attitude', 'minecraft:ender_pearl'),
    'quick_configurator': ('系统快速配置器', 'Quick System Configurator', '#F0CC77', 'quick', 'minecraft:quartz'),
    'motion_sensor': ('连续运动检测器', 'Continuous Motion Detector', '#6AAEE0', 'motion', 'minecraft:compass'),
    'system_builder': ('系统构建器', 'System Builder', '#53C3AA', 'graph', 'create:precision_mechanism'),
    'system_output': ('系统输出器', 'System Output', '#E6B65E', 'out', 'create:electron_tube'),
    'rpm_output': ('转速输出器', 'Rotation Speed Output', '#ED9666', 'motor', 'create:shaft'),
    'redstone_input': ('红石输入接口', 'Redstone Input Bridge', '#DA6868', 'in', 'minecraft:comparator'),
    'redstone_output': ('红石输出接口', 'Redstone Output Bridge', '#DA6868', 'out', 'minecraft:repeater'),
    'constant': ('数值发生器', 'Numeric Source', '#B59ADC', 'constant', 'minecraft:lever'),
    'monitor': ('信号记录仪', 'Signal Monitor', '#6BBFD5', 'monitor', 'minecraft:glass'),
}

def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')

def frame(accent):
    im = Image.new('RGB', (32,32), '#45534C')
    d = ImageDraw.Draw(im)
    d.rectangle((0,0,31,31), outline='#252F2B', width=2)
    d.rectangle((2,2,29,29), outline='#D0AD69', width=2)
    d.rectangle((4,4,27,27), fill='#293D36', outline='#87978A')
    d.line((5,5,26,5), fill='#B6C1AC')
    for x,y in [(2,2),(28,2),(2,28),(28,28)]:
        d.rectangle((x,y,x+1,y+1), fill='#EAD5A0')
    d.rectangle((6,25,25,26), fill='#182B25')
    d.rectangle((6,25,12,26), fill=accent)
    return im,d

def texture(name, accent, icon):
    im,d=frame(accent)
    if icon in ('rpm','motor'):
        d.ellipse((8,7,24,23), outline=accent, width=2)
        d.rectangle((13,12,19,18), fill='#B8B9A5', outline='#F0E3BB')
        for a,b in [((16,5),(16,10)),((16,20),(16,24)),((6,15),(11,15)),((21,15),(26,15))]:
            d.line((a,b), fill=accent, width=2)
        if icon=='rpm': d.line((16,15,21,10), fill='#FFF1CC', width=2)
    elif icon=='height':
        d.line((10,7,10,23), fill=accent, width=2)
        for y in range(8,24,4): d.line((10,y,14,y), fill='#E3E9C9')
        d.line((22,9,22,21), fill=accent, width=2)
        d.polygon([(22,6),(18,11),(25,11)], fill=accent)
        d.polygon([(22,24),(18,19),(25,19)], fill=accent)
    elif icon=='speed':
        d.line((6,10,13,10), fill=accent, width=2)
        d.line((7,16,21,16), fill=accent, width=2)
        d.line((6,22,13,22), fill=accent, width=2)
        d.polygon([(26,16),(19,10),(19,22)], fill='#E3E9C9')
    elif icon=='attitude':
        d.ellipse((7,6,25,24), outline=accent, width=2)
        d.line((7,19,25,11), fill='#E3E9C9', width=2)
        d.line((16,8,16,12), fill=accent)
        d.line((16,19,16,22), fill=accent)
    elif icon=='quick':
        d.ellipse((7,7,12,12), outline=accent, width=1)
        d.ellipse((7,18,12,23), outline=accent, width=1)
        d.line((19,8,25,14), fill=accent, width=2)
        d.line((25,8,19,14), fill=accent, width=2)
        d.line((18,18,25,18), fill='#E3E9C9', width=2)
        d.line((18,22,25,22), fill='#E3E9C9', width=2)
    elif icon=='graph':
        d.line((9,10,20,10,20,20,9,20,9,10), fill='#A7C8AA', width=1)
        for x,y in [(6,7),(18,7),(6,17),(18,17)]:
            d.rectangle((x,y,x+6,y+5), fill=accent, outline='#E3E9C9')
    elif icon=='motion':
        d.line((8,20,24,20), fill=accent, width=2)
        d.line((16,8,16,22), fill=accent, width=2)
        d.polygon([(16,6),(12,12),(20,12)], fill='#E3E9C9')
        d.line((7,16,11,16,11,13,21,13,21,16,25,16), fill=accent)
    elif icon in ('in','out'):
        d.rectangle((7,8,24,22), outline=accent, width=2)
        if icon=='in':
            d.line((5,15,18,15), fill='#F5E6BD', width=2)
            d.polygon([(22,15),(16,11),(16,19)], fill=accent)
        else:
            d.line((11,15,26,15), fill='#F5E6BD', width=2)
            d.polygon([(27,15),(21,11),(21,19)], fill=accent)
    elif icon=='constant':
        d.line((9,15,23,15), fill=accent, width=3)
        d.line((16,8,16,22), fill=accent, width=3)
        d.rectangle((23,21,24,22), fill='#F5E6BD')
    else:
        d.rectangle((6,7,25,23), fill='#142B27', outline='#9BAB98')
        d.line((8,19,11,19,14,11,17,20,20,14,23,14), fill=accent, width=2)
    path=ASSET/'textures/block'/f'{name}.png'
    path.parent.mkdir(parents=True,exist_ok=True)
    im.save(path)


def main():
    zh={'itemGroup.create_automation':'机械动力：自动化'}
    en={'itemGroup.create_automation':'Create: Automation'}
    side,draw=frame('#D0AD69')
    draw.rectangle((8,9,23,21), outline='#4D6859', width=2)
    draw.line((10,12,21,12),fill='#7B8B74')
    (ASSET/'textures/block').mkdir(parents=True,exist_ok=True)
    side.save(ASSET/'textures/block/casing.png')
    for name,(cn,english,accent,icon,ingredient) in BLOCKS.items():
        texture(name,accent,icon)
        zh['block.create_automation.'+name]=cn
        en['block.create_automation.'+name]=english
        variants={}
        for facing,x,y in [('north',0,0),('east',0,90),('south',0,180),('west',0,270),('up',270,0),('down',90,0)]:
            variants['facing='+facing]={'model':f'create_automation:block/{name}','x':x,'y':y}
        write(ASSET/'blockstates'/f'{name}.json',{'variants':variants})
        write(ASSET/'models/block'/f'{name}.json',{
            'parent':'minecraft:block/orientable',
            'textures':{'top':'create_automation:block/casing','front':f'create_automation:block/{name}','side':'create_automation:block/casing'}})
        write(ASSET/'models/item'/f'{name}.json',{'parent':f'create_automation:block/{name}'})
        write(DATA/'loot_table/blocks'/f'{name}.json',{'type':'minecraft:block','pools':[{'rolls':1,'entries':[{'type':'minecraft:item','name':f'create_automation:{name}'}],'conditions':[{'condition':'minecraft:survives_explosion'}]}]})
        write(DATA/'recipe'/f'{name}.json',{'type':'minecraft:crafting_shaped','category':'redstone','pattern':[' I ','CEC',' S '],
            'key':{'I':{'item':ingredient},'C':{'item':'create:brass_casing'},'E':{'item':'create:electron_tube'},'S':{'item':'create:shaft'}},
            'result':{'id':f'create_automation:{name}','count':1}})
    # Ponder registrations and descriptions are owned by the client tutorial module.
    for code, language in [('zh_cn', zh), ('en_us', en)]:
        fragment = Path(__file__).resolve().parents[1]/'docs'/f'ponder_lang_{code}.json'
        if fragment.is_file(): language.update(json.loads(fragment.read_text(encoding='utf-8')))
    write(ASSET/'lang/zh_cn.json',zh)
    write(ASSET/'lang/en_us.json',en)
    write(ROOT/'data/minecraft/tags/block/mineable/pickaxe.json',{'replace':False,'values':['create_automation:'+k for k in BLOCKS]})
    # Empty 12x6x12 game-test template (gzip NBT), generated without runtime dependencies.
    def string(s):
        b=s.encode(); return struct.pack('>H',len(b))+b
    def integer(name,i): return b'\x03'+string(name)+struct.pack('>i',i)
    def list_tag(name,kind,items): return b'\x09'+string(name)+bytes([kind])+struct.pack('>i',len(items))+b''.join(items)
    palette=b'\x08'+string('Name')+string('minecraft:air')+b'\x00'
    payload=b'\x0a\x00\x00'+integer('DataVersion',3955)+list_tag('size',3,[struct.pack('>i',n) for n in (12,6,12)])+list_tag('palette',10,[palette])+list_tag('blocks',10,[])+list_tag('entities',10,[])+b'\x00'
    template=DATA/'structure/empty.nbt'; template.parent.mkdir(parents=True,exist_ok=True)
    template.write_bytes(gzip.compress(payload,mtime=0))
    print(f'Generated {len(BLOCKS)} block textures, models, recipes, loot tables, languages and test structure.')


if __name__=='__main__': main()
