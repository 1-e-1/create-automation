"""Fetch unmodified Gradle wrapper from the official NeoForge MDK."""
import time
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BASE = 'https://raw.githubusercontent.com/NeoForgeMDKs/MDK-1.21.1-ModDevGradle/main/'
for name in ['gradlew', 'gradlew.bat', 'gradle/wrapper/gradle-wrapper.jar', 'gradle/wrapper/gradle-wrapper.properties']:
    dest = ROOT / name
    dest.parent.mkdir(parents=True, exist_ok=True)
    if dest.exists():
        continue
    for attempt in range(3):
        try:
            data = urllib.request.urlopen(BASE + name, timeout=45).read()
            dest.write_bytes(data)
            print(f'{name}: {len(data)} bytes', flush=True)
            break
        except Exception as error:
            print(f'{name} attempt {attempt+1}: {error}', flush=True)
            if attempt == 2:
                raise
            time.sleep(2)
