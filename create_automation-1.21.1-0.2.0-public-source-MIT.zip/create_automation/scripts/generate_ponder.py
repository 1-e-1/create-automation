"""Deterministic native Ponder structures and bilingual tutorial/tooltip language fragments.

Run before generate_resources.py. Uses only Python's standard library. The generated
Java text registry supplies native Ponder's English fallback; all rendering remains
in Ponder, including the stock hold-W and Shift item tooltip prompts.
"""
import gzip
import json
import struct
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
TEXT = {
 'flow_source': ('Sources publish decimal values. This constant supplies a target of 3.25.', '信号源发布小数数值。这里的常数模块提供目标值 3.25。'),
 'flow_channels': ('Right-click to configure. Match dimension, network and channel to connect; one publisher per channel.', '右键配置。维度、网络和通道名相同即可连接；每个通道只允许一个发布者。'),
 'flow_output': ('The system builder calculates a graph. A system output can remap and republish its result.', '系统构建器执行节点图。系统输出接口可以映射数值并发布到另一个通道。'),
 'flow_precision': ('The monitor plots values. The RPM output drives a shaft with continuous signed RPM; intermediate signals retain decimal precision.', '监视器显示曲线；转速输出以连续正负 RPM 驱动轴。中间信号保留小数精度。'),
 'flow_null': ('Unused inputs are NULL or blank. They have no subscription and are not a numerical zero. Save to apply edits.', '不用的输入填 NULL 或留空：它们不订阅信号，也不是数值 0。修改后点击保存。'),
 'sensor_body': ('Height, speed and attitude detectors measure the whole Sable rigid body. Mounting location does not change their reference.', '高度、速度、姿态检测器测量整个 Sable 刚体，安装位置不会改变整船参考点。'),
 'sensor_height': ('Height offers absolute World Y or height relative to a zero reference. Save & zero establishes a new reference.', '高度可选绝对世界 Y，或相对归零高度。“保存并校准高度零点”建立新的相对参考。'),
 'sensor_speed': ('Speed offers magnitude or world X/Y/Z velocity, in blocks per second. Missing bodies produce an invalid signal.', '速度可选合速度或世界 X/Y/Z 分量，单位为方块/秒。没有有效刚体时信号无效。'),
 'sensor_attitude': ('Attitude offers Roll, Pitch and Yaw as YXZ Euler angles in degrees. Select the component needed by your controller.', '姿态提供 Roll、Pitch、Yaw，采用 YXZ 欧拉角，单位为度。选择控制器需要的分量。'),
 'sensor_rpm': ('The RPM sensor measures the actual Create shaft speed. Its shaft connection is separate from the numerical channel.', '转速检测器读取真实 Create 轴转速。轴连接与数值通道分别配置。'),
 'sensor_legacy': ('The original motion sensor remains compatible: its HEIGHT mode measures relative height at the sensor block point.', '原运动传感器继续兼容旧装置：HEIGHT 模式测量传感器方块点位的相对高度。'),
 'graph_inputs': ('Assign A to the target and B to the measured value. INPUT port 0/1/2/3 reads A/B/C/D; unused ports stay NULL.', 'A 接目标，B 接测量值。INPUT 的 port 0/1/2/3 对应 A/B/C/D；不用的端口保持 NULL。'),
 'graph_nodes': ('Open Build graph. Add nodes, select each operation and connect its input nodes. Presets are editable starting points.', '打开“系统构建”。添加节点、选择运算并连接输入节点。预设也可以继续修改。'),
 'graph_pid': ('PID takes target and measurement. Configure kp, ki, kd and output limits. Gains must be tuned for your vehicle.', 'PID 输入依次为目标、测量。设置 kp、ki、kd 与输出限幅；增益需要按载具调节。'),
 'graph_apply': ('Select the final node, choose Use as output, then Save & apply. Invalid graphs are rejected without losing your draft.', '选择最终节点，点击“设为输出”，再保存。无效节点图会被拒绝，草稿仍保留。'),
 'graph_trace': ('Live traces show the saved running system and keep your unsaved draft intact. Invalid data leaves a gap.', '实时曲线显示已保存系统的运行结果，不覆盖未保存草稿。无效数据会留空。'),
 'graph_delay': ('Feedback inside a graph must pass through DELAY. It holds the previous step; ordinary channel links add one tick of delay.', '图内反馈环必须经过 DELAY，它保存上一步数值；普通通道连接会增加一 tick 延迟。'),
 'redstone_input': ('The input interface converts redstone strength 0-15 into a numerical signal using scale and offset.', '红石输入接口将 0–15 强度经比例和偏移映射为数值信号。'),
 'redstone_math': ('The builder can calculate, filter and control with decimals, even when the original source is redstone.', '即使信号源是红石，构建器内部仍能用小数运算、滤波和控制。'),
 'redstone_output': ('The output interface maps and clamps the result, then rounds it to redstone strength 0-15.', '红石输出接口先映射并限幅，再将结果取整到 0–15 强度。'),
 'redstone_limits': ('Choose scale and limits for the receiving device. Quantization happens at this redstone boundary.', '按接收装置设置比例和上下限。量化发生在红石接口处。'),
 'quick_reference': ('The quick configurator takes the reference on A and publishes Y. Keep B/C/D as NULL.', '快速配置器从 A 读取参考输入并发布 Y；B/C/D 保持 NULL。'),
 'quick_transfer': ('Enter the zeros, poles and gain K of open-loop L(s). Positive imaginary parts automatically create conjugate pairs.', '输入开环 L(s) 的零点、极点和增益 K。正虚部会自动生成共轭对。'),
 'quick_feedback': ('It forms unit negative feedback automatically: T(s) = L(s) / (1 + L(s)). The simulation advances once per tick.', '自动形成单位负反馈：T(s) = L(s) / (1 + L(s))。仿真每 tick 前进一步。'),
 'quick_curve': ('Save and watch the response curve. Check steady value, overshoot and settling before connecting an actuator.', '保存后观察响应曲线，检查稳态值、超调和收敛，再连接执行器。'),
 'quick_limits': ('Set output limits for the device, then subscribe an RPM output or another numerical consumer to Y.', '设置适合装置的输出限幅，然后让转速输出或其他数值模块订阅 Y。'),
 'quick_physical': ('This is a closed-loop model simulation. To feed back an actual vehicle measurement, use the builder with a sensor and PID graph.', '这是闭环模型仿真。要反馈真实载具测量值，请使用检测器和系统构建器中的 PID 图。'),
}
TOOLTIPS = {
 'rpm_sensor': ('Read actual Create shaft speed in _RPM_. Publish it as a decimal signal.', '读取真实 Create 轴转速，单位 _RPM_，发布为小数信号。'),
 'motion_sensor': ('A compatible _Sable motion sensor_. Legacy HEIGHT uses the sensor block point.', '兼容旧装置的 _Sable 运动传感器_。HEIGHT 使用传感器点位高度。'),
 'height_sensor': ('Measure the _whole Sable body_ height: World Y or relative to a zero reference.', '测量_整个 Sable 刚体_的世界 Y 高度或归零相对高度。'),
 'speed_sensor': ('Measure _body speed_ or world X/Y/Z velocity, in blocks/s.', '测量_整船合速度_或世界 X/Y/Z 速度，单位方块/秒。'),
 'attitude_sensor': ('Measure _body Roll, Pitch or Yaw_: YXZ Euler angles in degrees.', '测量_整船 Roll、Pitch 或 Yaw_，采用 YXZ 欧拉角，单位度。'),
 'system_builder': ('Build an editable _control graph_: math, PID, filters, integration and delay.', '自由构建_控制节点图_：数学、PID、滤波、积分和延迟。'),
 'system_output': ('_Scale, offset and clamp_ a numerical signal, then publish it on another channel.', '将数值信号_缩放、偏移、限幅_后发布到另一通道。'),
 'rpm_output': ('Drive a Create shaft with _continuous signed RPM_ from a numerical channel.', '使用数值通道的_连续正负 RPM_ 驱动 Create 轴。'),
 'redstone_input': ('Convert redstone _0-15_ into a scaled numerical signal.', '将红石 _0–15_ 强度映射为数值信号。'),
 'redstone_output': ('Map a numerical signal to redstone _0-15_; this interface rounds the result.', '将数值信号映射为红石 _0–15_，在此接口取整。'),
 'constant': ('Publish a decimal _constant or target value_ to your control network.', '向控制网络发布小数_常数或目标值_。'),
 'monitor': ('Inspect a channel with _live values and response curves_.', '查看通道的_实时数值和响应曲线_。'),
 'quick_configurator': ('Enter open-loop _L(s)_. Simulate unit negative feedback _L/(1+L)_; A is the reference.', '输入开环 _L(s)_，仿真单位负反馈 _L/(1+L)_；A 为参考输入。'),
}
SCENES = {
 'signal_flow': ('Precise signals: detect, calculate, drive','精确信号：检测、计算、驱动'),
 'sensors': ('Measuring the whole structure','检测整个结构的运动'),
 'graph': ('Build your own controller graph','自由构建控制系统节点图'),
 'redstone': ('Bridge redstone and continuous signals','连接红石与连续数值信号'),
 'quick_control': ('An open-loop model becomes a closed-loop system','开环模型自动组成闭环系统'),
}

def utf(s):
    b=s.encode('utf-8'); return struct.pack('>H',len(b))+b
def payload(t,v):
    if t==3: return struct.pack('>i',v)
    if t==8: return utf(v)
    if t==9:
        typ,items=v; return bytes([typ])+struct.pack('>i',len(items))+b''.join(payload(typ,item) for item in items)
    if t==10: return b''.join(bytes([typ])+utf(name)+payload(typ,value) for name,(typ,value) in v.items())+b'\0'
    raise ValueError(t)
def write_structure(name, extras):
    states=[]; blocks=[]
    def block(x,y,z,id,props=None):
        state={'Name':(8,id)}
        if props: state['Properties']=(10,{k:(8,v) for k,v in props.items()})
        if state not in states: states.append(state)
        blocks.append({'pos':(9,(3,[x,y,z])),'state':(3,states.index(state))})
    for x in range(7):
        for z in range(7): block(x,0,z,'minecraft:polished_andesite')
    for x,y,z,id,props in extras: block(x,y,z,id,props)
    data={'DataVersion':(3,3955),'size':(9,(3,[7,4,7])),'palette':(9,(10,states)),
          'blocks':(9,(10,blocks)),'entities':(9,(10,[]))}
    path=ROOT/'src/main/resources/assets/create_automation/ponder'/f'{name}.nbt'
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_bytes(gzip.compress(b'\x0a\0\0'+payload(10,data),mtime=0))
def node(x,z,id): return (x,1,z,'create_automation:'+id,{'facing':'south'})
def vanilla(x,z,id,props=None): return (x,1,z,id,props)

def main():
    write_structure('signal_flow',[node(1,2,'constant'),node(3,2,'system_builder'),node(5,2,'system_output'),node(3,4,'monitor'),node(5,4,'rpm_output'),vanilla(5,5,'create:shaft',{'axis':'z'})])
    write_structure('sensors',[node(1,1,'motion_sensor'),node(3,1,'height_sensor'),node(5,1,'speed_sensor'),node(3,3,'attitude_sensor'),node(1,5,'rpm_sensor'),vanilla(1,4,'create:shaft',{'axis':'z'}),vanilla(1,6,'create:creative_motor',{'facing':'north'})])
    write_structure('graph',[node(1,2,'constant'),node(1,4,'height_sensor'),node(3,2,'system_builder'),node(5,2,'system_output'),node(3,4,'monitor')])
    write_structure('redstone',[vanilla(1,1,'minecraft:lever',{'face':'floor','facing':'south','powered':'false'}),vanilla(1,2,'minecraft:redstone_wire',{'north':'side','south':'side','east':'none','west':'none','power':'0'}),node(1,3,'redstone_input'),node(3,3,'system_builder'),node(5,3,'redstone_output'),vanilla(5,2,'minecraft:redstone_wire',{'north':'side','south':'side','east':'none','west':'none','power':'0'}),vanilla(5,1,'minecraft:redstone_lamp',{'lit':'false'})])
    write_structure('quick_control',[node(1,2,'constant'),node(3,2,'quick_configurator'),node(3,4,'monitor'),node(5,4,'rpm_output'),vanilla(5,5,'create:shaft',{'axis':'z'})])
    for index,locale in enumerate(('en_us','zh_cn')):
        lang={f'create_automation.ponder.shared.{key}':pair[index] for key,pair in TEXT.items()}
        lang.update({f'create_automation.ponder.{key}.header':pair[index] for key,pair in SCENES.items()})
        tags={'signals':(('Continuous signals','Measure and route precise numerical signals'),('连续数值信号','检测并连接精确数值信号')),
              'control':(('Control systems','Build a graph or configure a transfer function'),('控制系统','构建节点图或配置传递函数')),
              'actuators':(('Outputs and interfaces','Drive Create rotation and connect redstone'),('输出与接口','驱动 Create 转轴并连接红石'))}
        for key,pair in tags.items():
            lang[f'create_automation.ponder.tag.{key}']=pair[index][0]
            lang[f'create_automation.ponder.tag.{key}.description']=pair[index][1]
        for key,pair in TOOLTIPS.items():
            base=f'block.create_automation.{key}.tooltip'
            lang[base+'.summary']=pair[index]
            lang[base+'.condition1']=('On right-click','右键时')[index]
            lang[base+'.behaviour1']=('Configure channels and settings, then Save & apply. NULL inputs are unused.','配置通道和参数，再保存并应用。NULL 输入表示未使用。')[index]
        (ROOT/'docs'/f'ponder_lang_{locale}.json').write_text(json.dumps(lang,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    java='package dev.createautomation.client.ponder;\n\nimport net.createmod.ponder.api.registration.SharedTextRegistrationHelper;\n\n/** Generated by scripts/generate_ponder.py. */\nfinal class AutomationPonderText {\n    static void register(SharedTextRegistrationHelper helper) {\n'
    for key,pair in TEXT.items(): java+='        helper.registerSharedText('+json.dumps(key)+', '+json.dumps(pair[0])+');\n'
    java+='    }\n}\n'
    (ROOT/'src/main/java/dev/createautomation/client/ponder/AutomationPonderText.java').write_text(java,encoding='utf-8')
    print('Generated 5 Ponder structures, 27 shared texts, 13 tooltip descriptions, bilingual fragments')

if __name__=='__main__': main()
