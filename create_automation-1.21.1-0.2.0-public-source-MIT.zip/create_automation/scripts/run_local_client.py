"""Prepare/run an isolated offline Minecraft client without touching the user's worlds or mods.

Shares the exact, already-installed 1.21.1 / NeoForge 21.1.248 runtime preparation
with run_local_gametest. All writable client state lives under run/local-client.
No account store, access token, or launcher login is read. Assets are read-only.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import time
import uuid

import run_local_gametest as runtime
from build_local import ROOT, MC, JDK
from project_metadata import JAR_NAME
from local_config import java_tool

RUN = ROOT / 'run/local-client'
IDENTITY = 'AutomationUITest'


def prepare(world_source=None, smoke=False, world_name=None, with_aeronautics=False):
    RUN.mkdir(parents=True, exist_ok=True)
    (RUN / 'natives').mkdir(exist_ok=True)
    (RUN / 'mods').mkdir(exist_ok=True)
    runtime.archive_previous_addons(RUN / 'mods')
    (RUN / 'saves').mkdir(exist_ok=True)
    metadata, exploded = runtime.prepare_runtime()
    artifacts = [ROOT / 'libs/create-1.21.1-6.0.10.jar', ROOT / 'libs/sable-neoforge-1.21.1-2.0.6.jar',
                 ROOT / 'build/libs' / JAR_NAME]
    for source in artifacts:
        if not source.is_file():
            raise FileNotFoundError(f'Build/stage the required mod first: {source}')
        shutil.copy2(source, RUN / 'mods' / source.name)
    if with_aeronautics:
        runtime.stage_aeronautics(RUN / 'mods')

    if world_source:
        source = Path(world_source).resolve()
        if not source.is_relative_to((ROOT / 'run').resolve()):
            raise ValueError('Only worlds created inside this project run/ directory may be used')
        if not (source / 'level.dat').is_file():
            raise ValueError(f'The test source is not a saved Minecraft world: {source}')
        world_name = 'AutomationUITest-' + time.strftime('%Y%m%d-%H%M%S')
        destination = RUN / 'saves' / world_name
        # Caller must stop the test server before copying its world. Existing worlds are never overwritten.
        shutil.copytree(source, destination, ignore=shutil.ignore_patterns('session.lock'))
    if world_name:
        world = (RUN / 'saves' / world_name).resolve()
        if not world.is_relative_to((RUN / 'saves').resolve()) or not (world / 'level.dat').is_file():
            raise ValueError('Quick Play world must be an existing isolated client save')
    if smoke and not world_name:
        raise ValueError('--smoke requires --world or --world-source, both within the isolated test workspace')

    # These are new isolated preferences, not the player's options.txt.
    options = RUN / 'options.txt'
    if not options.is_file():
        options.write_text('version:3955\nlang:zh_cn\nguiScale:2\nrenderDistance:5\nsimulationDistance:5\n'
                           'maxFps:60\nenableVsync:false\nfullscreen:false\n'
                           'pauseOnLostFocus:false\nshowAutosaveIndicator:false\n'
                           'onboardAccessibility:false\ntutorialStep:none\n'
                           'soundCategory_master:0.0\n', encoding='utf-8')

    libraries = runtime.exact_libraries(metadata)
    bootstrap = [arg.replace(str(runtime.RUN / 'natives'), str(RUN / 'natives'))
                 for arg in runtime.bootstrap_jvm(metadata, libraries)]
    arguments = ['-Xmx3G', '-Xms512M', '-Dfile.encoding=UTF-8',
                 '-Dfml.modFolders=minecraft%%' + str(exploded)]
    if smoke:
        arguments.append('-Dcreate_automation.uiSmoke=true')
    arguments += bootstrap
    offline_uuid = uuid.UUID(bytes=hashlib.md5(('OfflinePlayer:' + IDENTITY).encode('utf-8')).digest(), version=3)
    arguments += [metadata['mainClass'], '--launchTarget', 'forgeclientdev',
                  '--fml.neoForgeVersion', '21.1.248', '--fml.fmlVersion', '4.0.43',
                  '--fml.mcVersion', '1.21.1', '--fml.neoFormVersion', '20240808.144430',
                  '--username', IDENTITY, '--uuid', offline_uuid.hex, '--accessToken', '0',
                  '--version', 'create_automation_test', '--versionType', 'release', '--userType', 'legacy',
                  '--gameDir', str(RUN), '--assetsDir', str(MC / 'assets'),
                  '--assetIndex', metadata['assetIndex']['id'], '--width', '854', '--height', '480']
    if world_name:
        arguments += ['--quickPlaySingleplayer', world_name]
    argfile = RUN / 'launch.args'
    argfile.write_text('\n'.join('"' + arg.replace('\\', '/') + '"' for arg in arguments), encoding='utf-8')
    sanitized = arguments.copy()
    for flag in ['--accessToken', '--uuid', '--username']:
        sanitized[sanitized.index(flag) + 1] = '<offline-test-identity>'
    (RUN / 'launch.redacted.json').write_text(json.dumps({
        'java': str(java_tool('java', JDK)), 'args': sanitized, 'world': world_name,
        'isolated_game_directory': str(RUN), 'user_worlds_accessed': False,
        'mods': [{'file': p.name, 'sha256': hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted((RUN/'mods').glob('*.jar'))],
    }, ensure_ascii=False, indent=2), encoding='utf-8')
    return argfile


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--prepare-only', action='store_true', help='Prepare without launching (the default)')
    parser.add_argument('--launch', action='store_true', help='Start the isolated client')
    parser.add_argument('--wait', action='store_true', help='Wait and return the client exit status')
    parser.add_argument('--world-source', help='Copy a stopped project test server world into a new isolated save')
    parser.add_argument('--world', help='Existing save directory name inside run/local-client/saves')
    parser.add_argument('--smoke', action='store_true', help='Enable the explicit client GUI smoke harness')
    parser.add_argument('--with-aeronautics', action='store_true', help='Also load the installed Aeronautics 1.3.2 bundle')
    options = parser.parse_args()
    argfile = prepare(options.world_source, options.smoke, options.world, options.with_aeronautics)
    print(f'Prepared isolated client: {RUN}; sanitized launch record: launch.redacted.json', flush=True)
    if not options.launch or options.prepare_only:
        return
    log = RUN / f'console-{int(time.time())}.log'
    environment = os.environ.copy()
    environment.pop('MOD_CLASSES', None)
    with log.open('w', encoding='utf-8') as output:
        # Hide the helper console; Minecraft's own GLFW window remains visible for visual QA.
        flags = subprocess.CREATE_NO_WINDOW if os.name == 'nt' else 0
        process = subprocess.Popen([str(java_tool('java', JDK)), '@' + str(argfile)], cwd=RUN, env=environment,
                                   stdout=output, stderr=subprocess.STDOUT, creationflags=flags)
    (RUN / 'process.json').write_text(json.dumps({'pid': process.pid, 'log': str(log),
                                                'started': time.time()}, indent=2), encoding='utf-8')
    print(f'Isolated client PID={process.pid}; log={log}', flush=True)
    if options.wait:
        result = process.wait()
        print(f'Client exit={result}', flush=True)
        raise SystemExit(result)


if __name__ == '__main__':
    main()
