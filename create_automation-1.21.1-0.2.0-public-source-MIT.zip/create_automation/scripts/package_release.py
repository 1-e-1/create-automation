"""Package this addon's JAR and source after matching its documented verification record."""
import hashlib
import json
import shutil
import zipfile
from pathlib import Path
from project_metadata import JAR_NAME

ROOT = Path(__file__).resolve().parents[1]
NAME = JAR_NAME.removesuffix('.jar')


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    jar = ROOT / 'build/libs' / (NAME + '.jar')
    verification = json.loads((ROOT / 'docs/release-verification.json').read_text(encoding='utf-8'))
    if verification.get('status') != 'passed' or verification.get('jar_sha256') != digest(jar):
        raise RuntimeError('Release JAR must match the documented verification record and its artifact hash')
    with zipfile.ZipFile(jar) as archive:
        names = set(archive.namelist())
        required = {'META-INF/neoforge.mods.toml', 'create_automation.mixins.json', 'LICENSE',
                    'dev/createautomation/CreateAutomation.class',
                    'dev/createautomation/client/AutomationScreen.class'}
        for block in ('rpm_sensor','motion_sensor','system_builder','system_output','rpm_output',
                      'redstone_input','redstone_output','constant','monitor',
                      'height_sensor','speed_sensor','attitude_sensor','quick_configurator'):
            required.add(f'assets/create_automation/blockstates/{block}.json')
            required.add(f'data/create_automation/recipe/{block}.json')
        if not required.issubset(names):
            raise RuntimeError(f'Missing release entries: {sorted(required - names)}')
        if any(n.startswith(('net/minecraft/', 'com/simibubi/', 'dev/ryanhcode/', 'META-INF/jarjar/')) for n in names):
            raise RuntimeError('Upstream dependencies must not be bundled in this addon')
    dist = ROOT / 'dist'
    dist.mkdir(exist_ok=True)
    shutil.copy2(jar, dist / jar.name)
    shutil.copy2(ROOT/'README.md', dist/'README.md')
    shutil.copy2(ROOT/'docs/VERIFICATION.md', dist/'VERIFICATION.md')
    shutil.copy2(ROOT/'docs/release-verification.json', dist/'release-verification.json')
    shutil.copytree(ROOT/'docs', dist/'docs', dirs_exist_ok=True)
    source_zip = dist / (NAME + '-source.zip')
    top_files = ['README.md', 'LICENSE', 'THIRD_PARTY.md', 'BUILDING.md', 'PROJECT_DESCRIPTION_EN.txt',
                 '.gitignore', 'build.gradle', 'settings.gradle',
                 'gradle.properties', 'gradlew', 'gradlew.bat']
    files = [ROOT / name for name in top_files]
    for folder in ('src', 'scripts', 'docs', 'gradle'):
        files += [p for p in (ROOT/folder).rglob('*') if p.is_file()
                  and not any(part in ('__pycache__', '.compile-check') for part in p.relative_to(ROOT).parts)
                  and p.suffix not in ('.pyc', '.class')]
    with zipfile.ZipFile(source_zip, 'w', zipfile.ZIP_DEFLATED) as archive:
        for path in sorted(set(files)):
            archive.write(path, 'create_automation/' + path.relative_to(ROOT).as_posix())
    artifacts = [dist / jar.name, source_zip, dist/'README.md', dist/'VERIFICATION.md', dist/'release-verification.json']
    (dist/'SHA256SUMS.txt').write_text(''.join(f'{digest(p)}  {p.name}\n' for p in artifacts), encoding='utf-8')
    print(f'Packaged {jar.name}: {digest(jar)}')
    print(f'Source: {source_zip} ({source_zip.stat().st_size} bytes)')


if __name__ == '__main__':
    main()
