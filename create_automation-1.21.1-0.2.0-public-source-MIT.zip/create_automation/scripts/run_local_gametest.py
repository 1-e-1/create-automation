"""Isolated headless NeoForge development launch from the exact installed 1.21.1 runtime.

No user saves/mods are modified. The production jars already contain Mojang names;
we overlay the matching NeoForge patches in a local exploded development root.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import time
import zipfile
import re

from build_local import ROOT, MC, VERSION, JDK
from project_metadata import JAR_NAME
from local_config import mods_directory, java_tool

RUN = ROOT / 'run/local-gametest'


def prepare_runtime():
    metadata = json.loads(VERSION.read_text(encoding='utf-8'))
    root = RUN / 'runtime/minecraft'
    jars = [MC/'libraries/net/minecraft/client/1.21.1-20240808.144430/client-1.21.1-20240808.144430-srg.jar',
            MC/'libraries/net/neoforged/neoforge/21.1.248/neoforge-21.1.248-client.jar',
            MC/'libraries/net/neoforged/neoforge/21.1.248/neoforge-21.1.248-universal.jar']
    fingerprint = '\n'.join(f'{p}:{p.stat().st_size}:{p.stat().st_mtime_ns}' for p in jars)
    marker = RUN / 'runtime/fingerprint.txt'
    if not marker.is_file() or marker.read_text(encoding='utf-8') != fingerprint:
        root.mkdir(parents=True, exist_ok=True)
        for jar in jars:
            with zipfile.ZipFile(jar) as archive:
                for item in archive.infolist():
                    if item.is_dir() or item.filename.upper().endswith(('.SF', '.RSA', '.DSA')):
                        continue
                    destination = (root/item.filename).resolve()
                    if not destination.is_relative_to(root.resolve()):
                        raise RuntimeError(f'Unsafe jar path {item.filename}')
                    destination.parent.mkdir(parents=True, exist_ok=True)
                    destination.write_bytes(archive.read(item))
        marker.write_text(fingerprint, encoding='utf-8')
    return metadata, root


def exact_libraries(metadata):
    libraries = []
    for library in metadata['libraries']:
        allowed = not library.get('rules')
        for rule in library.get('rules', []):
            operating_system = rule.get('os', {}).get('name')
            if operating_system is None or operating_system == 'windows':
                allowed = rule['action'] == 'allow'
        if not allowed:
            continue
        path = library.get('downloads', {}).get('artifact', {}).get('path')
        if path:
            full = MC/'libraries'/path
            if not full.is_file():
                raise FileNotFoundError(full)
            # Minecraft/NeoForge are supplied through the exploded dev root, not bootstrap modules.
            if '/net/neoforged/neoforge/' in full.as_posix() or '/net/minecraft/client/' in full.as_posix():
                continue
            libraries.append(full)
    libraries.append(MC/'libraries/net/minecraft/client/1.21.1-20240808.144430/client-1.21.1-20240808.144430-extra.jar')
    return list(dict.fromkeys(libraries))


def bootstrap_jvm(metadata, libraries):
    replacements = {
        '${library_directory}': str(MC/'libraries'), '${classpath_separator}': os.pathsep,
        '${classpath}': os.pathsep.join(map(str, libraries)), '${version_name}': 'create_automation_test',
        '${natives_directory}': str(RUN/'natives'), '${launcher_name}': 'CreateAutomationTest',
        '${launcher_version}': '1',
    }
    args = []
    for entry in metadata['arguments']['jvm']:
        if isinstance(entry, dict):
            continue  # Heapdump naming and platform launcher UI flags are unnecessary for a headless server.
        value = entry
        for old, new in replacements.items():
            value = value.replace(old, new)
        args.append(value)
    return args


def archive_previous_addons(mods):
    # Only retire our own older artifacts in isolated project runtimes; preserve their bytes.
    mods = mods.resolve()
    if not mods.is_relative_to((ROOT/'run').resolve()):
        raise ValueError('Addon staging is restricted to project run directories')
    for previous in mods.glob('create_automation-*.jar'):
        if previous.name == JAR_NAME:
            continue
        with zipfile.ZipFile(previous) as archive:
            metadata = archive.read('META-INF/neoforge.mods.toml').decode('utf-8')
        if 'modId="create_automation"' not in metadata:
            raise ValueError(f'Unexpected artifact: {previous.name}')
        archived = previous.with_name(previous.name + '.' + str(time.time_ns()) + '.disabled')
        previous.rename(archived)


def stage_aeronautics(mods):
    source = mods_directory()/'create-aeronautics-bundled-1.21.1-1.3.2.jar'
    if not source.is_file():
        raise FileNotFoundError(source)
    shutil.copy2(source, mods/source.name)


def prepare(with_aeronautics=False):
    RUN.mkdir(parents=True, exist_ok=True)
    metadata, exploded = prepare_runtime()
    mods = RUN/'mods'
    mods.mkdir(exist_ok=True)
    archive_previous_addons(mods)
    for jar in [ROOT/'libs/create-1.21.1-6.0.10.jar', ROOT/'libs/sable-neoforge-1.21.1-2.0.6.jar',
                ROOT/'build/libs'/JAR_NAME]:
        shutil.copy2(jar, mods/jar.name)
    if with_aeronautics:
        stage_aeronautics(mods)
    else:
        old_aero = mods/'create-aeronautics-bundled-1.21.1-1.3.2.jar'
        if old_aero.is_file():
            old_aero.unlink()  # Only our staged test dependency; the installed mod stays untouched.
    (RUN/'eula.txt').write_text('eula=true\n', encoding='utf-8')
    (RUN/'server.properties').write_text('online-mode=false\nserver-ip=127.0.0.1\nserver-port=0\n'
                                        'level-name=gametest-world\nenable-rcon=false\nenable-query=false\n', encoding='utf-8')
    libraries = exact_libraries(metadata)
    arguments = ['-Xmx3G', '-Xms512M', '-Dfile.encoding=UTF-8', '-Djava.awt.headless=true',
                 '-Dneoforge.gameTestServer=true', '-Dneoforge.enabledGameTestNamespaces=create_automation',
                 '-Dfml.modFolders=minecraft%%'+str(exploded)]
    arguments += bootstrap_jvm(metadata, libraries)
    arguments += [metadata['mainClass'], '--launchTarget', 'forgeserverdev',
                  '--fml.neoForgeVersion', '21.1.248', '--fml.fmlVersion', '4.0.43',
                  '--fml.mcVersion', '1.21.1', '--fml.neoFormVersion', '20240808.144430', '--nogui']
    argfile = RUN/'launch.args'
    argfile.write_text('\n'.join('"'+arg.replace('\\','/')+'"' for arg in arguments), encoding='utf-8')
    return argfile


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--prepare-only', action='store_true')
    parser.add_argument('--with-aeronautics', action='store_true', help='Also load the installed Aeronautics 1.3.2 bundle')
    opts = parser.parse_args()
    argfile = prepare(opts.with_aeronautics)
    if opts.prepare_only:
        print(f'Prepared {argfile}', flush=True)
        return
    log = RUN/f'console-{int(time.time())}.log'
    print(f'Starting isolated GameTest runtime; log={log}', flush=True)
    environment = os.environ.copy()
    environment.pop('MOD_CLASSES', None)
    flags = subprocess.CREATE_NO_WINDOW if os.name == 'nt' else 0
    with log.open('w', encoding='utf-8') as output:
        process = subprocess.Popen([str(java_tool('java', JDK)), '@'+str(argfile)], cwd=RUN, env=environment,
                                   stdout=output, stderr=subprocess.STDOUT, creationflags=flags)
        (RUN/'process.json').write_text(json.dumps({'pid': process.pid, 'log': str(log), 'started': time.time()}, indent=2), encoding='utf-8')
        print(f'GameTest PID={process.pid}', flush=True)
        result = process.wait()
    console = log.read_text(encoding='utf-8', errors='replace')
    total = re.search(r'========= (\d+) GAME TESTS COMPLETE', console)
    passed = re.search(r'All (\d+) required tests passed', console)
    report = {'exit_code': result, 'log': str(log), 'test_count': int(total.group(1)) if total else 0,
              'all_required_passed': passed is not None,
              'mod_sha256': hashlib.sha256((RUN/'mods'/JAR_NAME).read_bytes()).hexdigest(),
              'staged_mods': sorted(p.name for p in (RUN/'mods').glob('*.jar')),
              'with_aeronautics': opts.with_aeronautics}
    (RUN/'results-latest.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
    (log.with_suffix('.json')).write_text(json.dumps(report, indent=2), encoding='utf-8')
    print(f'GameTest exit={result}; log={log}', flush=True)
    raise SystemExit(result)


if __name__ == '__main__':
    main()
