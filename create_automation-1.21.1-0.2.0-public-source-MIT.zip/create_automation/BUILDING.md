# Building Create: Automation

This repository targets Java 21, Minecraft 1.21.1, NeoForge 21.1.248 and Create 6.0.10. Physical-body integration targets Sable 2.0.6; the complete tested combination also includes Create Aeronautics 1.3.2. Upstream mod JARs are obtained separately and are never included in this source archive.

## Exact-runtime build used for the release

The Python scripts compile against an existing, fully installed Windows Minecraft/NeoForge runtime. They do not install Minecraft, obtain game credentials, or search your computer for an account. Launch the exact game version at least once so its libraries and assets exist. Select an instance JSON containing the resolved NeoForge libraries and launch arguments; a partial inherited launcher JSON may not be sufficient.

Set these variables in the same PowerShell session, replacing every placeholder with your own absolute path:

```powershell
$env:CREATE_AUTOMATION_MINECRAFT = '<Minecraft root containing libraries and assets>'
$env:CREATE_AUTOMATION_VERSION_JSON = '<full path to the installed NeoForge instance JSON>'
$env:CREATE_AUTOMATION_MODS = '<directory containing the required mod JARs>'
$env:JAVA_HOME = '<Java 21 JDK directory>'
python scripts/stage_dependencies.py
python scripts/build_local.py
```

`CREATE_AUTOMATION_MODS` may be omitted when the selected instance JSON has its `mods` directory beside it. No personal Minecraft path or instance name is supplied as a fallback. The local-runtime launch scripts currently support Windows; cross-platform runtime launching is not claimed.

The staging step requires `create-1.21.1-6.0.10.jar` and `sable-neoforge-1.21.1-2.0.6.jar`. It extracts Create's nested development dependencies into the ignored `libs/` directory. Testing with Aeronautics also requires `create-aeronautics-bundled-1.21.1-1.3.2.jar` in the configured mods directory. The addon itself does not redistribute these dependencies.

The output is `build/libs/create_automation-1.21.1-0.2.0.jar`. Sources already include generated assets. To regenerate them, install Pillow and run:

```powershell
python scripts/generate_ponder.py
python scripts/generate_resources.py
```

## Checks

```powershell
python scripts/test_engine_local.py
python scripts/verify_transfer_scipy.py
python scripts/run_local_gametest.py --with-aeronautics
python scripts/run_local_client.py --world-source run/local-gametest/gametest-world --with-aeronautics --smoke --launch
```

The SciPy comparison additionally requires NumPy and SciPy. JUnit is downloaded from Maven Central if absent. Run the game tests to completion before copying their world into the isolated client. All test worlds and runtime outputs are confined to the repository's `run/` directory. GUI automation requires the explicit `--smoke` option. A successful smoke run leaves the isolated client open for inspection; exit it normally before running another instance.

## Gradle project

After staging the exact dependencies into `libs/`, the included Gradle project provides `gradlew.bat build` on Windows or `./gradlew build` with a suitable JDK on another platform. Gradle must download the NeoForge development runtime. The reference release was verified using the exact-runtime Python build; a successful Gradle build and non-Windows game launch are not part of the recorded validation. Local file dependencies are intentional here; this repository does not pretend to resolve every mod automatically from Maven.

## Release records

Historical game and GUI reports describe the tested v0.2.0 gameplay artifact. The MIT public build is checked against that artifact entry by entry; its license metadata and bundled license text are the documented differences. See `docs/PUBLIC_RELEASE.md` and `docs/evidence/public-build-equivalence.json` for the public artifact's own hash and comparison result. Paths in the public historical reports are anonymized; test outcomes are preserved.
