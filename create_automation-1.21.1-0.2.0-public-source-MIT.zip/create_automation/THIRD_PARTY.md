# Third-party components

Create: Automation is an independently developed addon. It is not an official Minecraft, NeoForge, Create, Create Aeronautics, or Sable project.

The original addon code and original assets in this repository are licensed under MIT; see [LICENSE](LICENSE). The mod JAR includes that license and declares `MIT` in its NeoForge metadata. This grant does not relicense upstream projects.

Minecraft, NeoForge, Create, Sable, Aeronautics, Flywheel, Ponder, Registrate and other runtime dependencies are not bundled in the addon JAR or source archive. Obtain them separately from their official distributions and follow their respective licenses. Development scripts may copy dependencies from an installation explicitly selected by the developer into ignored local `libs/` and `run/` directories.

The Gradle Wrapper is the only third-party JAR included in this source archive. It is distributed under Apache License 2.0. Its upstream license is preserved inside `gradle/wrapper/gradle-wrapper.jar`; an extracted copy is retained alongside that JAR for convenience. Gradle Wrapper components are not covered by this project's MIT license.
